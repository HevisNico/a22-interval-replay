"""Read-only diagnostic: recompute ONE cell from an existing campaign's
verified previous layer with THIS engine, without writing anything into
that campaign.  Use it to check, in minutes, whether a refused cell (for
example layer 18, lanes 4 and 8) now passes before restarting a campaign.

    python -B replay_cell.py --campaign OLD_CAMPAIGN_DIR --layer 18 --lane 4

The previous-layer payloads are hash-checked against that layer's
verification.json.  The result is a diagnostic only: it is NOT a receipt,
it is NOT part of any campaign and must not be imported as one (the inputs
were produced by another kernel_id).  For an accepted layer 18, run a new
campaign with this package.
"""
from pathlib import Path
import argparse, json, sys, os, time, tempfile
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'affine'))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--campaign', type=Path, required=True)
    ap.add_argument('--layer', type=int, required=True)
    ap.add_argument('--lane', type=int, required=True)
    args = ap.parse_args()
    if not __debug__: raise RuntimeError('Python -O is forbidden')
    if not 2 <= args.layer <= 18 or not 0 <= args.lane <= 11: ap.error('layer 2..18, lane 0..11')
    os.environ['A22_ARTIFACT_DIR'] = tempfile.mkdtemp(prefix='a22_replay_')
    import engine, artifacts as a
    try:
        import commutation; stats = commutation.STATS
    except ImportError:
        stats = 'absent (v2 engine)'
    camp = args.campaign.resolve()
    prev = camp / f'layer_{args.layer - 1:02d}'
    proof = json.loads((prev / 'verification.json').read_text())
    run_id = json.loads((camp / 'campaign.json').read_text())['run_id']
    trains = []
    for j in range(12):
        if j not in {(args.lane - 1) % 12, args.lane, (args.lane + 1) % 12}:
            trains.append(()); continue
        d = prev / f'cell_{j:02d}'
        if a.file_hash(d / 'result.json') != proof['payloads'][j]:
            raise ValueError(f'layer {args.layer - 1} cell {j}: payload differs from its verification')
        data = a.read(d / 'result.json', proof['payloads'][j])
        if data['case']['layer'] != args.layer - 1 or data['case']['lane'] != j: raise ValueError('wrong source cell')
        trains.append(data['outputs'])
    started = time.perf_counter()
    try:
        r = engine.compute_cell(args.layer, args.lane, trains, f'replay/{run_id}/cell/{args.layer}/{args.lane}')
    except Exception as e:
        print(json.dumps(dict(status='REFUSED', layer=args.layer, lane=args.lane, error=type(e).__name__,
            message=str(e)[:2000], commutation=stats, seconds=round(time.perf_counter() - started, 1)), indent=1))
        sys.exit(1)
    proofs = [p for p in r['state']['width_profile']['relative_order_proofs'] if p.get('guard') == 'fire_arrival_commutation']
    m = r['metrics']
    print(json.dumps(dict(status='PASSED (diagnostic only, not a receipt)', layer=args.layer, lane=args.lane,
        pulses=m['pulses'], max_width=m['max_width'], seconds=round(m['elapsed_seconds'], 1),
        commutations=[dict(kappa=p['kappa'][:8], widening=p['widening'][:10], fire=[x[:14] for x in p['fire']]) for p in proofs]), indent=1))


if __name__ == '__main__':
    main()
