A22 AFFINE FAST START v3.2 — FIRST LAUNCH (clean folder)

Experimental research engine, NOT a qualified all-trajectories proof.
No campaign, physical state or receipt is bundled. kernel/ is byte-identical
to every previous release (same physics, parameters, 18 layers, 12 lanes,
128 pulses spaced by 8, horizon 1116, Decimal precision 160).

The full guide is START_HERE_FR.txt (French). Short version:

  python -B verify_bundle.py
  python -B -m unittest discover -s tests          # 61 tests
  python -B run.py --out campaign_v32 --through 18 --workers 8 --zip-each-layer

On a refused cell (nothing is written into the campaign by these two):
  python -B replay_cell.py      --campaign campaign_v32 --layer L --lane J
  python -B tools/verif_h1h2.py --campaign campaign_v32 --layer L --lane J

Never run with python -O. Never edit the code during a campaign (program
identity is checked). Release notes and patches of v1–v3.2: historique/.
Independent H1/H2 check of this version: CONTROLE_H1_H2_v3_2.txt.
Scope and limits: AUDIT_EN.txt, MODEL_BOUNDARY_EN.txt.
