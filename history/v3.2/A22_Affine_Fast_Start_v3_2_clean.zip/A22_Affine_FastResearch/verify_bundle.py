"""Verify the distributed files before local rebuilds or edits."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST_SHA256.json').read_text())
bad=[]
for name,expected in manifest.items():
    p=root/name
    if not p.is_file():bad.append((name,'missing'));continue
    h=hashlib.sha256()
    with p.open('rb') as f:
        for part in iter(lambda:f.read(65536),b''):h.update(part)
    if h.hexdigest()!=expected:bad.append((name,'hash mismatch'))
if bad:
    print(json.dumps(bad,indent=2));sys.exit(1)
print('Verified',len(manifest),'distributed files. This is integrity, not mathematical qualification.')
