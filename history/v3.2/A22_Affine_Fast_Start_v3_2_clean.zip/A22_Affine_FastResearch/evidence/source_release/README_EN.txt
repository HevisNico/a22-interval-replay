A22 Affine Corrected Research Release

Start with START_HERE_EN.txt.

Contents
  kernel/              Original supplied physical/kernel files, unchanged.
  affine/engine.py     Corrected affine execution overlay; import-safe.
  affine/affine_iv.py  Affine arithmetic with explicit directed error bounds.
  affine/rounding.py   Readable Python reference for binary64 coefficient bounds.
  affine/rounding_native.c / _rounding_native*.so
                       Optional equivalent compiled coefficient primitives.
  affine/temporal.py   Creation identities, explicit copies and exact clocks.
  affine/decimal_cache.py
                       Bounded cache of scalar Decimal exp/ln results.
  affine/artifacts.py Exact typed DAG serialization; no pickle input.
  run.py               Two-worker runner, cell checkpoints, receipts, revalidation.
  build_native.py      Local build, no fast-math or contraction.
  tests/               Exact witnesses, differential tests and refusal tests.
  evidence/            Audit witnesses and measurements; not campaign inputs.
  AUDIT_EN.txt         Findings, fixes, arithmetic rationale and remaining scope.
  BENCHMARKS_EN.json    Measured timings and limits of comparisons.
  MANIFEST_SHA256.json / verify_bundle.py
                       Distribution file integrity checks.

The original kernel files being unchanged does not make the effective kernel
unchanged: the overlay replaces numerical arithmetic, time identity and selected
bounds. This is a new computational kernel and requires a fresh campaign.
Decimal centers use precision 160. Coefficients use binary64 with explicit
rounding/remainder enclosures; this is NOT 160-digit accuracy of every output.

Statuses deliberately say research_cell_complete / research_layer_complete.
They mean the implemented calculation and software consistency checks completed.
They are not mathematical certification of every admissible hybrid trajectory.
No claim of x10/x100 acceleration, layer-18 feasibility, or independent proof is
made by this release. See the actual measurements in BENCHMARKS_EN.json.
