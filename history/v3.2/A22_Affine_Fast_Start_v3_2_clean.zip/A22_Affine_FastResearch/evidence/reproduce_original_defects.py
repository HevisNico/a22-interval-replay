"""Reproduce failures of the SUPPLIED prototype, not of the corrected release."""
from pathlib import Path
import sys,importlib.util,json
from fractions import Fraction
from decimal import Decimal as D,localcontext
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'kernel/R_cycle_local_A20_2026-10-18'))
import intervalles_decimaux as iv
iv.configure(160)
# Reference source is a text attachment, loaded explicitly for this witness only.
source=(ROOT/'evidence/original_affine_iv.py.txt').read_text()
legacy={};exec(compile(source,'supplied_affine_iv','exec'),legacy)
I=legacy['I'];hull=legacy['hull'];results={}
d={'large':1.,**{str(i):2**-54 for i in range(95)}}
x=I.make(D(0),D(0),d,0.)
true=sum(map(Fraction.from_float,d.values()),Fraction(0))
results['underbounded_radius']=true>Fraction(x.hi)
x=I.symbol('x',1);z=hull([x,-x])-x
results['false_hull_correlation']=Fraction(z.lo)>-2*Fraction.from_float(x.d['x'])
y=-x+I('.1');z=I(min(x.lo,y.lo),min(x.hi,y.hi))-x
results['false_min_correlation']=Fraction(z.lo)>Fraction(1,10)-2*Fraction.from_float(x.d['x'])
legacy['install']()
import dependances_A17 as dep
x=dep.Time('same-label',I.symbol('independent-a',1));y=dep.Time('same-label',I.symbol('independent-b',1))
results['same_label_cancels_independent_dates']=x.minus(y).lo==x.minus(y).hi==0
with localcontext() as c:
 c.prec=28
 a=Fraction(D('1'));b=Fraction(D('1.000000000000000000000000000001'))
 results['rounded_constant_clock_collision']=D(a.numerator)/D(a.denominator)==D(b.numerator)/D(b.denominator)
results['history_repr_collision']=repr(I.symbol('a',1))==repr(I.symbol('b',1))
print(json.dumps(results,indent=2))
assert all(results.values()),'A reference witness no longer reproduces'
