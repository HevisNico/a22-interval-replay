"""Contrôle indépendant H1 / H2 sur UNE cellule d'une campagne (lecture seule).

Recalcule la cellule (couche, voie) à partir de la couche précédente VÉRIFIÉE
(empreintes contrôlées contre verification.json) et reprouve chaque décision
READY prise par le moteur avec mémoire d'impulsions, sans utiliser l'argument
de pic du moteur :
  tir          (H1) : Q0 < 1 avant la racine — prouvé par bissection jusqu'à un
                      point u, puis pente dQ0/dt > 0 de u à la racine ;
  pas de tir   (H2) : Q0 < 1 sur toute la fenêtre jusqu'à la frontière.
Q0 = charge contrefactuelle sans nouvel événement (dep.evaluate de la mémoire).
« non concluant » = encadrement trop large (pas un contre-exemple) ;
« contre-exemple » = morceau où Q0 >= 1 pour tous les paramètres : tir manqué.
N'écrit rien dans la campagne. Diagnostic, jamais un reçu.

    python -B tools/verif_h1h2.py --campaign DOSSIER --layer 18 --lane 4
Code de sortie : 0 si aucune décision non prouvée, 1 sinon.
"""
from pathlib import Path
import argparse, json, os, sys, tempfile, time
from collections import Counter
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'affine'))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--campaign', type=Path, required=True)
    ap.add_argument('--layer', type=int, required=True)
    ap.add_argument('--lane', type=int, required=True)
    args = ap.parse_args()
    if not __debug__: raise RuntimeError('Python -O is forbidden')
    if not 1 <= args.layer <= 18 or not 0 <= args.lane <= 11: ap.error('layer 1..18, lane 0..11')
    os.environ['A22_ARTIFACT_DIR'] = tempfile.mkdtemp(prefix='a22_h1h2_')
    from decimal import Decimal as D
    import engine, artifacts as a, temporal
    from affine_iv import I
    b = engine.b; dep = b.dep
    stats = Counter(); bad = []

    def below_one(mem, t0, lo0, hi0, depth=16):
        stack = [(lo0, hi0, 0)]; res = 'prouvé'
        while stack:
            lo, hi, n = stack.pop()
            q = dep.evaluate(mem, b.shift(t0, I(lo, hi), 'h1h2'))
            if q.hi < 1: continue
            if q.lo >= 1: return 'contre-exemple'
            if n >= depth or hi - lo < D('1e-12'): res = 'non concluant'; continue
            m = (lo + hi) / 2
            stack.append((m, hi, n + 1)); stack.append((lo, m, n + 1))
        return res

    def no_earlier_crossing(mem, t0, rlo, rhi):
        u = D(0); step = rlo
        while u < rlo:
            z = min(rlo, u + step)
            q = dep.evaluate(mem, b.shift(t0, I(u, z), 'h1h2'))
            if q.hi < 1: u = z; step *= 2; continue
            if q.lo >= 1: return 'contre-exemple'
            if dep.evaluate(mem, b.shift(t0, I(u, max(u, rhi)), 'h1h2'), True).lo > 0: return 'prouvé'
            step /= 2
            if step < D('1e-13'): return 'non concluant'
        return 'prouvé'

    orig = engine.orig_advance
    def checked(s, boundary, cell, count):
        out = orig(s, boundary, cell, count)
        if s['p'] != 0 or s.get('memory') is None: return out
        new, kind = out; t0 = s['t']; mem = s['memory']
        if kind == 'fire':
            r = new['t'].minus(t0)
            if r.lo > 0:
                v = no_earlier_crossing(mem, t0, r.lo, r.hi); stats['H1 tir : ' + v] += 1
                if v != 'prouvé': bad.append(dict(test='H1', compteur=count, racine=[str(x)[:14] for x in r.pair()], verdict=v))
        elif kind == 'external':
            H = boundary.minus(t0)
            if H.hi > 0:
                v = below_one(mem, t0, D(0), max(D(0), H.hi))
                if v == 'non concluant' and below_one(mem, t0, D(0), max(D(0), H.lo)) == 'prouvé' \
                        and dep.evaluate(mem, boundary).hi < 1:
                    v = 'prouvé'
                stats['H2 pas de tir : ' + v] += 1
                if v != 'prouvé': bad.append(dict(test='H2', compteur=count, fenetre=[str(x)[:14] for x in H.pair()], verdict=v))
        return out
    engine.orig_advance = checked

    camp = args.campaign.resolve()
    run_id = json.loads((camp / 'campaign.json').read_text())['run_id']
    if args.layer == 1:
        temporal.begin_producer(run_id + '/source')
        clock = temporal.Time('canonical-initial-clock', I(0))
        trains = [tuple(clock.plus(8 * k) for k in range(128))] + [()] * 11
    else:
        prev = camp / f'layer_{args.layer - 1:02d}'
        proof = json.loads((prev / 'verification.json').read_text())
        trains = []
        for j in range(12):
            if j not in {(args.lane - 1) % 12, args.lane, (args.lane + 1) % 12}:
                trains.append(()); continue
            d = prev / f'cell_{j:02d}'
            if a.file_hash(d / 'result.json') != proof['payloads'][j]:
                raise ValueError(f'couche {args.layer - 1} cellule {j} : contenu différent de sa vérification')
            trains.append(a.read(d / 'result.json', proof['payloads'][j])['outputs'])
    started = time.perf_counter()
    try:
        engine.compute_cell(args.layer, args.lane, trains, f'h1h2/{run_id}/cell/{args.layer}/{args.lane}')
        status = 'cellule calculée jusqu\'au bout'
    except Exception as e:
        status = f'cellule arrêtée ({type(e).__name__}) : décisions contrôlées jusqu\'à l\'arrêt'
    print(json.dumps(dict(couche=args.layer, voie=args.lane, statut=status, secondes=round(time.perf_counter() - started, 1),
                          decisions=dict(stats), non_prouvees=bad[:20]), ensure_ascii=False, indent=1))
    sys.exit(1 if bad else 0)


if __name__ == '__main__':
    main()
