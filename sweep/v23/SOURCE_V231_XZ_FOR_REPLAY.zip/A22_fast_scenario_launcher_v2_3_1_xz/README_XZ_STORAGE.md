# Scenario launcher v2.3.1 with xz storage

This is the scenario launcher v2.3.1 (`README.md`, source identity
`d892d7596ee22ad8875117be0a9c4a46ce3e1d0cb5c09494b6ad70d93d8ad2ce`) with one storage change.
The physics kernel, the affine arithmetic, the scheduler and the verification rules are unchanged.

## The change

`engine/affine/artifacts.py` writes every `result.json` payload xz-compressed (preset 6). The file
keeps its name. Its hash (`payload_sha256` in the receipt) is the SHA-256 of the **uncompressed**
canonical bytes, so it has the same meaning as in an uncompressed campaign. Reading is transparent:
a payload must be exactly one complete xz stream with nothing after it, or plain JSON; anything else
is refused with `artifact hash mismatch`. All other files (receipts, manifests, completion and
verification records, `campaign.json`) are written as before.

Why: at ε = 3e-3 the uncompressed outputs double in size from layer to layer (layer 14 alone is
7.5 GB), more than a cloud session's disk. xz divides the payload size by about 57.

The exact change is in [`CHANGES_XZ_STORAGE.diff`](CHANGES_XZ_STORAGE.diff): `artifacts.py`, one test
adapted (it altered a payload as text; it now alters its bytes) and one test added (a byte flipped
inside the xz stream, and a second stream appended, are both refused).

## Checks

- The 188 tests of v2.3.1 pass, plus the new one (189).
- A two-layer campaign at ε = 3e-3 with this package gives, for all 24 cells, the same terminal
  states (charges, gains, recovery, energy, phases) as the uncompressed v2.3.1 campaign.
- `tools/verify_package.py` now reports the three changed files: the manifest `MANIFEST_V23.json`
  describes the unmodified v2.3.1 package and is kept unchanged.

## Identity

The source identity changes, so this is a new program: campaigns of v2.3.1 cannot be resumed with
it, and its campaigns cannot be resumed with v2.3.1. Campaign started with it:

```
run_id          0c92786260c9482588c6403f7f1e1124
kernel_id       77974408551c93b53a735431add8c02d32ed13df13f2cb1c486ad05903d6955a
source_identity bc18c23f1f9468d126b593984d4523c63bbed7db061cff2f5092477bbeaca76f
epsilon         0.003, initial delta 1e-5
environment     Python 3.12.3, numpy 2.3.5, scipy 1.17.0, the two packaged native binaries
```

## Run

Linux x86-64, Python 3.12 with numpy 2.3.5 and scipy 1.17.0. The native binaries are included and
must not be rebuilt if a campaign is to be resumed (their hash is part of `kernel_id`).

```sh
cd engine
python -u -B launch_v2.py --out <new folder> --through 18 --epsilon 0.003 --workers <cores> --zip-every 0
```

Resume an interrupted campaign, same machine type, same Python version (3.12.3 for the campaign
above), unchanged files:

```sh
python -u -B run_scenarios.py --out <same folder> --through 18 --epsilon 0.003 --workers <cores>
```

To read a payload by hand: `xz -dc result.json > result_plain.json`, or in Python
`json.loads(lzma.decompress(open(p, 'rb').read()))`.
