"""Explicit fresh launch for Fast Scenario Launcher v2.1; never runs on import."""
from pathlib import Path
import argparse
import os
import sys


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',required=True,type=Path,help='A new campaign directory')
    parser.add_argument('--through',type=int,choices=range(1,19),default=18)
    parser.add_argument('--epsilon',default='0.01')
    parser.add_argument('--workers',type=int,choices=range(1,13),default=4)
    parser.add_argument('--zip-every',type=int,default=5)
    parser.add_argument('--wall-seconds',type=int,default=14400)
    parser.add_argument('--cpu-seconds',type=int,default=14400)
    parser.add_argument('--memory-mib',type=int,default=0)
    parser.add_argument('--max-histories',type=int,default=512)
    parser.add_argument('--max-jobs-per-cell',type=int,default=10000)
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    out=args.out.resolve()
    if out.exists():parser.error('Fresh output directory already exists; choose a new path')
    if min(args.wall_seconds,args.max_histories,args.max_jobs_per_cell)<=0 or min(args.cpu_seconds,args.memory_mib,args.zip_every)<0:
        parser.error('Invalid budgets')
    sys.path.insert(0,str(root/'affine'))
    from experiment_parameters import validate_epsilon
    epsilon=validate_epsilon(args.epsilon)
    print('Fast Scenario Launcher v2.1 — NEW canonical research campaign',flush=True)
    print('Output:',out,'epsilon:',epsilon,'through:',args.through,flush=True)
    command=[sys.executable,'-u','-B',str(root/'run_scenarios.py'),'--out',str(out),
             '--through',str(args.through),'--epsilon',epsilon]
    for name in ('workers','zip_every','wall_seconds','cpu_seconds','memory_mib','max_histories','max_jobs_per_cell'):
        command.extend(('--'+name.replace('_','-'),str(getattr(args,name))))
    os.execv(sys.executable,command)


if __name__=='__main__':main()
