"""Experimental campaign with compatible joint histories; no output-train unions."""
from pathlib import Path
import argparse, itertools, json, os, sys, time, uuid
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor, as_completed
import run

SCHEMA='A22-joint-scenario-campaign-1'

def join_contexts(contexts):
    result={}
    for context in contexts:
        for key,value in context.items():
            if key in result and result[key]!=value:return None
            result[key]=value
    return dict(sorted(result.items()))

def plan(cfg,n,lane,previous,a,max_jobs):
    if n==1:selections=[()]
    else:
        ports=[previous[j] for j in ((lane-1)%12,lane,(lane+1)%12)]
        selections=itertools.product(*ports)
    result=[]
    for selected in selections:
        context=join_contexts(x['context'] for x in selected)
        if context is None:continue
        case=dict(run_id=cfg['run_id'],kernel_id=cfg['kernel_id'],layer=n,lane=lane,
                  selected=list(selected),context=context)
        case['job_id']=a.canonical_hash(case)
        result.append(case)
        if len(result)>max_jobs:raise RuntimeError('Compatible-job budget exceeded; no jobs discarded')
    if not result:raise ValueError('No compatible parent selection')
    return result

def views(data):
    ss=data['scenarios']
    return dict(state=tuple(s['state'] for s in ss),emissions=tuple(s['outputs'] for s in ss),
        time_dependencies=tuple(tuple((t.token(),t.expression()) for t in s['outputs']) for s in ss),
        ancestry=(data['case'],tuple((s['id'],s['context'],s['conditions'],s['trace'],s['lineage']) for s in ss)),
        complete=data)

def digest_views(a,data):
    return a.digest_views(data,views)

def metadata(data):
    return [dict(id=s['id'],context=s['context']) for s in data['scenarios']]

def check_job(root,case,cfg,a):
    folder=job_folder(root,case)
    receipt=json.loads((folder/'receipt.json').read_text())
    if receipt['case']!=case or receipt['status']!='scenario_job_complete':raise ValueError('Wrong job receipt')
    data=a.read(folder/'result.json',receipt['payload_sha256'])
    if data['case']!=case or not data['scenarios']:raise ValueError('Wrong or empty job cover')
    if digest_views(a,data)!=receipt['views']:raise ValueError('Scenario view mismatch')
    if metadata(data)!=receipt['scenarios']:raise ValueError('Scenario catalogue mismatch')
    key=f"{cfg['run_id']}/cell/{case['layer']}/{case['lane']}"
    for i,s in enumerate(data['scenarios']):
        sid=a.canonical_hash(dict(job=case['job_id'],terminal=i))
        if s['id']!=sid or s['context']!={**case['context'],key:sid}:raise ValueError('Broken scenario ancestry')
    return receipt

def job_folder(root,case):
    return root/f"layer_{case['layer']:02d}"/f"cell_{case['lane']:02d}"/case['job_id']

def worker(root_string,cfg,case):
    root=Path(root_string);folder=job_folder(root,case);folder.mkdir(parents=True,exist_ok=True)
    e,a,t=run.initialize(folder/'diagnostics')
    if run.identity()!=cfg['source_identity']:raise ValueError('Source changed before job')
    if (folder/'receipt.json').exists():return check_job(root,case,cfg,a)
    started=time.perf_counter()
    try:
        import resource
        limits=cfg['limits']
        if limits['memory_mib']:
            size=limits['memory_mib']*1024*1024;resource.setrlimit(resource.RLIMIT_AS,(size,size))
        if limits['cpu_seconds']:resource.setrlimit(resource.RLIMIT_CPU,(limits['cpu_seconds'],limits['cpu_seconds']))
        if case['layer']==1:trains=run.initial_trains(cfg['run_id'],t)
        else:
            trains=[() for _ in range(12)]
            for lane,selected in zip(((case['lane']-1)%12,case['lane'],(case['lane']+1)%12),case['selected']):
                rp=root/selected['receipt_path']
                if a.file_hash(rp)!=selected['receipt_sha256']:raise ValueError('Changed parent receipt')
                r=json.loads(rp.read_text());parent=r['case']
                if any(parent[k]!=v for k,v in dict(run_id=cfg['run_id'],kernel_id=cfg['kernel_id'],layer=case['layer']-1,lane=lane).items()):
                    raise ValueError('Wrong parent identity')
                if r['payload_sha256']!=selected['payload_sha256']:raise ValueError('Wrong parent digest')
                data=a.read(root/selected['payload_path'],r['payload_sha256'])
                scenario=data['scenarios'][selected['scenario_index']]
                if scenario['id']!=selected['id'] or scenario['context']!=selected['context']:raise ValueError('Wrong parent scenario')
                trains[lane]=scenario['outputs']
        import scenario_engine
        physical=f"{cfg['run_id']}/cell/{case['layer']}/{case['lane']}"
        result=scenario_engine.compute(e,t,case['layer'],case['lane'],trains,
            physical+'/job/'+case['job_id'],physical,limits['wall_seconds'],limits['histories'])
        if result['status']!='complete':
            a.write_checked(folder/'refused_frontier.json',result)
            raise RuntimeError(result['reason'])
        ss=[]
        for i,s in enumerate(result['scenarios']):
            sid=a.canonical_hash(dict(job=case['job_id'],terminal=i))
            ss.append(dict(s,id=sid,context={**case['context'],physical:sid}))
        data=dict(case=case,scenarios=tuple(ss),metrics=result['metrics'])
        sha,check,before=a.write_checked_views(folder/'result.json',data,views)
        if run.identity()!=cfg['source_identity']:raise ValueError('Source changed during job')
        r=dict(status='scenario_job_complete',case=case,payload_sha256=sha,
            scenarios=metadata(data),views=before,serialization_check=check,
            elapsed_seconds=time.perf_counter()-started)
        a.atomic_json(folder/'receipt.json',r)
        return r
    except BaseException as exc:
        import traceback
        a.atomic_json(folder/'refusal.json',dict(status='not_certified',case=case,
            reason=str(exc),traceback=traceback.format_exc()))
        raise

def catalogue(root,cases,receipts,a):
    row=[]
    for case,r in zip(cases,receipts):
        folder=job_folder(root,case)
        for i,s in enumerate(r['scenarios']):
            row.append(dict(s,receipt_path=str((folder/'receipt.json').relative_to(root)),
                receipt_sha256=a.file_hash(folder/'receipt.json'),
                payload_path=str((folder/'result.json').relative_to(root)),
                payload_sha256=r['payload_sha256'],scenario_index=i))
    return row

def sealed_layer(root,cfg,layer,manifest,cases,a):
    """Reuse a checked decision only for the same source and exact bytes.

    A new process still hashes every receipt and scientific payload. Modified
    size/mtime alone is never evidence. The immediately preceding proof is
    bound by complete.json and by the current campaign/kernel identity.
    """
    folder=root/f'layer_{layer:02d}'
    seal=json.loads((folder/'complete.json').read_text())
    if seal['status']!='research_scenario_layer_complete':raise ValueError('Unaccepted ancestor layer')
    if a.file_hash(folder/'manifest.json')!=seal['manifest_sha256'] or a.file_hash(folder/'verification.json')!=seal['verification_sha256']:
        raise ValueError('Ancestor proof or catalogue changed')
    proof=json.loads((folder/'verification.json').read_text())
    if any(proof[k]!=v for k,v in dict(run_id=cfg['run_id'],kernel_id=cfg['kernel_id'],through=layer).items()):
        raise ValueError('Ancestor verification identity mismatch')
    hashes=[a.file_hash(job_folder(root,c)/'receipt.json') for c in cases]
    if hashes!=proof['receipts']:raise ValueError('Ancestor receipt changed')
    receipts=[]
    for case in cases:
        folder=job_folder(root,case)
        r=json.loads((folder/'receipt.json').read_text())
        if r['case']!=case or r['status']!='scenario_job_complete':raise ValueError('Wrong ancestor job')
        if a.file_hash(folder/'result.json')!=r['payload_sha256']:raise ValueError('Ancestor payload changed')
        receipts.append(r)
    return receipts

_VERIFY_CONTEXT = None

def initialize_verifier(root_string,cfg):
    """Each spawned checker imports its own typed reader and numerical modules."""
    global _VERIFY_CONTEXT
    epsilon=cfg['parameters']['epsilon_relative']
    os.environ['A22_PHYSICAL_EPSILON']=epsilon
    root=Path(root_string)
    if run.identity()!=cfg['source_identity']:
        raise ValueError('Source changed before verifier imports')
    _,a,_=run.initialize(root/'diagnostics'/'verification')
    if run.identity()!=cfg['source_identity']:
        raise ValueError('Source changed before independent verification')
    _VERIFY_CONTEXT=(root,cfg,a)

def verify_job_in_process(case):
    if _VERIFY_CONTEXT is None:raise RuntimeError('Uninitialized independent verifier')
    root,cfg,a=_VERIFY_CONTEXT
    return check_job(root,case,cfg,a)

def verify_jobs(root,cfg,cases,a,workers=1):
    """All checks are unchanged; only independent job checks are concurrent.

    map preserves planned case order. A failed read, view, ancestry or child
    process aborts the whole operation before any layer proof is written.
    The reference single-process path remains available.
    """
    if type(workers) is not int or not 1<=workers<=12:
        raise ValueError('Verification workers must be 1..12')
    source=cfg.get('source_identity')
    if source is not None and run.identity()!=source:
        raise ValueError('Source changed before independent verification')
    if workers==1 or len(cases)<2:
        receipts=[check_job(root,c,cfg,a) for c in cases]
    else:
        if source is None:raise ValueError('Parallel verification requires frozen source identity')
        with ProcessPoolExecutor(max_workers=min(workers,len(cases)),
                mp_context=mp.get_context('spawn'),initializer=initialize_verifier,
                initargs=(str(root),cfg)) as pool:
            receipts=list(pool.map(verify_job_in_process,cases,chunksize=1))
    if source is not None and run.identity()!=source:
        raise ValueError('Source changed during independent verification')
    return receipts

def verify_prefix(root,cfg,n,a,workers=1):
    previous=None
    for layer in range(1,n+1):
        manifest=json.loads((root/f'layer_{layer:02d}'/'manifest.json').read_text())
        if manifest['run_id']!=cfg['run_id'] or manifest['kernel_id']!=cfg['kernel_id']:raise ValueError('Wrong layer identity')
        rows=[];all_cases=[];hashes=[];planned=[]
        for lane in range(12):
            cases=plan(cfg,layer,lane,previous,a,cfg['limits']['jobs_per_cell'])
            if manifest['jobs'][lane]!=[c['job_id'] for c in cases]:raise ValueError('Missing or extra compatible job')
            planned.append(cases);all_cases.extend(cases)
        sealed=(sealed_layer(root,cfg,layer,manifest,all_cases,a) if layer<n
                else verify_jobs(root,cfg,all_cases,a,workers))
        offset=0
        for cases in planned:
            receipts=sealed[offset:offset+len(cases)]
            offset+=len(cases)
            rows.append(catalogue(root,cases,receipts,a))
            hashes.extend(a.file_hash(job_folder(root,c)/'receipt.json') for c in cases)
        if rows!=manifest['scenarios']:raise ValueError('Layer scenario catalogue changed')
        previous=rows
    proof=dict(run_id=cfg['run_id'],kernel_id=cfg['kernel_id'],through=n,
        manifest_sha256=a.file_hash(root/f'layer_{n:02d}'/'manifest.json'),receipts=hashes)
    a.atomic_json(root/f'layer_{n:02d}'/'verification.json',proof)
    return previous

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',required=True,type=Path);ap.add_argument('--through',required=True,type=int)
    ap.add_argument('--epsilon',default='0.01');ap.add_argument('--workers',default=4,type=int,choices=range(1,13))
    ap.add_argument('--wall-seconds',default=14400,type=int);ap.add_argument('--cpu-seconds',default=14400,type=int)
    ap.add_argument('--memory-mib',default=0,type=int);ap.add_argument('--max-histories',default=512,type=int)
    ap.add_argument('--max-jobs-per-cell',default=10000,type=int);ap.add_argument('--zip-every',default=5,type=int)
    ap.add_argument('--verify-layer',type=int)
    args=ap.parse_args()
    if not 1<=args.through<=18:ap.error('--through must be 1..18')
    if min(args.wall_seconds,args.max_histories,args.max_jobs_per_cell)<=0 or min(args.cpu_seconds,args.memory_mib,args.zip_every)<0:
        ap.error('invalid budgets')
    from experiment_parameters import validate_epsilon
    epsilon=validate_epsilon(args.epsilon);os.environ['A22_PHYSICAL_EPSILON']=epsilon
    import experiment_parameters
    experiment_parameters.PHYSICAL_EPSILON=epsilon
    root=args.out.resolve();root.mkdir(parents=True,exist_ok=True)
    import fcntl
    with (root/'scenario_controller.lock').open('a+') as lock:
        if not args.verify_layer:fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        e,a,t=run.initialize(root/'diagnostics')
        import platform,importlib.metadata as md,rounding
        env=dict(python=platform.python_version(),numpy=md.version('numpy'),scipy=md.version('scipy'),backend=rounding.BACKEND)
        if rounding.BACKEND=='native':
            import _rounding_native
            env['native_sha256']=a.file_hash(_rounding_native.__file__)
        limits=dict(wall_seconds=args.wall_seconds,cpu_seconds=args.cpu_seconds,memory_mib=args.memory_mib,
            histories=args.max_histories,jobs_per_cell=args.max_jobs_per_cell)
        binding=dict(source_identity=run.identity(),environment=env,parameters=dict(epsilon_relative=epsilon,initial_delta='1e-5'),
            precision=160,kmax=run.affine_iv_kmax(),limits=limits,schema=SCHEMA)
        kernel=a.canonical_hash(binding);path=root/'campaign.json'
        if path.exists():
            cfg=json.loads(path.read_text())
            if cfg.get('schema')!=SCHEMA or cfg['kernel_id']!=kernel:raise ValueError('Changed engine, environment or options; use a new campaign directory')
        else:
            if args.verify_layer:raise ValueError('Missing campaign configuration')
            cfg=dict(binding,run_id=uuid.uuid4().hex,kernel_id=kernel,scientific_status='experimental_not_qualified')
            a.atomic_json(path,cfg)
        if args.verify_layer:
            verify_prefix(root,cfg,args.verify_layer,a,args.workers);print('SCENARIO PREFIX VERIFIED',args.verify_layer,flush=True);return
        previous=None;first=1
        for n in range(1,args.through+1):
            folder=root/f'layer_{n:02d}';folder.mkdir(exist_ok=True)
            if not (folder/'complete.json').exists():break
            previous=verify_prefix(root,cfg,n,a,args.workers);print('REUSED SCENARIO LAYER',n,flush=True);first=n+1
        if first<=args.through:dataflow(root,cfg,a,args,epsilon,first,previous)

def dataflow(root,cfg,a,args,epsilon,first,previous):
    """v2.3 scheduler. A cell (n,j) is planned as soon as its three parent
    lanes (n-1,j-1..j+1) have all their jobs complete, without waiting for
    the rest of layer n-1. Ready jobs run lowest layer first, then the most
    expensive parent lane first. Each layer is still accepted exactly as in
    v2.1: complete manifest, fresh independent verification subprocess of
    the whole prefix, then complete.json. Verifications run one layer at a
    time, in order, while later jobs keep computing. A child job computed
    before its parent layer is accepted is only a job; its layer can never be
    accepted before every ancestor layer is.
    """
    import subprocess
    from concurrent.futures import wait,FIRST_COMPLETED
    kernel=cfg['kernel_id'];through=args.through
    rows={}            # (n,lane) -> catalogue of a finished lane
    planned={}         # (n,lane) -> planned cases
    left={}            # (n,lane) -> job ids still running or queued
    done={}            # job_id -> verified-by-hash worker receipt
    cost={}            # (n,lane) -> summed job seconds, for priorities
    started={};finished={}
    if previous is not None:
        for lane,row in enumerate(previous):
            rows[(first-1,lane)]=row
            seconds=0.0
            for path in sorted({x['receipt_path'] for x in row}):
                seconds+=json.loads((root/path).read_text()).get('elapsed_seconds',0.0)
            cost[(first-1,lane)]=seconds
    ready=[]
    def plannable(n,lane):
        if (n,lane) in planned or n>through:return False
        if n==1:return True
        return all(((n-1,j)) in rows for j in ((lane-1)%12,lane,(lane+1)%12))
    def plan_lane(n,lane):
        if n==1:prev=None
        else:
            prev=[None]*12
            for j in ((lane-1)%12,lane,(lane+1)%12):prev[j]=rows[(n-1,j)]
        cases=plan(cfg,n,lane,prev,a,args.max_jobs_per_cell)
        planned[(n,lane)]=cases;left[(n,lane)]={c['job_id'] for c in cases}
        (root/f'layer_{n:02d}').mkdir(exist_ok=True)
        estimate=max(cost.get((n-1,j),0.0) for j in ((lane-1)%12,lane,(lane+1)%12))
        for c in cases:ready.append(((n,-estimate,lane),c))
    def plan_new():
        for n in range(first,through+1):
            for lane in range(12):
                if plannable(n,lane):plan_lane(n,lane)
    verifying=None;next_verify=first;proc=None;verify_start=None
    def layer_done(n):return all((n,lane) in rows for lane in range(12))
    def start_verification(n):
        lanes=[planned[(n,lane)] for lane in range(12)]
        a.atomic_json(root/f'layer_{n:02d}'/'manifest.json',dict(run_id=cfg['run_id'],kernel_id=kernel,
            jobs=[[c['job_id'] for c in row] for row in lanes],scenarios=[rows[(n,lane)] for lane in range(12)]))
        cmd=[sys.executable,'-B',str(Path(__file__).resolve()),'--out',str(root),'--through',str(n),
            '--epsilon',epsilon,'--verify-layer',str(n),'--workers',str(args.workers),
            '--wall-seconds',str(args.wall_seconds),
            '--cpu-seconds',str(args.cpu_seconds),'--memory-mib',str(args.memory_mib),
            '--max-histories',str(args.max_histories),'--max-jobs-per-cell',str(args.max_jobs_per_cell)]
        return subprocess.Popen(cmd)
    current=first
    try:
        plan_new()
        with ProcessPoolExecutor(max_workers=args.workers,mp_context=mp.get_context('spawn'),max_tasks_per_child=1) as pool:
            running={}
            while True:
                while ready and len(running)<args.workers:
                    ready.sort(key=lambda x:x[0]);_,c=ready.pop(0)
                    started.setdefault(c['layer'],time.perf_counter())
                    running[pool.submit(worker,str(root),cfg,c)]=c
                if proc is None and next_verify<=through and layer_done(next_verify):
                    current=next_verify;verify_start=time.perf_counter();proc=start_verification(next_verify)
                if proc is not None and proc.poll() is not None:
                    n=next_verify
                    if proc.returncode!=0:raise RuntimeError(f'Independent verification of layer {n} failed')
                    if run.identity()!=cfg['source_identity']:raise ValueError('Engine changed during layer')
                    folder=root/f'layer_{n:02d}';now=time.perf_counter()
                    a.atomic_json(folder/'complete.json',dict(status='research_scenario_layer_complete',layer=n,
                        compute_seconds=finished[n]-started[n],verification_seconds=now-verify_start,
                        elapsed_seconds=now-started[n],jobs=sum(len(planned[(n,l)]) for l in range(12)),
                        histories=sum(len(rows[(n,l)]) for l in range(12)),
                        manifest_sha256=a.file_hash(folder/'manifest.json'),verification_sha256=a.file_hash(folder/'verification.json'),
                        scheduler='dataflow-v2.3',scientific_status='experimental_not_qualified'))
                    print('SCENARIO LAYER',n,'COMPLETE',round(now-started[n],3),'s',flush=True)
                    if args.zip_every and (n%args.zip_every==0 or n==through):print('ZIP',run.zip_run(root,n),flush=True)
                    proc=None;next_verify+=1;current=next_verify
                    if next_verify>through:break
                    continue
                if not running:
                    if proc is None and not ready and not layer_done(next_verify):
                        raise RuntimeError('Scheduler stalled before layer %d'%next_verify)
                    time.sleep(0.5);continue
                finished_set,_=wait(list(running),timeout=1.0,return_when=FIRST_COMPLETED)
                for future in finished_set:
                    c=running.pop(future);current=c['layer']
                    r=future.result()
                    # Bind the worker receipt to its exact bytes, as in v2.1.
                    if a.file_hash(job_folder(root,c)/'receipt.json')!=a.canonical_hash(r):
                        raise ValueError('Worker receipt changed before planning')
                    done[c['job_id']]=r;key=(c['layer'],c['lane'])
                    left[key].discard(c['job_id'])
                    cost[key]=cost.get(key,0.0)+r['elapsed_seconds']
                    print('SCENARIO JOB',c['layer'],c['lane'],c['job_id'][:12],'COMPLETE',round(r['elapsed_seconds'],3),'s;',len(r['scenarios']),'histories',flush=True)
                    if not left[key]:
                        cases=planned[key]
                        rows[key]=catalogue(root,cases,[done[x['job_id']] for x in cases],a)
                        if layer_done(c['layer']):finished[c['layer']]=time.perf_counter()
                        plan_new()
    except BaseException as exc:
        if proc is not None and proc.poll() is None:proc.terminate()
        a.atomic_json(root/f'layer_{current:02d}'/'stopped.json',dict(status='not_certified',reason=str(exc)))
        raise

if __name__=='__main__':main()
