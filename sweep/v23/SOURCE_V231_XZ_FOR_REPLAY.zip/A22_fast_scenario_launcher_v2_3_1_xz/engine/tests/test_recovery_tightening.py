"""Independent scalar witnesses and fail-closed recovery acceptance."""
from pathlib import Path
import os
import sys
import unittest
from decimal import Decimal as D, localcontext
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'affine'))
os.environ.setdefault('A22_ARTIFACT_DIR', str(ROOT / 'test_diagnostics'))
import engine
import affine_iv as af
import temporal
import recovery_tightening as tighten
import recovery_group
import cycle_local_A20 as cycle
import cycle_relatif_A22 as relative

b = engine.b


class MonotoneContraction(unittest.TestCase):
    def setUp(self):
        name = 'tightening-test/' + self._testMethodName
        temporal.begin_producer(name)
        af.FRESH = name + ':remainder'
        af._COUNTER[0] = 0
        engine.settings_cell(name)

    def test_contraction_contains_constant_rate_roots_at_all_corners(self):
        fire = temporal.Time('fire', af.I(10) + af.I.symbol('shared-fire', '.1'))
        rate = af.I('.25') + af.I.symbol('rate', '.05')
        state = dict(fire=fire, actuation=(b.ac.History(rate, fire=fire),))
        original = temporal.Time('broad-certified-return', af.I(10, 20))
        with patch('branche_retour_A19.return_with_marks', return_value=original):
            result = tighten.contract_return(b, state, 'test')
        self.assertLess(result.box().width(), original.box().width() / 4)
        self.assertEqual(result.expression(), original.expression())
        with localcontext() as ctx:
            ctx.prec = 250
            for f in (D('9.9'), D(10), D('10.1')):
                for rate_value in (D('.2'), D('.25'), D('.3')):
                    exact = f + 1 + D('2.5').ln() / rate_value
                    self.assertLessEqual(result.box().lo, exact)
                    self.assertGreaterEqual(result.box().hi, exact)

    def test_zero_budget_keeps_original_bounds_and_expression(self):
        original = temporal.Time('original', af.I(12, 16))
        with patch('branche_retour_A19.return_with_marks', return_value=original):
            result = tighten.contract_return(b, {}, 'test', steps=0)
        self.assertEqual(result.box().pair(), original.box().pair())
        self.assertEqual(result.expression(), original.expression())

    def test_indeterminate_signs_cannot_contract(self):
        original = temporal.Time('original', af.I(12, 16))
        with patch('branche_retour_A19.return_with_marks', return_value=original), \
             patch.object(b.ac, 'bounds', return_value=af.I(-1, 1)):
            result = tighten.contract_return(b, {'actuation': ()}, 'test')
        self.assertEqual(result.box().pair(), original.box().pair())


class AllBranchesRequired(unittest.TestCase):
    def test_tightened_forest_with_any_fire_or_nonready_branch_is_declined(self):
        for branches in ((), ((0, ()), (1, ('fire',))), ((0, ()), (2, ()))):
            forest = SimpleNamespace(branches=tuple(
                SimpleNamespace(state=dict(p=p), emissions=e) for p, e in branches))
            with self.subTest(branches=branches), \
                 patch('retour_file_A22.pending_window', return_value=(forest, 2, (1, 2))):
                self.assertIsNone(tighten.window(b, {}, (), 0, 'test', 0))

    def test_ambiguous_tightening_keeps_refusal(self):
        with patch('retour_file_A22.pending_window', side_effect=b.v.Ambiguous('unsupported')):
            self.assertIsNone(tighten.window(b, {}, (), 0, 'test', 0))

    def test_invariant_errors_are_not_swallowed(self):
        with patch('retour_file_A22.pending_window', side_effect=AssertionError('invariant')):
            with self.assertRaisesRegex(AssertionError, 'invariant'):
                tighten.window(b, {}, (), 0, 'test', 0)

    def test_existing_success_does_not_invoke_fallback(self):
        forest = SimpleNamespace(branches=(SimpleNamespace(state=dict(p=0), emissions=()),), certificate={})
        with patch.object(cycle, 'pending_window', return_value=(forest, 2, (1,))), \
             patch.object(b, 'join_states', return_value=dict(p=0, memory=object())), \
             patch.object(b, 'PROFILE', None), patch.object(tighten, 'window') as fallback:
            self.assertIsNotNone(recovery_group.resolve(b, dict(p=2), (), 0, 'test', 0))
            fallback.assert_not_called()

    def test_tightened_join_reanchors_even_if_time_tokens_match(self):
        rejected = SimpleNamespace(branches=(SimpleNamespace(state=dict(p=1), emissions=('fire',)),))
        accepted = SimpleNamespace(branches=(SimpleNamespace(state=dict(p=0), emissions=()),), certificate={})
        old_memory, new_memory = object(), object()
        with patch.object(cycle, 'pending_window', return_value=(rejected, 2, (1,))), \
             patch.object(tighten, 'window', return_value=(accepted, 2, (1,))), \
             patch.object(b, 'join_states', return_value=dict(p=0, memory=old_memory)), \
             patch.object(b, 'new_memory', return_value=new_memory) as rebuild, \
             patch.object(b, 'PROFILE', None):
            result = recovery_group.resolve(b, dict(p=2), (), 0, 'test', 0)
        self.assertIs(result[0]['memory'], new_memory)
        rebuild.assert_called_once()


class WeakOrderContraction(unittest.TestCase):
    def setUp(self):
        ns = 'order-contraction/' + self._testMethodName
        temporal.begin_producer(ns)
        af.FRESH = ns + ':remainder'
        af._COUNTER[0] = 0
        engine.settings_cell(ns)

    def exercise(self, previous, following):
        start = temporal.Time('start', af.I(1))
        coarse = temporal.Time('coarse', af.I('1.8', '2.8'))
        ready = temporal.Time('return', af.I('1.85', '2.75'))
        first = (temporal.Time('previous', af.I(*previous)), [('raw_on', 0, None)])
        last = (temporal.Time('following', af.I(*following)), [('raw_off', 0, None)])
        order = (first, (coarse, [('principal_ready', -1, None)]), last)
        state = dict(t=start, p=2, q=af.I('.2'), aux=[0]*3, raw=[None]*3)
        captured = []
        def reopen(s, t):
            captured.append(t)
            return dict(s, t=t, p=0)
        with patch.object(relative, 'no_new_fire_bound', return_value={}), \
             patch.object(b, 'admissible_orders', return_value=(order,)), \
             patch.object(b, 'possible_order', return_value=True), \
             patch.object(b, 'flowing', side_effect=lambda s,t,*args: dict(s,t=t)), \
             patch.object(b, 'act', side_effect=lambda s,a:s), \
             patch.object(b, 'reopen', side_effect=reopen), \
             patch.object(relative, '_until', side_effect=lambda x,t,key:[x]):
            forest = relative.resolve(state, (first,last), D(3), coarse, 'test', 0,
                return_solver=lambda s,key:ready, contract_order=True)
        return captured, forest, ready

    def test_necessary_neighbor_bounds_contract_and_keep_shared_expression(self):
        captured, forest, original = self.exercise(('1.9','2.1'), ('2.4','2.6'))
        self.assertEqual(len(captured), 1)
        self.assertEqual(captured[0].box().pair(), af.I('1.9','2.6').pair())
        self.assertEqual(captured[0].expression(), original.expression())
        self.assertEqual(len(forest.branches), 1)

    def test_weak_equality_is_retained(self):
        captured, forest, _ = self.exercise(('2.2','2.4'), ('2.0','2.2'))
        self.assertEqual(captured[0].box().pair(), af.I('2.2').pair())
        self.assertEqual(len(forest.branches), 1)

    def test_only_empty_conditional_interval_is_pruned(self):
        with self.assertRaisesRegex(b.v.Ambiguous, 'No local-cycle branch'):
            self.exercise(('2.7','2.8'), ('2.4','2.6'))


if __name__ == '__main__':
    unittest.main()
