import ast,sys,unittest,random
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'affine'))
import engine as e, temporal, affine_iv as af
from event_order_cache import admissible_orders

def reference():
    source=Path(e.b.__file__).read_text()
    node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='admissible_orders')
    ns=dict(e.b.__dict__);exec(ast.get_source_segment(source,node),ns)
    return ns['admissible_orders']

class EventOrderTests(unittest.TestCase):
    def test_exact_order_sequence_on_correlated_fixtures(self):
        old=reference();rng=random.Random(22)
        for trial in range(30):
            temporal.begin_producer('order-test/'+str(trial));af.FRESH=None
            start=temporal.Time('start',af.I(0))
            shared=af.I.symbol('shared','.2')
            events=[]
            for j in range(3):
                origin=temporal.Time('same-label',af.I(str(rng.uniform(.3,.9)))+shared+af.I.symbol('port'+str(j),'.05'))
                events.extend([(origin,[('raw_on',j,origin)]),(origin.plus('.4'),[('raw_off',j,origin)])])
            s={'t':start,'aux':[0]*3,'raw':[None]*3}
            self.assertEqual(list(old(s,events)),list(admissible_orders(e.b,s,events)))

    def test_budget_refusal_preserved(self):
        temporal.begin_producer('budget');af.FRESH=None
        start=temporal.Time('start',af.I(0))
        events=[(temporal.Time(str(j),af.I('.2','.4')),[('raw_on',j,None)]) for j in range(3)]
        s={'t':start,'aux':[0]*3,'raw':[None]*3}
        for call in (lambda:list(reference()(s,events,1)),lambda:list(admissible_orders(e.b,s,events,1))):
            with self.assertRaisesRegex(e.v.Ambiguous,'admissible event-order budget exceeded'):call()

if __name__=='__main__':unittest.main()
