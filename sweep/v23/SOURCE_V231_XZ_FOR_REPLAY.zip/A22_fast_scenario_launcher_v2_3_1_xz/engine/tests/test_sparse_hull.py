from pathlib import Path
import sys,unittest,random,math
from fractions import Fraction as F
from decimal import Decimal as D
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'affine'))
import engine,affine_iv as af
import sparse_hull as sh

class SparseHullTests(unittest.TestCase):
    def test_pointwise_enclosure_exact_rationals(self):
        old=(af.FRESH,af.KMAX);af.FRESH=None
        rng=random.Random(2210)
        try:
            for cap in (3,256):
                af.KMAX=cap
                for trial in range(40):
                    values=[]
                    for j in range(12):
                        lo=D(rng.randrange(-30,30))/D(16)
                        d={str(k):rng.uniform(-1,1) for k in rng.sample(range(50),8)}
                        values.append(af._new_form(af.I,lo,lo+D('.125'),d,2.0**-40))
                    out=sh.hull(values)
                    for x in values:
                        residual=F(x.e)+sum(abs(F(x._d.get(k,0.0))-F(out._d.get(k,0.0))) for k in x._d.keys()|out._d.keys())
                        self.assertLessEqual(F(out.clo)-F(out.e),F(x.clo)-residual)
                        self.assertGreaterEqual(F(out.chi)+F(out.e),F(x.chi)+residual)
        finally:af.FRESH,af.KMAX=old

    def test_exact_missing_mass_including_subnormals(self):
        numbers=[0.0,-0.0,math.ulp(0.0),1e-300,.1,.2,1e100]
        units=sum(sh.mass_units(x) for x in numbers)
        exact=sum(abs(F(x)) for x in numbers)
        self.assertEqual(F(units,sh.SCALE),exact)
        upper=sh.upward_mass(units)
        self.assertGreaterEqual(F(upper),exact)
        self.assertLess(F(math.nextafter(upper,-math.inf)),exact)

    def test_identity_and_empty(self):
        x=af.I('.25');self.assertIs(sh.hull([x,x]),x)
        with self.assertRaises(ValueError):sh.hull([])

if __name__=='__main__':unittest.main()
