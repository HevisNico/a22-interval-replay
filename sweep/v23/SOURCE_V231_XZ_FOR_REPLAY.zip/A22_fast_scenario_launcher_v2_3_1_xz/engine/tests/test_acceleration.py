"""Differential checks: exact coefficients, payload bytes and transfer replay."""
from pathlib import Path
import sys, unittest, random, json, math
from decimal import Decimal as D, Inexact, Rounded
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'affine'))
import engine as e, affine_iv as af, temporal as t, temporal_memo as tm
import transfer_memo as memo, rounding, artifacts
from actuations_A19 import Segment
from time_sum import sum_atoms

def snapshot(x):
    return (str(x.clo), str(x.chi), tuple((k,v.hex()) for k,v in x._d.items()), x.e.hex())

class AccelerationTests(unittest.TestCase):
    def setUp(self):
        self.old=(af.FRESH, af.KMAX, af.ETHRESH, tm.ENABLED, memo.ENABLED,
                  memo.MAX_ENTRIES, memo.MAX_COEFFICIENTS)
        af.FRESH='acceleration:remainder'; af._COUNTER[0]=0
        af.KMAX=16; af.ETHRESH=1e-14; tm.ENABLED=False; memo.ENABLED=True
        memo.clear(); t.begin_producer('acceleration')
    def tearDown(self):
        (af.FRESH, af.KMAX, af.ETHRESH, tm.ENABLED, memo.ENABLED,
         memo.MAX_ENTRIES, memo.MAX_COEFFICIENTS)=self.old
        memo.clear(); tm.clear()
    def test_accumulator_matches_copying_with_subnormals_and_signed_zero(self):
        rng=random.Random(654)
        values=[0.,-0.,math.ulp(0.),-math.ulp(0.),1e-300,-1e-300,1.,-1.]
        a={}; b={}
        for _ in range(150):
            d={str(rng.randrange(50)):rng.choice(values) for _ in range(20)}
            before=list(d.items()); b, expected=rounding.add_coeff(b,d)
            actual=rounding.accumulate_coeff(a,d)
            self.assertEqual([(k,v.hex()) for k,v in a.items()],[(k,v.hex()) for k,v in b.items()])
            self.assertEqual(actual.hex(),expected.hex()); self.assertEqual(before,list(d.items()))
        with self.assertRaises(ValueError):rounding.accumulate_coeff(a,a)
        with self.assertRaises(ArithmeticError):rounding.accumulate_coeff({}, {'bad':math.inf})
    def test_time_sum_preserves_names_order_and_allocator(self):
        rng=random.Random(912)
        vals=[af.I.make(D('.123'),D('.124'),{str(j):rng.uniform(-.1,.1) for j in range(24)},.001) for _ in range(5)]
        atoms=list(zip([1,-1,0,2,-3],vals))
        af._COUNTER[0]=100
        lo=hi=D('.01'); coeff={}; error=0.
        for n,v in atoms:
            if not n:continue
            if n==1:vl,vh,vd,ve=v.clo,v.chi,v._d,v.e
            elif n==-1:vl,vh=v.chi.copy_negate(),v.clo.copy_negate();vd,_=rounding.scale_coeff(v._d,-1.);ve=v.e
            else:
                q=n*v;vl,vh,vd,ve=q.clo,q.chi,q._d,q.e
            lo=e.iv.DOWN.add(lo,vl);hi=e.iv.UP.add(hi,vh)
            coeff,err=rounding.add_coeff(coeff,vd)
            error=rounding.add_up(rounding.add_up(error,ve),err)
        expected=af.I.make(lo,hi,coeff,error); end=af._COUNTER[0]
        af._COUNTER[0]=100;actual=sum_atoms(D('.01'),atoms)
        self.assertEqual(snapshot(expected),snapshot(actual));self.assertEqual(af._COUNTER[0],end)
    def test_batched_time_sum_randomized_against_python(self):
        from time_sum import _reference_sum_atoms
        rng=random.Random(3829)
        af.FRESH=None
        vals=[af.I.make(D('0.1234567890123456789'),D('.124'),
                       {str(j):rng.choice([0.,-0.,math.ulp(0.),-math.ulp(0.),rng.uniform(-.1,.1)]) for j in range(28)},.001)
              for _ in range(12)]
        af.FRESH='acceleration:remainder'
        for _ in range(70):
            atoms=[(rng.choice([-3,-1,0,1,2]),rng.choice(vals)) for _ in range(rng.randrange(2,30))]
            start=af._COUNTER[0]
            expected=_reference_sum_atoms(D('.01'),atoms);stop=af._COUNTER[0]
            af._COUNTER[0]=start;actual=sum_atoms(D('.01'),atoms)
            self.assertEqual(snapshot(expected),snapshot(actual));self.assertEqual(stop,af._COUNTER[0])

    def test_json_bytes_exact_and_nonfinite_refused(self):
        obj={'é':'漢字\n','values':[0.,-0.,1e-300,1e300,True,None,{'x':'\\'}]}
        expected=''.join(json.JSONEncoder(sort_keys=True,separators=(',',':'),allow_nan=False).iterencode(obj)).encode()
        self.assertEqual(expected,artifacts.canonical_bytes(obj))
        with self.assertRaises(ValueError):artifacts.canonical_bytes({'x':float('nan')})
    def trace(self, enabled, bounded=False):
        memo.ENABLED=enabled;memo.clear();t.begin_producer('transfer-trace');af._COUNTER[0]=0
        if bounded:memo.MAX_ENTRIES=2
        origin=t.Time('origin',af.I('2')+af.I.symbol('o','.0001'))
        start=t.Time('start',af.I('2.02')+af.I.symbol('s','.0001'))
        end=t.Time('end',af.I('2.04')+af.I.symbol('e','.0001'))
        segs=[Segment(0,origin,start,fs,end,fe) for fs,fe in [(False,False),(True,False),(False,True),(True,True)]]
        lam=af.I('8')+af.I.symbol('lam','.01');out=[]
        for repeat in range(10):
            for seg in segs:
                for _ in range(4):
                    for c in (e.iv.DOWN,e.iv.UP,e.iv.NEAR):c.clear_flags()
                    x=e.b.dz.transfer(seg,lam,'.1','.025',8)
                    out.append((snapshot(x),af._COUNTER[0],tuple(tuple(c.flags.items()) for c in (e.iv.DOWN,e.iv.UP,e.iv.NEAR)),
                                tuple(snapshot(ti.box()) for ti in (origin,start,end))))
                    out.append(snapshot(x*x+lam))
            if repeat==4: af._COUNTER[0]=0
        return out
    def test_transfer_exact_values_names_counters_boxes_flags(self):
        expected=self.trace(False);actual=self.trace(True)
        self.assertEqual(expected,actual);self.assertGreater(memo.STATS['hits'],20)
    def test_transfer_eviction(self):
        expected=self.trace(False,True);actual=self.trace(True,True)
        self.assertEqual(expected,actual);self.assertLessEqual(len(memo._CACHE),2)
        self.assertGreater(memo.STATS['evictions'],0)
    def test_completed_deposit_exact_replay(self):
        def trace(enabled):
            memo.ENABLED=enabled;memo.clear();t.begin_producer('subtotal');af._COUNTER[0]=0
            initial=af.I('.12')+af.I.symbol('initial','.001')
            origin=t.Time('o',af.I(2)+af.I.symbol('o','.0001'))
            segments=[]
            for k in range(5):
                start=origin.plus(D('.01')*k)
                end=t.Time(str(k),af.I(D('2.02')+D('.01')*k)+af.I.symbol(str(k),'.0001'))
                segments.append(Segment(0,origin,start,k%2==0,end,False))
            histories=[e.b.dz.History(initial,2,tuple(segments[:n])) for n in (2,3,5)]
            e.b.dz.LAM=af.I(8)+af.I.symbol('lam','.01')
            out=[]
            for _ in range(15):
                for h in histories:
                    for c in (e.iv.DOWN,e.iv.UP,e.iv.NEAR):c.clear_flags()
                    x=e.b.dz.completed(h)
                    out.append((snapshot(x),af._COUNTER[0],tuple(tuple(c.flags.items()) for c in (e.iv.DOWN,e.iv.UP,e.iv.NEAR))))
                    out.append(snapshot(x*x))
            return out
        old=getattr(e.b.dz,'LAM',None)
        try:
            expected=trace(False);actual=trace(True)
            self.assertEqual(expected,actual);self.assertGreater(memo.STATS['hits'],30)
        finally:
            if old is None:del e.b.dz.LAM
            else:e.b.dz.LAM=old
    def test_transfer_context_precision_and_traps(self):
        origin=t.Time('o',af.I(0)); end=t.Time('e',af.I('.042123456789'))
        seg=Segment(1,origin,origin,True,end,False);lam=af.I('8.123456789')
        contexts=(e.iv.DOWN,e.iv.UP,e.iv.NEAR)
        old=[(c.prec,dict(c.traps)) for c in contexts]
        try:
            for prec in (160,12,160):
                for c in contexts:c.prec=prec
                for _ in range(3):
                    start=af._COUNTER[0];memo.ENABLED=False
                    expected=e.b.dz.transfer(seg,lam,'.1','.025',8);stop=af._COUNTER[0]
                    af._COUNTER[0]=start;memo.ENABLED=True
                    actual=e.b.dz.transfer(seg,lam,'.1','.025',8)
                    self.assertEqual(snapshot(expected),snapshot(actual));self.assertEqual(stop,af._COUNTER[0])
            e.iv.DOWN.prec=4;e.iv.DOWN.traps[Inexact]=True
            for enabled in (False,True):
                memo.ENABLED=enabled
                with self.assertRaises(Inexact):e.b.dz.transfer(seg,lam,'.1','.025',8)
        finally:
            for c,(prec,traps) in zip(contexts,old):c.prec=prec;c.traps=traps
    def test_history_identity_keeps_distinct_correlations(self):
        a=e.b.dz.History(af.I(1)+af.I.symbol('a','.01'))
        b=e.b.dz.History(af.I(1)+af.I.symbol('b','.01'))
        ka=e.history_lookup_key(a);kb=e.history_lookup_key(b)
        self.assertIs(ka,e.history_lookup_key(a));self.assertNotEqual(ka,kb)
        self.assertEqual(len(e.unique_histories([a,b,a])),2)
        before=artifacts.canonical_hash(artifacts.Encoder().encode(a))
        e.history_lookup_key(a)
        self.assertEqual(before,artifacts.canonical_hash(artifacts.Encoder().encode(a)))

if __name__=='__main__':unittest.main()
