"""Uniform rule: eligibility, conservative fallback and engine DELTA binding."""
import os, sys, unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'affine'))
os.environ.setdefault('A22_ARTIFACT_DIR',str(ROOT/'test_diagnostics'))
import engine, temporal, affine_iv, correlated_first_delay
I=engine.I

class CorrelatedFirstDelay(unittest.TestCase):
    def setUp(self):
        temporal.begin_producer('uniform-delay-test')
        affine_iv.FRESH='uniform-delay-test:remainder'
        affine_iv._COUNTER[0]=0
        engine.settings_cell('uniform-delay-test')

    def train(self,lo,hi=None):
        return (temporal.Time('source',I(lo) if hi is None else I(lo,hi)),)

    def test_mixed_eligibility_preserves_other_ports(self):
        b=engine.b;old=b.D1_PORTS
        rows=correlated_first_delay.tighten(b,[self.train(0),self.train(100),()])
        self.assertIs(b.D1_PORTS[0],old[0]);self.assertIs(b.D1_PORTS[2],old[2])
        self.assertEqual([r['status'] for r in rows],['unchanged','tightened','unchanged'])
        self.assertTrue(any(':M:1' in n for n in b.D1_PORTS[1].d))
        self.assertFalse(any(':D1:' in n for n in b.D1_PORTS[1].d))
        self.assertLessEqual(old[1].lo,b.D1_PORTS[1].lo)
        self.assertLessEqual(b.D1_PORTS[1].hi,old[1].hi)

    def test_strict_arrival_test_uses_whole_enclosure(self):
        b=engine.b;old=b.D1_PORTS
        rows=correlated_first_delay.tighten(b,[self.train(b.U0.lo,1),(),()])
        self.assertEqual(rows[0]['reason'],'first_arrival_not_strictly_after_U0')
        self.assertIs(b.D1_PORTS[0],old[0])

    def test_reads_delta_from_engine(self):
        b=engine.b
        small=correlated_first_delay.tighten(b,[self.train(100),(),()])[0]
        engine.settings_cell('uniform-delay-test-large')
        b.DELTA=I('2e-5')
        large=correlated_first_delay.tighten(b,[self.train(100),(),()])[0]
        self.assertEqual(large['initial_delta_upper'],'0.00002')
        self.assertGreaterEqual(engine.D(large['delay_radius']),2*engine.D(small['delay_radius']))

    def test_failed_analytic_checks_are_optional(self):
        b=engine.b;old=b.D1_PORTS
        b.M=I(0)
        rows=correlated_first_delay.tighten(b,[self.train(100),(),()])
        self.assertEqual(rows[0]['reason'],'slope_not_proved_positive')
        self.assertIs(b.D1_PORTS[0],old[0])
        engine.settings_cell('uniform-delay-test-domain');old=b.D1_PORTS
        b.D0_PORTS=(I('.2'),)*3
        rows=correlated_first_delay.tighten(b,[self.train(100),(),()])
        self.assertEqual(rows[0]['reason'],'root_domain_not_proved')
        self.assertIs(b.D1_PORTS[0],old[0])

    def test_non_nested_candidate_keeps_legacy_range(self):
        b=engine.b;b.D1_PORTS=(I('.02'),)*3;old=b.D1_PORTS
        rows=correlated_first_delay.tighten(b,[self.train(100),(),()])
        self.assertEqual(rows[0]['reason'],'marginal_containment_not_proved')
        self.assertIs(b.D1_PORTS[0],old[0])

    def test_compute_calls_rule_for_arbitrary_layer_and_lane(self):
        for layer,lane in [(1,0),(3,9),(5,2),(6,11)]:
            with patch.object(correlated_first_delay,'tighten',return_value=['called']) as rule, patch.object(engine.b,'unit',return_value=((),{'clusters':0,'orders_enclosed':0})):
                result=engine.compute_cell(layer,lane,[()]*12,f'uniform-call/{layer}/{lane}')
            rule.assert_called_once()
            self.assertEqual(result['metrics']['first_delay_refinements'],['called'])

if __name__=='__main__':unittest.main()
