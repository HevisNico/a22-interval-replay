import sys,unittest
from pathlib import Path
from unittest.mock import patch
from dataclasses import replace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'affine'))
import engine as e,temporal,affine_iv as af,ready_commuting as rc

class ReadyCommutingTests(unittest.TestCase):
    def fixture(self):
        temporal.begin_producer('commuting-fixture');af.FRESH=None;e.settings_cell('commuting-fixture')
        b=e.b;t=temporal.Time('start',af.I(0));U=t.plus('.3')
        s=dict(t=t,q=b.R,z=[af.I(x).ln() for x in ('.3','1.2','.3')],b=af.I('.08'),p=0,
               raw=[None]*3,aux=[0]*3,mark=[None]*3,err=[None]*3,caps=[False]*3,bstop=False,fire=None)
        s['memory']=b.new_memory(s);s['actuation']=(b.ac.History(s['b']),)
        s['depot']=tuple((b.dz.History(z),) for z in s['z'])
        events=[]
        for j in range(2):
            arrival=temporal.Time('same-label',af.I('.2')+af.I.symbol('arrival'+str(j),'.005'))
            mark=arrival.plus('.02')
            events.extend([(arrival,[('raw_on',j,arrival)]),(mark,[('mark_on',j,mark)]),(mark.plus('.02'),[('mark_off',j,mark)])])
        return s,events,U

    def test_every_enumerated_order_has_same_endpoint_memory(self):
        s,events,U=self.fixture();out=rc.endpoint(e.b,s,events,U)
        self.assertIsNotNone(out);self.assertEqual(s['raw'],[None]*3)
        count=0
        for order in e.b.admissible_orders(s,events):
            ss=s
            for tt,actions in order:ss=e.b.act(e.b.flowing(ss,tt,True),actions)
            ss=e.b.flowing(ss,U,True);count+=1
            self.assertEqual(ss['aux'],out['aux'])
            self.assertEqual(ss['raw'],out['raw'])
            self.assertEqual(ss['actuation'],out['actuation'])
            self.assertEqual(set(ss['memory']['pulses']),set(out['memory']['pulses']))
            for key,term in ss['memory']['pulses'].items():
                other=out['memory']['pulses'][key]
                self.assertEqual(term['origin'].token(),other['origin'].token())
                self.assertTrue(af._same(term['g'],other['g']))
        self.assertGreater(count,1)

    def test_refuses_active_deposits_and_protected_history(self):
        s,g,U=self.fixture()
        dep=s['depot'];s['depot']=((replace(dep[0][0],active=e.b.ac.Segment(0,s['t'],s['t'],True)),),)+dep[1:]
        self.assertIsNone(rc.endpoint(e.b,s,g,U))
        s['depot']=dep;s['actuation']=(replace(s['actuation'][0],fire=s['t']),)
        self.assertIsNone(rc.endpoint(e.b,s,g,U))

    def test_failed_no_fire_proof_falls_back(self):
        s,g,U=self.fixture()
        with patch.object(e.b,'READY_MEMORY_COVER',return_value=False):self.assertIsNone(rc.endpoint(e.b,s,g,U))

    def test_error_event_is_not_commuted(self):
        s,g,U=self.fixture();g.append((U,[('error_on',2,U)]))
        self.assertIsNone(rc.endpoint(e.b,s,g,U))

if __name__=='__main__':unittest.main()
