"""Ancestry compatibility and complete transition catalogues, with real typed storage."""
import sys, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import run_scenarios as runner
sys.path.insert(0,str(ROOT/'affine'))
_,a,_=runner.run.initialize(ROOT/'test_diagnostics'/'scenario_launcher')

class Planning(unittest.TestCase):
    def test_shared_ancestor_choices_must_agree(self):
        self.assertIsNone(runner.join_contexts([{'A':'left'},{'A':'right'}]))
        self.assertEqual(runner.join_contexts([{'A':'left'},{'B':'x','A':'left'}]),{'A':'left','B':'x'})

    def test_two_layers_keep_joint_choices_without_cartesian_mixing(self):
        cfg=dict(run_id='test',kernel_id='kernel')
        parents=[[dict(id=f'{lane}-{choice}',context={'common':str(choice),f'own-{lane}':str(choice)})
                  for choice in range(2)] for lane in range(12)]
        cases=runner.plan(cfg,2,0,parents,a,100)
        self.assertEqual(len(cases),2)
        for case in cases:
            self.assertEqual({x['context']['common'] for x in case['selected']},{case['context']['common']})
        next_rows=[]
        for lane in range(12):
            jobs=runner.plan(cfg,2,lane,parents,a,100)
            next_rows.append([dict(id=c['job_id'],context={**c['context'],f'cell2-{lane}':c['job_id']}) for c in jobs])
        self.assertEqual(len(runner.plan(cfg,3,0,next_rows,a,100)),2)

    def test_independent_choices_are_all_retained(self):
        parents=[[dict(id=f'{lane}/{k}',context={str(lane):str(k)}) for k in range(2)] for lane in range(12)]
        self.assertEqual(len(runner.plan(dict(run_id='r',kernel_id='k'),2,0,parents,a,100)),8)
        with self.assertRaisesRegex(RuntimeError,'no jobs discarded'):
            runner.plan(dict(run_id='r',kernel_id='k'),2,0,parents,a,7)

    def test_missing_job_is_rejected_by_independent_verifier(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);folder=root/'layer_01';folder.mkdir()
            cfg=dict(run_id='r',kernel_id='k',limits=dict(jobs_per_cell=100))
            jobs=[[c['job_id'] for c in runner.plan(cfg,1,j,None,a,100)] for j in range(12)]
            jobs[0]=[]
            a.atomic_json(folder/'manifest.json',dict(run_id='r',kernel_id='k',jobs=jobs,scenarios=[]))
            with self.assertRaisesRegex(ValueError,'Missing or extra'):
                runner.verify_prefix(root,cfg,1,a)

    def test_changed_ancestry_is_detected_after_typed_reread(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);cfg=dict(run_id='r',kernel_id='k')
            case=runner.plan(cfg,1,0,None,a,100)[0]
            sid=a.canonical_hash(dict(job=case['job_id'],terminal=0))
            data=dict(case=case,scenarios=(dict(id=sid,context={'r/cell/1/0':sid},state={},outputs=(),conditions=(),trace=(),lineage=()),))
            folder=runner.job_folder(root,case);folder.mkdir(parents=True)
            sha,check=a.write_checked(folder/'result.json',data)
            receipt=dict(status='scenario_job_complete',case=case,payload_sha256=sha,
                views=runner.digest_views(a,data),scenarios=runner.metadata(data))
            a.atomic_json(folder/'receipt.json',receipt)
            runner.check_job(root,case,cfg,a)
            data['scenarios'][0]['context']['alien']='choice'
            sha,_=a.write_checked(folder/'result.json',data)
            receipt.update(payload_sha256=sha,views=runner.digest_views(a,data),scenarios=runner.metadata(data))
            a.atomic_json(folder/'receipt.json',receipt)
            with self.assertRaisesRegex(ValueError,'Broken scenario ancestry'):
                runner.check_job(root,case,cfg,a)

    def test_worker_feeds_each_selected_train_and_shares_only_device_parameters(self):
        # A synthetic model isolates transport/ancestry from the physics.
        import scenario_engine, temporal
        from affine_iv import I
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            cfg=dict(run_id='transport-fixture',kernel_id='fixture-only',source_identity=runner.run.identity(),
                limits=dict(memory_mib=0,cpu_seconds=0,wall_seconds=60,histories=32))
            def scenario(k):
                return dict(outputs=(temporal.Time('fixture-clock',I(3+k)),),state={},conditions=(),trace=(),lineage=())
            def initial(*args,**kw):return dict(status='complete',scenarios=(scenario(0),scenario(1)),metrics={})
            rows=[]
            with patch.object(scenario_engine,'compute',side_effect=initial):
                for lane in range(12):
                    cases=runner.plan(cfg,1,lane,None,a,100)
                    receipts=[runner.worker(str(root),cfg,c) for c in cases]
                    rows.append(runner.catalogue(root,cases,receipts,a))
            cases=runner.plan(cfg,2,0,rows,a,100)
            calls=[]
            def consume(e,t,n,lane,trains,producer,physical,*args):
                calls.append((trains,producer,physical))
                return dict(status='complete',scenarios=(scenario(0),),metrics={})
            with patch.object(scenario_engine,'compute',side_effect=consume):
                for c in cases:runner.worker(str(root),cfg,c)
            self.assertEqual(len(calls),8)
            self.assertEqual(len({x[1] for x in calls}),8)
            self.assertEqual({x[2] for x in calls},{'transport-fixture/cell/2/0'})
            for case,(trains,producer,physical) in zip(cases,calls):
                for lane,selection in zip((11,0,1),case['selected']):
                    self.assertEqual(trains[lane][0].box().lo,3+selection['scenario_index'])
            with patch.object(scenario_engine,'compute',side_effect=AssertionError('cache should be reused')):
                runner.worker(str(root),cfg,cases[0])

if __name__=='__main__':unittest.main()
