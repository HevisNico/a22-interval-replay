"""Exact rational witnesses for pointwise affine sum enclosure."""
from pathlib import Path
import sys, unittest, random
from fractions import Fraction as F
from decimal import Decimal as D
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'affine'))
import engine, affine_iv as af
from time_sum import sum_atoms

class TimeSumTests(unittest.TestCase):
    def test_exact_rational_pointwise_residual(self):
        old=(af.FRESH,af.KMAX)
        try:
            af.FRESH=None
            rng=random.Random(22010)
            for cap in (2,16,256):
                af.KMAX=cap
                for trial in range(40):
                    atoms=[];lo=hi=F(0);coeff={};error=F(0)
                    for i in range(12):
                        low=D(rng.randrange(-100,100))/D(16)
                        high=low+D(rng.randrange(5))/D(32)
                        d={str(k):rng.uniform(-1,1) for k in rng.sample(range(25),8)}
                        x=af._new_form(af.I,low,high,d,2.0**-40)
                        n=rng.choice([-3,-1,0,1,2]);atoms.append((n,x))
                        lo+=n*F(low if n>=0 else high)
                        hi+=n*F(high if n>=0 else low)
                        error+=abs(n)*F(x.e)
                        for k,v in d.items():coeff[k]=coeff.get(k,F(0))+n*F(v)
                    result=sum_atoms(D(0),atoms)
                    residual=error+sum(abs(coeff.get(k,F(0))-F(result._d.get(k,0.0))) for k in coeff.keys()|result._d.keys())
                    self.assertLessEqual(F(result.clo)-F(result.e),lo-residual)
                    self.assertGreaterEqual(F(result.chi)+F(result.e),hi+residual)
        finally:
            af.FRESH,af.KMAX=old

    def test_exact_cancellation_and_empty_sum(self):
        old=af.FRESH;af.FRESH=None
        try:
            x=af.I.symbol('shared','0.25')
            out=sum_atoms(D(0),[(1,x),(-1,x)])
            self.assertEqual((out.lo,out.hi),(D(0),D(0)))
            self.assertEqual(sum_atoms(D('0.125'),[]).pair(),['0.125','0.125'])
        finally:af.FRESH=old

if __name__=='__main__':unittest.main()
