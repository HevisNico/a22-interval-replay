"""Exercise recovery routing through unit(), including unchanged refusals."""
from pathlib import Path
import os
import sys
import unittest
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'affine'))
os.environ.setdefault('A22_ARTIFACT_DIR', str(ROOT / 'test_diagnostics'))
import engine
import affine_iv as af
import temporal
import recovery_group
import cycle_local_A20
from decimal import Decimal as D, localcontext

b = engine.b
SLOW_REFUSAL = 'slow section inside external cluster (actuation ledger)'


class ClusterRouting(unittest.TestCase):
    def setUp(self):
        ns = 'test-recovery-cluster/' + self._testMethodName
        temporal.begin_producer(ns)
        af.FRESH = ns + ':remainder'
        af._COUNTER[0] = 0
        engine.settings_cell(ns)
        self.inputs = ((temporal.Time('left', af.I('10', '10.01')),),
                       (temporal.Time('right', af.I('10.005', '10.015')),), ())

    def exercise(self, reason, accept):
        def advance(s, boundary, cell, count):
            return dict(s, p=2, t=boundary), 'external'

        def resolve(s, pending, idx, cell, count):
            self.assertEqual(s['p'], 2)
            self.assertEqual(idx, 0)
            self.assertEqual(count, 1)
            self.assertGreater(len(pending), 2)
            if not accept:
                return None
            return dict(s, p=0), len(pending), len(pending) + 1, 80

        failure = AssertionError(reason)
        with patch.object(b, 'advance', side_effect=advance), \
             patch.object(b, 'flowing', side_effect=failure), \
             patch.object(b, 'RECOVERY_GROUP', side_effect=resolve) as resolver:
            if accept:
                outputs, state = b.unit(self.inputs, 'synthetic-cluster')
                self.assertEqual(outputs, [])
                self.assertEqual(state['main_phase'], 0)
                self.assertEqual(state['orders_enclosed'], 80)
                self.assertEqual(state['clusters'], 1)
            else:
                with self.assertRaises(AssertionError) as raised:
                    b.unit(self.inputs, 'synthetic-cluster')
                self.assertIs(raised.exception, failure)
            return resolver.call_count

    def test_slow_crossing_uses_existing_resolver(self):
        self.assertEqual(self.exercise(SLOW_REFUSAL, True), 1)

    def test_declined_window_preserves_original_refusal(self):
        self.assertEqual(self.exercise(SLOW_REFUSAL, False), 1)

    def test_other_assertions_escape_unchanged(self):
        for reason in ('fast section inside external cluster',
                       'gain saturation invariant', 'unexpected invariant'):
            with self.subTest(reason=reason):
                self.assertEqual(self.exercise(reason, False), 0)


class RecoveryJoinPreconditions(unittest.TestCase):
    def test_ready_join_reanchors_a_lost_pulse_memory(self):
        forest = SimpleNamespace(branches=(SimpleNamespace(emissions=(), state=dict(p=0)),), certificate='test')
        joined = dict(p=0, memory=None)
        marker = object()
        with patch.object(cycle_local_A20, 'pending_window', return_value=(forest, 3, [1, 2])), \
             patch.object(b, 'join_states', return_value=joined), \
             patch.object(b, 'new_memory', return_value=marker) as rebuild, \
             patch.object(b, 'PROFILE', None):
            out = recovery_group.resolve(b, dict(p=2), [], 0, 'c', 0)
            self.assertIs(out[0]['memory'], marker)
            rebuild.assert_called_once_with(joined)
            self.assertEqual(out[1:], (3, 3, 1))

    def test_ready_join_retains_an_existing_pulse_memory(self):
        forest = SimpleNamespace(branches=(SimpleNamespace(emissions=(), state=dict(p=0)),), certificate='test')
        marker = object()
        joined = dict(p=0, memory=marker)
        with patch.object(cycle_local_A20, 'pending_window', return_value=(forest, 3, [1, 2])), \
             patch.object(b, 'join_states', return_value=joined), \
             patch.object(b, 'new_memory') as rebuild, patch.object(b, 'PROFILE', None):
            self.assertIs(recovery_group.resolve(b, dict(p=2), [], 0, 'c', 0)[0]['memory'], marker)
            rebuild.assert_not_called()

    def test_no_emission_is_insufficient_if_a_branch_is_not_ready(self):
        for phases in ((2,), (0, 1), (0, 2)):
            forest = SimpleNamespace(branches=tuple(
                SimpleNamespace(emissions=(), state=dict(p=p)) for p in phases))
            with patch.object(cycle_local_A20, 'pending_window',
                              return_value=(forest, 3, [1, 2])), \
                 patch('recovery_tightening.window', return_value=None), \
                 patch.object(b, 'join_states') as join:
                self.assertIsNone(recovery_group.resolve(b, dict(p=2), [], 0, 'c', 0))
                join.assert_not_called()

    def test_empty_forest_cannot_be_joined(self):
        forest = SimpleNamespace(branches=())
        with patch.object(cycle_local_A20, 'pending_window',
                          return_value=(forest, 3, [1, 2])), \
             patch('recovery_tightening.window', return_value=None), \
             patch.object(b, 'join_states') as join:
            self.assertIsNone(recovery_group.resolve(b, dict(p=2), [], 0, 'c', 0))
            join.assert_not_called()


class ReadyPeakDomain(unittest.TestCase):
    def setUp(self):
        ns = 'test-ready-peak/' + self._testMethodName
        temporal.begin_producer(ns)
        af.FRESH = ns + ':remainder'
        af._COUNTER[0] = 0
        engine.settings_cell(ns)

    def state(self, q):
        z = [af.I(g).ln() for g in ('.3', '1.2', '.3')]
        return dict(t=temporal.Time('clock', af.I(1)), q=q, p=0,
                    raw=[None]*3, aux=[0]*3, mark=[None]*3, err=[None]*3,
                    caps=[False]*3, bstop=False, b=af.I('.08'), z=z,
                    memory=None, actuation=(b.ac.History(af.I('.08')),),
                    depot=tuple((b.dz.History(g),) for g in z))

    def test_reanchored_memory_covers_the_same_active_pulse_trajectory(self):
        origin = temporal.Time('pulse-origin', af.I(10))
        anchor = origin.plus('.3')
        gain = af.I('1.2') + af.I.symbol('gain', '.01')
        original = b.dep.add(b.dep.start(origin, b.R, ()), 0, origin, gain)
        state = dict(t=anchor, q=b.dep.evaluate(original, anchor), p=0,
                     raw=[origin, None, None], caps=[False]*3,
                     z=[gain.ln(), af.I('1.2').ln(), af.I('.3').ln()])
        rebuilt = b.new_memory(state)
        for age in ('.3', '.5', '.9', '1.2', '2'):
            enclosure = b.dep.evaluate(rebuilt, origin.plus(age))
            with localcontext() as ctx:
                ctx.prec = 250
                A, K, R, u = b.A.mid(), b.K.mid(), b.R.mid(), D(age)
                v = min(u, D(1))
                response = A/(A-K)*((-K*v).exp()-(-A*v).exp())
                response *= (-K*max(D(0), u-1)).exp()
                for g in (gain.lo, gain.hi):
                    truth = R + g*response
                    self.assertLessEqual(enclosure.lo, truth)
                    self.assertGreaterEqual(enclosure.hi, truth)

    def test_nonpositive_peak_domain_uses_a_covering_upper_bound(self):
        for q, current, expected_calls in ((af.I('.09', '.11'), af.I(0, 1), 1),
                           (af.I('.1'), af.I('.001', '1'), 0),
                           (af.I('.09'), af.I('.001'), 1),
                           (af.I('.1'), af.I(2)+af.I.symbol('current', '.9'), 1)):
            with self.subTest(q=q.pair(), current=current.pair()):
                s = self.state(q)
                end = s['t'].plus('.1')
                with patch.object(b, 'coefficients', return_value=(current, [af.I(0)]*3, [af.I(0)]*3)), \
                     patch.object(b, 'READY_CLUSTER_PEAK', wraps=engine.ready_general_A22.peak_upper) as fallback:
                    out = b.flowing(s, end, True)
                    self.assertEqual(fallback.call_count, expected_calls)
                    upper = engine.ready_general_A22.peak_upper(s, end)
                    # Independent high-precision scalar trajectories on the
                    # parameter corners, including every sampled interior time.
                    with localcontext() as ctx:
                        ctx.prec = 250
                        A, K, R = b.A.mid(), b.K.mid(), b.R.mid()
                        for q0 in (q.lo, q.hi):
                            for j0 in (current.lo, current.hi):
                                for k in range(51):
                                    u = D(k)/500
                                    bb = j0/(A-K)
                                    truth = R + (q0-R+bb)*(-K*u).exp() - bb*(-A*u).exp()
                                    self.assertGreaterEqual(upper, truth)
                    self.assertLess(out['q'].hi, 1)

    def test_invalid_peak_domain_does_not_hide_a_possible_fire(self):
        s = self.state(af.I('.09', '.11'))
        with patch.object(b, 'coefficients', return_value=(af.I(0, 1000), [af.I(0)]*3, [af.I(0)]*3)):
            with self.assertRaisesRegex(AssertionError, 'internal crossing inside uncertain external cluster'):
                b.flowing(s, s['t'].plus('.1'), True)

    def test_advance_can_prove_no_fire_without_a_logarithm(self):
        s = self.state(af.I('.09', '.11'))
        with patch.object(b, 'coefficients', return_value=(af.I(0, 1), [af.I(0)]*3, [af.I(0)]*3)):
            out, kind = b.advance(s, s['t'].plus('.1'), 'test', 0)
            self.assertEqual(kind, 'external')
            self.assertLess(out['q'].hi, 1)

    def test_advance_declines_when_the_scalar_upper_bound_is_inconclusive(self):
        s = self.state(af.I('.09', '.11'))
        with patch.object(b, 'coefficients', return_value=(af.I(0, 1000), [af.I(0)]*3, [af.I(0)]*3)):
            with self.assertRaisesRegex(b.v.Ambiguous, 'ready guard still overlaps external boundary'):
                b.advance(s, s['t'].plus('.1'), 'test', 0)


if __name__ == '__main__':
    unittest.main()
