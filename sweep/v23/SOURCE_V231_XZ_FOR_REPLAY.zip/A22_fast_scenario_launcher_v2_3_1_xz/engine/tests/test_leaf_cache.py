from pathlib import Path
import sys,unittest,tempfile,json
from decimal import Decimal as D
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import run
e,a,t=run.initialize(Path(__file__).resolve().parents[1]/'test_diagnostics'/'leaf_cache')
from affine_iv import I

def views(x):return {'state':x['x'],'emissions':x['ts'],'time_dependencies':tuple((v.token(),v.expression()) for v in x['ts']),'ancestry':x['case'],'complete':x}
def fixture():
    t.begin_producer('leaf-test')
    x=I.make(D('0'),D('0.01'),{'scope/x':.125,'scope/y':-.25},.001)
    return {'x':x,'ts':tuple(t.Time('test/'+str(i),x,D(i)) for i in range(4)),'case':{'a':True,'b':1,'description':'état'}}
class LeafCacheTests(unittest.TestCase):
    def test_five_independently_numbered_graphs_match(self):
        p=fixture();expected={k:a.Encoder().encode(v) for k,v in views(p).items()}
        actual=a.encode_views(p,views)
        self.assertEqual(expected,actual)
        self.assertEqual({k:a.canonical_hash(v) for k,v in expected.items()},a.digest_views(p,views))
    def test_private_mutations_cannot_reuse_stale_leaf(self):
        cache=a._AffineLeafCache();x=I.make(D(0),D(1),{'s':0.0},0.0)
        def check():self.assertEqual(a.Encoder().encode(x),a.Encoder(leaf_cache=cache).encode(x))
        check();x._d['s']=float('-0.0');check()
        x._d['extra']=.3;check();del x._d['s'];check()
        object.__setattr__(x,'clo',D('0.00'));check()
        object.__setattr__(x,'e',float('-0.0'));check()
        x._d.clear();check()
    def test_private_dictionary_and_key_subclasses_are_not_cached(self):
        class MisleadingDict(dict):
            def get(self,k,default=None):return original_values.get(k,default)
        class WeirdKey(str):
            def __lt__(self,other):return not super().__lt__(other)
        x=I.make(D(0),D(1),{'a':.125,'b':.25},0.0);original_values=x._d.copy();cache=a._AffineLeafCache()
        a.Encoder(leaf_cache=cache).encode(x)
        object.__setattr__(x,'_d',MisleadingDict(a=.75,b=.25))
        self.assertEqual(a.Encoder().encode(x),a.Encoder(leaf_cache=cache).encode(x))
        object.__setattr__(x,'_d',{WeirdKey('a'):.125,WeirdKey('b'):.25})
        self.assertEqual(a.Encoder().encode(x),a.Encoder(leaf_cache=cache).encode(x))
    def test_cache_bounds_and_real_reread(self):
        cache=a._AffineLeafCache();cache.MAX_COEFFICIENTS=2;cache.MAX_ENTRIES=2
        for i in range(10):a.Encoder(leaf_cache=cache).encode(I.symbol(str(i),'.1'))
        self.assertLessEqual(cache.weight,2);self.assertLessEqual(len(cache.entries),2)
        with tempfile.TemporaryDirectory() as tmp:
            p=fixture();path=Path(tmp)/'result.json';sha,check,before=a.write_checked_views(path,p,views)
            self.assertTrue(check['full_content_equal'])
            self.assertEqual(before,a.digest_views(a.read(path,sha),views))
    def test_reread_mutation_is_detected(self):
        original=a.read
        def changed(*args,**kwargs):
            value=original(*args,**kwargs);value['x']._d['scope/x']=.75;return value
        with tempfile.TemporaryDirectory() as tmp,patch.object(a,'read',changed):
            with self.assertRaises(ValueError):a.write_checked_views(Path(tmp)/'result.json',fixture(),views)
if __name__=='__main__':unittest.main()
