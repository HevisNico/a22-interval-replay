from pathlib import Path
import sys, unittest
from types import SimpleNamespace
from decimal import Decimal as D
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'affine'))
import engine, temporal
from affine_iv import I
from cluster_memory_cover import certify

class MemoryCoverTests(unittest.TestCase):
    def check_cover(self, charge, depth=8):
        temporal.begin_producer('cover-test')
        start=temporal.Time('start',I(0))
        b=SimpleNamespace(I=I,D=D,shift=temporal.shift,
                          dep=SimpleNamespace(evaluate=lambda memory,t: charge(t.box())))
        return certify(b,{'p':0,'t':start,'memory':{}},start.plus(1),depth)

    def test_strict_subthreshold(self):
        self.assertTrue(self.check_cover(lambda x:I('.99')))

    def test_equality_and_crossing_refused(self):
        self.assertFalse(self.check_cover(lambda x:I(1)))
        self.assertFalse(self.check_cover(lambda x:I('1.01')))

    def test_subdivision_covers_both_sides(self):
        self.assertTrue(self.check_cover(lambda x:I('.8')+I(0,x.width())))
        self.assertFalse(self.check_cover(lambda x:I('.8') if x.hi<D('.9') else I('1.1')))

    def test_budget_exhaustion_refused(self):
        self.assertFalse(self.check_cover(lambda x:I('.8')+I(0,x.width()),depth=0))

if __name__=='__main__':unittest.main()
