from pathlib import Path
from decimal import Decimal as D, Inexact
import random,sys,unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import run
engine,a,t=run.initialize(Path(__file__).resolve().parents[1]/'test_diagnostics/time_sum_helpers')
import affine_iv as af,intervalles_decimaux as iv,time_sum as ts
from _rounding_native import time_sum_centers,time_sum_key,time_sum_parts


def reference_centers(offset,atoms):
    lo=hi=offset
    for n,v in atoms:
        if not n:continue
        vl,vh=(v.clo,v.chi) if n==1 else (v.chi.copy_negate(),v.clo.copy_negate())
        lo=iv.DOWN.add(lo,vl);hi=iv.UP.add(hi,vh)
    return lo,hi

class TimeSumHelpers(unittest.TestCase):
    def test_key_exact_identity_order_and_generic_bypass(self):
        x=af.I.symbol('x','.1');y=af.I.symbol('x','.1')
        atoms=[(0,x),(1,af.I(100)),(-1,x),(1,y),(1,x)]
        key=time_sum_key(atoms,af.I)
        self.assertEqual(key,((-1,x),(1,y),(1,x)))
        self.assertIs(key[0][1],x);self.assertIs(key[1][1],y)
        for n in (True,1.0,3,-4,10**100):self.assertIsNone(time_sum_key([(n,x)],af.I))
        self.assertEqual(time_sum_key([],af.I),())
        self.assertIsNone(time_sum_key([(1,object())],af.I))

    def test_ordered_centers_flags_and_traps(self):
        rng=random.Random(31415)
        old=(iv.DOWN.copy(),iv.UP.copy())
        try:
            for precision in (4,16,160):
                iv.DOWN.prec=iv.UP.prec=precision
                for _ in range(15):
                    atoms=[(rng.choice((-1,0,1)),af.I(D(rng.randrange(-10000,10000))/7)) for i in range(35)]
                    offset=D('1e-155')
                    for ctx in (iv.DOWN,iv.UP):ctx.clear_flags()
                    expected=reference_centers(offset,atoms);flags=[dict(c.flags) for c in (iv.DOWN,iv.UP)]
                    for ctx in (iv.DOWN,iv.UP):ctx.clear_flags()
                    actual=time_sum_centers(offset,atoms,iv.DOWN,iv.UP)
                    self.assertEqual(expected,actual)
                    self.assertEqual(flags,[dict(c.flags) for c in (iv.DOWN,iv.UP)])
            iv.DOWN.prec=iv.UP.prec=4
            atoms=[(1,af.I(D('1.23456789')))]
            for ctx in (iv.DOWN,iv.UP):ctx.traps[Inexact]=True
            snapshots=[]
            for fn in (reference_centers,lambda offset,atoms:time_sum_centers(offset,atoms,iv.DOWN,iv.UP)):
                for ctx in (iv.DOWN,iv.UP):ctx.clear_flags()
                with self.assertRaises(Inexact):fn(D(0),atoms)
                snapshots.append([dict(c.flags) for c in (iv.DOWN,iv.UP)])
            self.assertEqual(snapshots[0],snapshots[1])
        finally:
            for ctx,prior in zip((iv.DOWN,iv.UP),old):
                ctx.prec=prior.prec;ctx.traps=prior.traps;ctx.flags=prior.flags

    def test_older_native_binary_retains_native_parts_and_cache(self):
        import importlib.util,types
        import _rounding_native as native
        proxy=types.ModuleType('_rounding_native')
        for name in dir(native):
            if name not in ('time_sum_key','time_sum_centers'):
                setattr(proxy,name,getattr(native,name))
        sys.modules['_rounding_native']=proxy
        try:
            source=Path(__file__).resolve().parents[1]/'affine/time_sum.py'
            spec=importlib.util.spec_from_file_location('stale_helpers',source)
            stale=importlib.util.module_from_spec(spec);spec.loader.exec_module(stale)
        finally:sys.modules['_rounding_native']=native
        self.assertIs(stale.time_sum_parts,native.time_sum_parts)
        self.assertEqual(stale.time_sum_key.__module__,'stale_helpers')
        atoms=[(1,af.I.symbol('legacy','.1')),(-1,af.I(12))]
        for offset in (D(0),D('.2')):
            expected=ts.sum_atoms(offset,atoms);actual=stale.sum_atoms(offset,atoms)
            self.assertEqual(expected.__getstate__(),actual.__getstate__())
        self.assertEqual(stale.CACHE_STATS['hits'],1)

    def test_eviction_retains_exact_results_and_allocation_counts(self):
        old=(af.FRESH,af.KMAX,af._COUNTER[0],ts.MAX_CACHED_COEFFICIENTS,ts.MAX_CACHED_SUMS)
        try:
            af.FRESH='small-cache';af.KMAX=2
            ts.MAX_CACHED_COEFFICIENTS=40;ts.MAX_CACHED_SUMS=2;ts.clear_cache()
            values=[af.I.make(D(i),D(i),{str(k):float(k+i) for k in range(4)},1e-6) for i in range(6)]
            for i in list(range(6))*2:
                atoms=[(1,values[i]),(-1,values[(i+1)%6])]
                af._COUNTER[0]=100
                expected=af.I.make(*time_sum_parts(D(0),atoms,iv.DOWN,iv.UP));count=af._COUNTER[0]
                af._COUNTER[0]=100;actual=ts.sum_atoms(D(0),atoms)
                self.assertEqual(expected.__getstate__(),actual.__getstate__())
                self.assertEqual(list(expected._d),list(actual._d));self.assertEqual(count,af._COUNTER[0])
            self.assertLessEqual(len(ts._parts_cache),2)
        finally:
            af.FRESH,af.KMAX,af._COUNTER[0],ts.MAX_CACHED_COEFFICIENTS,ts.MAX_CACHED_SUMS=old;ts.clear_cache()

if __name__=='__main__':unittest.main()
