"""Pointwise high-precision witnesses for the direct pulse mean-value form."""
from pathlib import Path
import sys,unittest
from decimal import Decimal as D,localcontext
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'affine'))
import engine as e,affine_iv as af,temporal
class PulseResponse(unittest.TestCase):
 def test_parameterwise_enclosure(self):
  temporal.begin_producer('pulse-response-test');af.FRESH=None;e.settings_cell('pulse-response-test')
  for mid,rad in (('.05','.04'),('.5','.4'),('.9','.09')):
   u=af.I(mid)+af.I.symbol('u',rad);out=e.h(u)
   for sign in (-1,-.5,0,.5,1):
    with localcontext() as ctx:
     ctx.prec=250
     x=D(mid)+D.from_float(u.d['u'])*D(str(sign))
     A=D(4).ln();K=D('.5')
     truth=A/(A-K)*((-K*x).exp()-(-A*x).exp())
     linear=D.from_float(out.d.get('u',0))*D(str(sign));err=D.from_float(out.e)
     self.assertLessEqual(out.clo+linear-err,truth)
     self.assertGreaterEqual(out.chi+linear+err,truth)
if __name__=='__main__':unittest.main()
