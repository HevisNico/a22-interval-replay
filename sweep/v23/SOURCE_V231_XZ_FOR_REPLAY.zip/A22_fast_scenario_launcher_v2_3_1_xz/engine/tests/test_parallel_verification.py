"""Independent concurrent disk checks preserve coverage, order, and failure."""
from pathlib import Path
from unittest.mock import patch
import sys,tempfile,unittest,json
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import run,run_scenarios as r
_,a,t=run.initialize(ROOT/'test_diagnostics/parallel')
from affine_iv import I

class ParallelVerification(unittest.TestCase):
    def fixture(self,root):
        cfg=dict(run_id='parallel-fixture',kernel_id='fixture',source_identity=run.identity(),
            parameters={'epsilon_relative':'0.01'},limits={'jobs_per_cell':100})
        t.begin_producer("parallel-fixture")
        all_cases=[];all_receipts=[];rows=[];jobs=[]
        for lane in range(12):
            cases=r.plan(cfg,1,lane,None,a,100);case=cases[0]
            sid=a.canonical_hash(dict(job=case['job_id'],terminal=0))
            time=t.Time(f'clock-{lane}',I(lane))
            data=dict(case=case,scenarios=(dict(state={'x':I.symbol(f'p{lane}', '.01')},
                outputs=(time,time.plus(2)),id=sid,context={f'parallel-fixture/cell/1/{lane}':sid},
                conditions=(),trace=(),lineage=()),))
            folder=r.job_folder(root,case);folder.mkdir(parents=True)
            sha,check,views=a.write_checked_views(folder/'result.json',data,r.views)
            receipt=dict(status='scenario_job_complete',case=case,payload_sha256=sha,
                scenarios=r.metadata(data),views=views,serialization_check=check)
            a.atomic_json(folder/'receipt.json',receipt)
            all_cases.append(case);all_receipts.append(receipt)
            jobs.append([case['job_id']]);rows.append(r.catalogue(root,cases,[receipt],a))
        a.atomic_json(root/'layer_01/manifest.json',dict(run_id=cfg['run_id'],kernel_id=cfg['kernel_id'],jobs=jobs,scenarios=rows))
        return cfg,all_cases,all_receipts

    def test_parallel_equals_serial_in_plan_order(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);cfg,cases,expected=self.fixture(root)
            serial=r.verify_jobs(root,cfg,cases,a,1)
            parallel=r.verify_jobs(root,cfg,cases,a,2)
            self.assertEqual(serial,expected);self.assertEqual(parallel,expected)
            self.assertEqual([x['case']['lane'] for x in parallel],list(range(12)))

    def test_changed_view_in_child_prevents_layer_proof(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);cfg,cases,receipts=self.fixture(root)
            receipts[5]['views']['state']='0'*64
            a.atomic_json(r.job_folder(root,cases[5])/'receipt.json',receipts[5])
            with self.assertRaisesRegex(ValueError,'Scenario view mismatch'):
                r.verify_prefix(root,cfg,1,a,2)
            self.assertFalse((root/'layer_01/verification.json').exists())

    def test_payload_byte_tamper_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);cfg,cases,_=self.fixture(root)
            p=r.job_folder(root,cases[0])/'result.json';p.write_bytes(p.read_bytes()+b' ')
            with self.assertRaisesRegex(ValueError,'artifact hash mismatch'):
                r.verify_jobs(root,cfg,cases,a,2)

    def test_xz_payload_tamper_is_rejected(self):
        import lzma
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);cfg,cases,_=self.fixture(root)
            p=r.job_folder(root,cases[0])/'result.json';data=p.read_bytes()
            self.assertEqual(data[:6],a.XZ_MAGIC)
            mid=len(data)//2;p.write_bytes(data[:mid]+bytes([data[mid]^1])+data[mid+1:])
            with self.assertRaisesRegex(ValueError,'artifact hash mismatch'):
                r.verify_jobs(root,cfg,cases,a,2)
            p.write_bytes(data+lzma.compress(b' '))
            with self.assertRaisesRegex(ValueError,'artifact hash mismatch'):
                r.verify_jobs(root,cfg,cases,a,2)

    def test_source_change_and_invalid_workers_refuse(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);cfg,cases,_=self.fixture(root)
            with patch.object(run,'identity',return_value='changed'):
                with self.assertRaisesRegex(ValueError,'Source changed'):
                    r.verify_jobs(root,cfg,cases,a,2)
            for workers in (0,13,True):
                with self.assertRaisesRegex(ValueError,'workers'):
                    r.verify_jobs(root,cfg,cases,a,workers)

if __name__=='__main__':unittest.main()
