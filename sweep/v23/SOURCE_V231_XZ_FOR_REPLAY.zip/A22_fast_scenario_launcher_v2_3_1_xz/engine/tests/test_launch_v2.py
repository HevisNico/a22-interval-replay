from pathlib import Path
from unittest.mock import patch
import importlib.util,sys,tempfile,unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import launch_v2

class LaunchV2(unittest.TestCase):
    def test_fresh_scenario_defaults_and_forwarded_limits(self):
        with tempfile.TemporaryDirectory() as tmp:
            target=Path(tmp)/'new'
            with patch.object(sys,'argv',['launch_v2','--out',str(target),'--through','10']),patch.object(launch_v2.os,'execv') as execute:
                launch_v2.main()
            command=execute.call_args.args[1]
            options=dict(zip(command[4::2],command[5::2]))
            self.assertEqual(options['--epsilon'],'0.01')
            self.assertEqual(options['--through'],'10')
            self.assertEqual(options['--max-histories'],'512')
            self.assertEqual(options['--zip-every'],'5')
            self.assertFalse(target.exists())

    def test_existing_output_is_refused_before_start(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch.object(sys,'argv',['launch_v2','--out',tmp]),patch.object(launch_v2.os,'execv') as execute:
                with self.assertRaises(SystemExit):launch_v2.main()
            execute.assert_not_called()

if __name__=='__main__':unittest.main()
