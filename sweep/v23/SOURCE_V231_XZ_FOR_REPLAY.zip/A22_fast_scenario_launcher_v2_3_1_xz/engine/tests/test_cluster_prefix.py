import sys, unittest
from pathlib import Path
from types import SimpleNamespace
from itertools import permutations
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'affine'))
import cluster_prefix

class PrefixTests(unittest.TestCase):
    def fixture(self):
        calls=[]
        # Equal-looking dates remain separate event objects.
        events=[('same-label',('a',)),('same-label',('b',)),('other',('c',))]
        def flow(s,t,guard):
            self.assertTrue(guard);calls.append((s,t));return s+('flow:'+t,)
        def act(s,actions):return s+actions
        b=SimpleNamespace(admissible_orders=lambda s,g:iter(permutations(g)),flowing=flow,act=act)
        return b,events,calls

    def test_all_orders_and_distinct_events_preserved(self):
        b,events,calls=self.fixture()
        expected=[]
        for order in permutations(events):
            s=()
            for tt,acts in order:s=b.act(b.flowing(s,tt,True),acts)
            expected.append(b.flowing(s,'end',True))
        old_calls=len(calls);calls.clear()
        self.assertEqual(list(cluster_prefix.states(b,(),events,'end')),expected)
        self.assertLess(len(calls),old_calls)
        self.assertEqual(len(expected),6)

    def test_zero_cache_budget_preserves_every_branch(self):
        b,events,_=self.fixture()
        self.assertEqual(list(cluster_prefix.states(b,(),events,'end',0)),list(cluster_prefix.states(b,(),events,'end',100)))

    def test_guard_refusal_propagates(self):
        b,events,_=self.fixture()
        def fail(*args):raise AssertionError('real guard refusal')
        b.flowing=fail
        with self.assertRaisesRegex(AssertionError,'real guard refusal'):
            list(cluster_prefix.states(b,(),events,'end'))

if __name__=='__main__':unittest.main()
