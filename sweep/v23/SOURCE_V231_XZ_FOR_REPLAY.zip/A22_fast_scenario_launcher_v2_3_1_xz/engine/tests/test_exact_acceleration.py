from pathlib import Path
from decimal import Decimal as D
import json,random,sys,tempfile,unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import run
engine,a,t=run.initialize(Path(__file__).resolve().parents[1]/'test_diagnostics/exact_acceleration')
import affine_iv as af,intervalles_decimaux as iv,time_sum as ts

class CoefficientReplay(unittest.TestCase):
    def test_complete_representation_flags_and_allocators_match(self):
        from _rounding_native import time_sum_parts
        old=(af.FRESH,af.KMAX,af._COUNTER[0])
        rng=random.Random(1002)
        try:
            for cap in (2,16,256):
                af.KMAX=cap;af.FRESH='differential';ts.clear_cache()
                atoms=[]
                for i in range(12):
                    d={f'symbol/{k}':rng.uniform(-1,1) for k in rng.sample(range(40),16)}
                    x=af._new_form(af.I,D(i)/7,D(i)/7+D('0.0001'),d,1e-7)
                    atoms.append((rng.choice((-1,0,1)),x))
                for offset in ('0','0.1234567890123456789','1e-160','100000'):
                    varied=[(1,af.I(D(offset)))]+atoms
                    for c in (iv.DOWN,iv.UP,iv.NEAR):c.clear_flags()
                    af._COUNTER[0]=100
                    expected=af.I.make(*time_sum_parts(D(offset),varied,iv.DOWN,iv.UP))
                    expected_flags=[dict(c.flags) for c in (iv.DOWN,iv.UP,iv.NEAR)]
                    expected_count=af._COUNTER[0]
                    for c in (iv.DOWN,iv.UP,iv.NEAR):c.clear_flags()
                    af._COUNTER[0]=100
                    actual=ts.sum_atoms(D(offset),varied)
                    self.assertEqual(expected.__getstate__(),actual.__getstate__())
                    self.assertEqual(list(expected._d),list(actual._d))
                    self.assertEqual(expected_flags,[dict(c.flags) for c in (iv.DOWN,iv.UP,iv.NEAR)])
                    self.assertEqual(expected_count,af._COUNTER[0])
                self.assertGreater(ts.CACHE_STATS['hits'],0)
            # General multipliers retain the original allocation path.
            x=af.I.symbol('general','.1');af._COUNTER[0]=0
            expected=af.I.make(*time_sum_parts(D(0),[(3,x)],iv.DOWN,iv.UP));count=af._COUNTER[0]
            af._COUNTER[0]=0;actual=ts.sum_atoms(D(0),[(3,x)])
            self.assertEqual(expected.__getstate__(),actual.__getstate__())
            self.assertEqual(count,af._COUNTER[0])
        finally:af.FRESH,af.KMAX,af._COUNTER[0]=old;ts.clear_cache()

    def test_equal_marginals_keep_distinct_symbols(self):
        ts.clear_cache();x=af.I.symbol('x','.1');y=af.I.symbol('y','.1')
        p=ts.sum_atoms(D(0),[(1,x)]);q=ts.sum_atoms(D(0),[(1,y)])
        self.assertEqual(p.pair(),q.pair());self.assertNotEqual(p._d,q._d)

class CompactStorage(unittest.TestCase):
    def graph(self):
        x=af.I.symbol('physical/'+'parameter/'*30,'.1')
        return a.Encoder().encode({'values':tuple(x+af.I(i) for i in range(30))})
    def test_exact_original_canonical_graph_is_reconstructed(self):
        graph=self.graph();packed=json.loads(a.canonical_bytes(a.pack_graph(graph)))
        self.assertEqual(a.canonical_bytes(a.unpack_graph(packed)),a.canonical_bytes(graph))
        self.assertLess(len(a.canonical_bytes(packed)),len(a.canonical_bytes(graph)))
    def test_invalid_indices_symbols_and_storage_schema_refuse(self):
        for bad in (-1,True,999999):
            doc=a.pack_graph(self.graph());node=next(n for n in doc['nodes'] if n[0]=='affine' and n[3])
            node[3][0]=(bad,node[3][0][1])
            with self.assertRaisesRegex(ValueError,'symbol index'):a.unpack_graph(doc)
        doc=a.pack_graph(self.graph());doc['symbols'].append(doc['symbols'][0])
        with self.assertRaisesRegex(ValueError,'symbol table'):a.unpack_graph(doc)
        doc=a.pack_graph(self.graph());doc['storage_schema']='unattested'
        with self.assertRaisesRegex(ValueError,'storage schema'):a.unpack_graph(doc)
    def test_size_and_sha_guards_still_apply_to_exact_disk_bytes(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'data.json';sha=a.atomic_graph(p,self.graph())
            with self.assertRaisesRegex(MemoryError,'byte budget'):a.read(p,sha,max_bytes=p.stat().st_size-1)
            p.write_bytes(p.read_bytes()+b' ')
            with self.assertRaisesRegex(ValueError,'hash mismatch'):a.read(p,sha)

if __name__=='__main__':unittest.main()
