"""Exact representation and byte-bound proof reuse, including tampering."""
from pathlib import Path
import os,sys,tempfile,unittest
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import run,run_scenarios as r
_,a,t=run.initialize(ROOT/'test_diagnostics'/'fast_checks')
from affine_iv import I

class Views(unittest.TestCase):
    def data(self):
        t.begin_producer('view-test')
        x=I(2)+I.symbol('p','.01');date=t.Time('date',x)
        return dict(case={},scenarios=(dict(state={'x':x,'alias':x},outputs=(date,date.plus(1)),
            id='s',context={},conditions=(),trace=(),lineage=()),))
    def test_each_graph_is_byte_identical_to_separate_reference_encoder(self):
        data=self.data();graphs=a.encode_views(data,r.views)
        for name,value in r.views(data).items():
            self.assertEqual(a.canonical_bytes(graphs[name]),a.canonical_bytes(a.Encoder().encode(value)))
    def test_batch_cache_does_not_survive_mutation_between_calls(self):
        data=self.data();before=r.digest_views(a,data)
        data['scenarios'][0]['state']['additional']=I(3)
        self.assertNotEqual(before,r.digest_views(a,data))
    def test_one_real_disk_decode_still_checks_every_view(self):
        data=self.data()
        with tempfile.TemporaryDirectory() as tmp:
            with patch.object(a,'read',wraps=a.read) as read:
                sha,check,views=a.write_checked_views(Path(tmp)/'data.json',data,r.views)
                self.assertEqual(read.call_count,1)
            self.assertEqual(views,{k:a.canonical_hash(a.Encoder().encode(v)) for k,v in r.views(data).items()})
            self.assertTrue(check['full_content_equal'])
    def test_disk_difference_is_refused(self):
        data=self.data();different=self.data();different['case']={'changed':True}
        with tempfile.TemporaryDirectory() as tmp,patch.object(a,'read',return_value=different):
            with self.assertRaisesRegex(ValueError,'fresh/disk view mismatch'):
                a.write_checked_views(Path(tmp)/'data.json',data,r.views)

class SealedProof(unittest.TestCase):
    def exercise(self,mutation=None):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);cfg=dict(run_id='fixture',kernel_id='kernel')
            case=r.plan(cfg,1,0,None,a,10)[0];folder=r.job_folder(root,case);folder.mkdir(parents=True)
            payload=folder/'result.json';payload.write_bytes(b'verified-byte-snapshot')
            receipt=dict(case=case,status='scenario_job_complete',payload_sha256=a.file_hash(payload))
            a.atomic_json(folder/'receipt.json',receipt)
            layer=root/'layer_01';manifest=dict(checked=True);a.atomic_json(layer/'manifest.json',manifest)
            proof=dict(run_id='fixture',kernel_id='kernel',through=1,receipts=[a.file_hash(folder/'receipt.json')])
            a.atomic_json(layer/'verification.json',proof)
            a.atomic_json(layer/'complete.json',dict(status='research_scenario_layer_complete',manifest_sha256=a.file_hash(layer/'manifest.json'),verification_sha256=a.file_hash(layer/'verification.json')))
            if mutation:mutation(root,folder,cfg)
            with patch.object(a,'read',side_effect=AssertionError('sealed old payload must not be decoded')):
                return r.sealed_layer(root,cfg,1,manifest,[case],a)
    def test_unchanged_bytes_reuse_original_proof(self):self.assertEqual(len(self.exercise()),1)
    def test_equal_size_and_mtime_do_not_hide_payload_change(self):
        def mutate(root,folder,cfg):
            p=folder/'result.json';stat=p.stat();p.write_bytes(b'Verified-byte-snapshot');os.utime(p,ns=(stat.st_atime_ns,stat.st_mtime_ns))
        with self.assertRaisesRegex(ValueError,'Ancestor payload changed'):self.exercise(mutate)
    def test_changed_receipt_or_proof_is_refused(self):
        for name in ('receipt.json','verification.json'):
            def mutate(root,folder,cfg):
                p=folder/name if name=='receipt.json' else root/'layer_01'/name
                p.write_bytes(p.read_bytes()+b' ')
            with self.subTest(name=name),self.assertRaises(ValueError):self.exercise(mutate)
    def test_other_kernel_cannot_reuse_proof(self):
        with self.assertRaisesRegex(ValueError,'identity mismatch'):
            self.exercise(lambda root,folder,cfg:cfg.update(kernel_id='different'))

if __name__=='__main__':unittest.main()
