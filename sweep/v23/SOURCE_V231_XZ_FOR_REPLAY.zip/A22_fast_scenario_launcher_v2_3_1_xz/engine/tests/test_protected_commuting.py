import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'affine'))
import engine as e,temporal,affine_iv as af,protected_commuting as pc

class ProtectedCommutingTests(unittest.TestCase):
    def fixture(self):
        temporal.begin_producer('protected-fixture');af.FRESH=None;e.settings_cell('protected-fixture')
        b=e.b;fire=temporal.Time('fire',af.I(0));start=fire.plus('.9')
        s=dict(t=start,q=(-b.A*af.I('.9')).exp(),z=[af.I(x).ln() for x in ('.3','1.2','.3')],
               b=af.I('.08'),p=1,raw=[None]*3,aux=[0]*3,mark=[None]*3,err=[None]*3,
               caps=[False]*3,bstop=False,fire=fire,memory=None)
        s['actuation']=(b.ac.History(s['b'],fire=fire),)
        s['depot']=tuple((b.dz.History(z),) for z in s['z'])
        events=[]
        for j in range(2):
            arrival=temporal.Time('same',af.I('.98')+af.I.symbol('arrival'+str(j),'.005'))
            mark=b.shift(arrival,b.D0_PORTS[j],'mark')
            off=b.shift(mark,b.DM_PORTS[j],'off')
            events.extend([(arrival,[('raw_on',j,arrival)]),(mark,[('mark_on',j,mark)]),(off,[('mark_off',j,mark)])])
        return s,events,af.D('1.06')

    def test_same_ledger_and_endpoint_as_every_order(self):
        s,g,upper=self.fixture();out,n=pc.endpoint(e.b,s,g,upper,'fixture',0)
        self.assertEqual(n,1);self.assertEqual(out['p'],2)
        U=out['t'];count=0
        for order in e.b.admissible_orders(s,g):
            ss=s
            for tt,actions in order:ss=e.b.act(e.b.flowing(ss,tt),actions)
            ss=e.b.flowing(ss,U)
            ell=e.b.ac.bounds(ss['actuation'],U,'ell')
            self.assertGreater(ell.lo,0)
            self.assertEqual(ss['actuation'],out['actuation'])
            self.assertEqual(ss['aux'],out['aux']);self.assertEqual(ss['raw'],out['raw'])
            self.assertTrue(af._same(e.b.R*ell.exp(),out['q']))
            count+=1
        self.assertGreater(count,1)
        self.assertEqual(s['aux'],[0]*3)

    def test_possible_recovery_is_not_commuted(self):
        s,g,_=self.fixture()
        self.assertIsNone(pc.endpoint(e.b,s,g,af.D(30),'fixture',0))

    def test_endpoint_before_fast_end_rejected(self):
        s,g,_=self.fixture()
        self.assertIsNone(pc.endpoint(e.b,s,g,af.D('.99'),'fixture',0))

if __name__=='__main__':unittest.main()
