import sys, unittest
from pathlib import Path
from types import SimpleNamespace
from decimal import Decimal as D
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'affine'))
import engine, temporal, memory_root
from affine_iv import I

class MemoryRootTests(unittest.TestCase):
    def fixture(self, slope=1, start='.1', boundary='1'):
        temporal.begin_producer('root-test')
        t=temporal.Time('start',I(0));s={'p':0,'t':t,'memory':{}}
        def refused(*args):raise engine.v.Ambiguous('ready guard still overlaps external boundary or possible tangency')
        def flowing(s,t):return dict(s,t=t)
        def reset(s):return dict(s,p=1)
        dep=SimpleNamespace(evaluate=lambda memory,t,derivative=False:I(slope) if derivative else I(start)+2*t.box())
        b=SimpleNamespace(advance=refused,v=engine.v,dep=dep,shift=temporal.shift,flowing=flowing,fire_reset=reset,PROFILE=None)
        memory_root.install(SimpleNamespace(b=b,I=I,D=D,iv=engine.iv))
        return b,s,t.plus(boundary)

    def test_certified_root_before_boundary(self):
        b,s,bd=self.fixture(slope=2)
        out,kind=b.advance(s,bd,'fixture',0)
        self.assertEqual(kind,'fire');self.assertEqual(out['p'],1)
        self.assertLessEqual(out['t'].box().lo,D('.45'))
        self.assertGreaterEqual(out['t'].box().hi,D('.45'))
        self.assertGreater(bd.minus(out['t']).lo,0)

    def test_nonpositive_slope_refused(self):
        b,s,bd=self.fixture(slope=0)
        with self.assertRaises(engine.v.Ambiguous):b.advance(s,bd,'fixture',0)

    def test_boundary_before_root_refused(self):
        b,s,bd=self.fixture(slope=2,boundary='.2')
        with self.assertRaises(engine.v.Ambiguous):b.advance(s,bd,'fixture',0)

    def test_initial_threshold_refused(self):
        b,s,bd=self.fixture(slope=2,start='1')
        with self.assertRaises(engine.v.Ambiguous):b.advance(s,bd,'fixture',0)

if __name__=='__main__':unittest.main()
