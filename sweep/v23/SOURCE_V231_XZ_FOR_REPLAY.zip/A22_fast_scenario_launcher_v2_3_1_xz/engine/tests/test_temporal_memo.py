"""Differential checks against the original directed affine operation."""
from pathlib import Path
import random,sys,unittest
from decimal import Decimal as D, Inexact, Rounded, Overflow, localcontext
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'affine'))
import engine, affine_iv as af, temporal as t, temporal_memo as memo

def snapshot(x):
    return (str(x.clo),str(x.chi),tuple((k,v.hex()) for k,v in x._d.items()),x.e.hex())

class TemporalMemoTests(unittest.TestCase):
    def setUp(self):
        self.old=(af.FRESH,af.KMAX,af.ETHRESH,memo.ENABLED,memo.MAX_ENTRIES,memo.MAX_COEFFICIENTS)
        af.FRESH='differential:remainder';af._COUNTER[0]=0
        af.KMAX=16;af.ETHRESH=1e-12;memo.ENABLED=True
        t.begin_producer('differential')
    def tearDown(self):
        af.FRESH,af.KMAX,af.ETHRESH,memo.ENABLED,memo.MAX_ENTRIES,memo.MAX_COEFFICIENTS=self.old
        memo.clear()
    def trace(self,enabled):
        memo.ENABLED=enabled;t.begin_producer('trace');af._COUNTER[0]=0
        rng=random.Random(824)
        x=af.I.make(D('.1'),D('.11'),{str(i):rng.uniform(-.02,.02) for i in range(24)},.001)
        y=af.I.make(D('.2'),D('.22'),{str(i):rng.uniform(-.02,.02) for i in range(24)},.002)
        a=t.Time('a',x);b=t.Time('b',y)
        out=[]
        # Fresh plus/copy objects exercise reuse before box-cache population.
        for k in range(36):
            for u,v in [(a,b),(a.plus('.123'),b.plus('.456')),
                        (a.copy(),a.copy()),(a.plus('1.00'),b.plus('1.00'))]:
                z=u.minus(v)
                out.append((snapshot(z),af._COUNTER[0],snapshot(u.box()),snapshot(v.box())))
                out.append(snapshot(z*z+af.I.symbol('after','.03')))
        return out
    def test_exact_trace_fresh_names_counters_boxes_and_order(self):
        expected=self.trace(False);actual=self.trace(True)
        self.assertEqual(expected,actual)
        self.assertGreater(memo.STATS['hits'],30)
        self.assertGreater(memo.STATS['replayed_allocations'],0)
    def test_atom_conflicts_still_refused(self):
        a=t.Time('a',af.I(1),terms=(('atom',1,af.I(1)),))
        b=t.Time('b',af.I(2),terms=(('atom',1,af.I(2)),))
        for _ in range(2):
            with self.assertRaises(ValueError):a.minus(b)
    def test_same_labels_and_boxes_do_not_imply_same_atom(self):
        a=t.Time('same',af.I(-1,1));b=t.Time('same',af.I(-1,1))
        for _ in range(2):
            self.assertEqual(a.minus(b).pair(),['-2','2'])
    def test_context_flags_replayed_and_existing_flags_preserved(self):
        a=t.Time('a',af.I('0.123456789012345678901234567890123456789'))
        b=t.Time('b',af.I('0.000000000000000000000000000000000000003'))
        old=engine.iv.DOWN.prec
        try:
            engine.iv.DOWN.prec=12
            for c in (engine.iv.DOWN,engine.iv.UP,engine.iv.NEAR):c.clear_flags()
            a.minus(b) # populate boxes
            for c in (engine.iv.DOWN,engine.iv.UP,engine.iv.NEAR):c.clear_flags()
            expected=a.minus(b);flags=tuple(dict(c.flags) for c in (engine.iv.DOWN,engine.iv.UP,engine.iv.NEAR))
            for c in (engine.iv.DOWN,engine.iv.UP,engine.iv.NEAR):c.clear_flags()
            actual=a.minus(b)
            self.assertEqual(snapshot(expected),snapshot(actual))
            self.assertEqual(flags,tuple(dict(c.flags) for c in (engine.iv.DOWN,engine.iv.UP,engine.iv.NEAR)))
            engine.iv.NEAR.flags[Rounded]=True;a.minus(b)
            self.assertTrue(engine.iv.NEAR.flags[Rounded])
            engine.iv.DOWN.traps[Inexact]=True
            with self.assertRaises(Inexact):a.minus(b)
        finally:
            engine.iv.DOWN.prec=old;engine.iv.DOWN.traps[Inexact]=False
    def test_context_precision_and_representation_separate_keys(self):
        af.FRESH=None
        a=t.Time('a',af.I('1.23456789'));b=t.Time('b',af.I('.000000003'))
        old=engine.iv.DOWN.prec
        try:
            for prec in (160,8,160):
                engine.iv.DOWN.prec=prec
                self.assertEqual(snapshot(a._minus_reference(b)),snapshot(a.minus(b)))
            a=t.Time('x',af.I(1));b=t.Time('y',af.I(1))
            for offset in ('1.0','1.00','-0','0'):
                self.assertEqual(snapshot(a.plus(offset)._minus_reference(b)),snapshot(a.plus(offset).minus(b)))
        finally:engine.iv.DOWN.prec=old
    def test_bounded_cache_and_producer_reset(self):
        memo.MAX_ENTRIES=3;memo.MAX_COEFFICIENTS=20;af.FRESH=None
        for k in range(30):
            a=t.Time(str(k),af.I(k));b=t.Time('zero',af.I(0));a.minus(b)
            self.assertLessEqual(len(memo._CACHE),3)
            self.assertLessEqual(memo._WEIGHT,20)
        self.assertGreater(memo.STATS['evictions'],0)
        t.begin_producer('next')
        self.assertFalse(memo._CACHE);self.assertEqual(memo._WEIGHT,0)
    def test_future_allocator_name_and_counter_reset(self):
        x=af.I.make(D(0),D(0),{af.FRESH+'#100':.001},0.)
        a=t.Time('a',x);b=t.Time('b',af.I(1))
        for start in (0,200,0):
            af._COUNTER[0]=start
            expected=a._minus_reference(b);end=af._COUNTER[0]
            af._COUNTER[0]=start
            actual=a.minus(b)
            self.assertEqual(snapshot(expected),snapshot(actual));self.assertEqual(af._COUNTER[0],end)
    def test_generated_signed_repeated_terms_box_choices_and_evictions(self):
        def trace(enabled):
            memo.ENABLED=enabled;t.begin_producer('generated');af._COUNTER[0]=0
            rng=random.Random(338)
            values=[af.I.make(D(k)/7,D(k)/7+D('.00001'),{str(j):rng.uniform(-.001,.001) for j in range(20)},1e-5) for k in range(10)]
            templates=[]
            for k in range(12):
                terms=tuple((str(j%4),rng.choice((-2,-1,0,1,2)),values[j%4]) for j in range(6))
                templates.append((str(k),values[k%10],D(k)/11,terms))
            out=[]
            for repeat in range(4):
                for k in range(11):
                    a=t.Time(*templates[k]);b=t.Time(*templates[k+1])
                    for _ in range(3):
                        z=a.minus(b);out.append((snapshot(z),af._COUNTER[0]))
            return out
        memo.MAX_ENTRIES=5
        self.assertEqual(trace(False),trace(True))
        self.assertGreater(memo.STATS['hits'],0);self.assertGreater(memo.STATS['evictions'],0)
    def test_accepted_list_atom_entries_and_subclass_fallback(self):
        a=t.Time('a',af.I(1),terms=(['atom',1,af.I(1)],))
        b=t.Time('b',af.I(2))
        for _ in range(2):self.assertEqual(snapshot(a._minus_reference(b)),snapshot(a.minus(b)))
        class SpecialTime(t.Time):
            def box(self):return af.I(9)
        a=SpecialTime('custom',af.I(3))
        self.assertEqual(snapshot(a._minus_reference(b)),snapshot(a.minus(b)))
    def test_replay_restores_lazy_state_instead_of_reusing_downstream_caches(self):
        af.FRESH=None
        x=af.I.make(D('1.123456789'),D('1.123456790'),{'x':.01},0.)
        y=af.I.make(D('.123456789'),D('.123456790'),{'y':.02},0.)
        a=t.Time('a',x);b=t.Time('b',y)
        a.minus(b);a.minus(b) # warm keys after input caches populate
        z=a.minus(b);z._center();z.fingerprint()
        expected=a._minus_reference(b)
        actual=a.minus(b)
        self.assertEqual(snapshot(expected),snapshot(actual))
        self.assertEqual(tuple(getattr(expected,n) for n in memo._FIELDS),tuple(getattr(actual,n) for n in memo._FIELDS))
        for c in (engine.iv.DOWN,engine.iv.UP,engine.iv.NEAR):c.clear_flags()
        expected.width();flags=tuple(dict(c.flags) for c in (engine.iv.DOWN,engine.iv.UP,engine.iv.NEAR))
        for c in (engine.iv.DOWN,engine.iv.UP,engine.iv.NEAR):c.clear_flags()
        actual.width()
        self.assertEqual(flags,tuple(dict(c.flags) for c in (engine.iv.DOWN,engine.iv.UP,engine.iv.NEAR)))
    def test_ambient_context_limits_cannot_be_hidden_by_cache(self):
        a=t.Time('a',af.I(0),D(100));b=t.Time('b',af.I(0))
        a.minus(b);a.minus(b);a.minus(b)
        with localcontext() as c:
            c.Emax=1;c.traps[Overflow]=True
            with self.assertRaises(Overflow):a._minus_reference(b)
            with self.assertRaises(Overflow):a.minus(b)
    def test_value_keys_preserve_aliases_input_cache_effects_and_representation(self):
        def trace(enabled):
            memo.ENABLED=enabled;t.begin_producer('value-keys');af._COUNTER[0]=0
            out=[]
            for repeat in range(24):
                pairs=[('p',.01),('q',-.002),('zero',-0.0)]
                if repeat%4==1:pairs.reverse()
                center='1.00' if repeat%4==2 else '1.0'
                x=af._new_form(af.I,D(center),D(center),dict(pairs),.00001)
                y=x if repeat%3==0 else af._new_form(af.I,D(center),D(center),dict(pairs),.00001)
                zero=af.I(0)
                a=t.Time('a',x,terms=(('x',1,x),('other',2,y)))
                b=t.Time('b',zero,terms=(('x',0,x),('other',-1,y)))
                for _ in range(3):
                    z=a.minus(b)
                    state=lambda v:tuple(getattr(v,n) for n in memo._FIELDS)
                    out.append((snapshot(z),af._COUNTER[0],state(z),state(x),state(y)))
                    z._center();z.fingerprint()
            return out
        expected=trace(False);actual=trace(True)
        self.assertEqual(expected,actual)
        self.assertGreater(memo.STATS['hits'],20)

if __name__=='__main__':unittest.main()
