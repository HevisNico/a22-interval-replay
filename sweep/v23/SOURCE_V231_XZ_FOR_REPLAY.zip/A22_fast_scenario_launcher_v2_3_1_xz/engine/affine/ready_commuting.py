"""One endpoint enclosure for READY groups with constant gains/actuator.

Preconditions: no active gain deposit, no protected actuation history, and
only raw_on/off and mark_on/off events. Each port's order is certified.
These events update independent port flags; marks do not change the actuator
in READY, and admitted pulse amplitudes are fixed because gains are constant.
The complete pulse memory includes zero response before each future arrival.
A strict no-fire cover of the WHOLE group is required before using its common
endpoint. Thus all physically admissible interleavings have the same exact
endpoint map. Failed preconditions or cover fall back to full enumeration.
"""
STATS={'attempts':0,'resolved':0,'fallbacks':0}

def endpoint(b,s,group,U):
    STATS['attempts']+=1
    def no():STATS['fallbacks']+=1;return None
    if s['p']!=0 or s.get('memory') is None:return no()
    if any(h.active is not None for hs in s['depot'] for h in hs):return no()
    if any(h.fire is not None or h.marks for h in s['actuation']):return no()
    ports=[[],[],[]]
    for tt,actions in group:
        for action,j,origin in actions:
            if action not in ('raw_on','raw_off','mark_on','mark_off') or j not in (0,1,2):return no()
            ports[j].append((tt,(action,j,origin)))
    for events in ports:
        if sum(a[0]=='raw_on' for _,a in events)>1:return no()
        events.sort(key=lambda item:item[0].box().mid())
        previous=s['t']
        for tt,_ in events:
            if tt.minus(previous).lo<0 or U.minus(tt).lo<0:return no()
            previous=tt
    state=s.copy()
    try:
        for events in ports:
            for tt,action in events:
                state=dict(state,t=tt)
                state=b.act(state,[action])
    except (AssertionError,ValueError,ArithmeticError):return no()
    # The synthetic bookkeeping state has already admitted all future raw_on
    # terms, but the pulse evaluator supplies zero contribution before arrival.
    covered=dict(s,memory=state['memory'])
    if not b.READY_MEMORY_COVER(covered,U):return no()
    state=dict(state,t=s['t'])
    state=b.flowing(state,U,False)
    STATS['resolved']+=1
    if b.PROFILE is not None:
        b.PROFILE.relative_order_proofs.append(dict(guard='ready_commuting_group',
            start=s['t'].box().pair(),end=U.box().pair(),events=len(group),
            predicate='constant gains and actuator; per-port order; strict whole-window pulse-memory no-fire cover'))
    return state

def install(b):
    previous=b.CLUSTER_STATES
    def states(s,group,U):
        result=endpoint(b,s,group,U)
        if result is not None:yield result
        else:yield from previous(s,group,U)
    b.CLUSTER_STATES=states
