"""Conservative fallback for a recovery window with spurious fire branches.

No threshold, physical parameter or branch acceptance rule is changed.
The continued protected ledger is monotone in time. Strict interval signs
can therefore contract an already certified enclosure of its unique return.
The complete exterior queue supplies all marks that can affect this first
return. The existing finite-cycle cover then retains every weak event order,
with the return date additionally restricted by that order's neighbors.
"""
STATS = {'attempts': 0, 'resolved': 0, 'refused': 0, 'sign_probes': 0}


def contract_return(b, s, key, steps=20):
    from branche_retour_A19 import return_with_marks
    original = return_with_marks(s, key)
    lo, hi = original.box().lo, original.box().hi

    def ell(t):
        STATS['sign_probes'] += 1
        probe = b.dep.Time(key + ':sign-probe', b.I(t))
        # Never assume a mark has ended at a probe before its actual end.
        return b.ac.bounds(s['actuation'], probe, 'ell', live=False)

    left, right = lo, hi
    for _ in range(steps):
        mid = b.I(left, right).mid()
        if not left < mid < right:
            break
        if ell(mid).lo > 0:
            lo = left = mid
        else:
            right = mid
    left, right = lo, hi
    for _ in range(steps):
        mid = b.I(left, right).mid()
        if not left < mid < right:
            break
        if ell(mid).hi < 0:
            hi = right = mid
        else:
            left = mid
    # Keep the original shared expression. The new absolute enclosure is
    # an additional valid constraint, not a redefinition of any time atom.
    return b.dep.Time(key + ':sign-contracted', b.I(lo, hi),
                      terms=original.expression())


def window(b, s, pending, idx, cell, count):
    from retour_file_A22 import pending_window
    STATS['attempts'] += 1
    try:
        result = pending_window(s, pending, idx, cell, count,
            return_solver=lambda state, key: contract_return(b, state, key),
            contract_order=True)
    except b.v.Ambiguous:
        STATS['refused'] += 1
        return None
    forest, _, _ = result
    if not forest.branches or not all(
            not x.emissions and x.state['p'] == 0 for x in forest.branches):
        STATS['refused'] += 1
        return None
    STATS['resolved'] += 1
    return result
