"""Common endpoint of a protected fast/slow group with closed gain gates.

Raw and auxiliary flags are port-local. Mark ledger updates on distinct
ports commute, retaining every exact origin and gate endpoint. Gains cannot
change while admission is closed. The complete ledger evaluates the capped,
nonnegative recovery dose through U, including zero contribution before each
future mark. ell(U)>0 proves no READY return anywhere in the window. Together
with U>=fire+1 this proves one common SLOW endpoint for all interleavings.
The original complete enumeration remains the fallback.
"""
STATS={'attempts':0,'resolved':0,'fallbacks':0}

def endpoint(b,s,group,upper,cell,count):
    def no():STATS['fallbacks']+=1;return None
    STATS['attempts']+=1
    if s['p']!=1 or s.get('memory') is not None:return no()
    if any(h.active is not None for hs in s['depot'] for h in hs):return no()
    if any(h.fire is None or h.fire.token()!=s['fire'].token() for h in s['actuation']):return no()
    U=b.v.T(f'{cell}:protected-commuting-U:{count}',b.I(upper))
    if U.box().lo<s['fire'].plus(1).box().hi:return no()
    ports=[[],[],[]]
    allowed=('raw_on','raw_off','mark_on','mark_off','error_on','error_off')
    for tt,actions in group:
        if tt.box().lo<s['t'].box().hi:return no()
        for action,j,origin in actions:
            if action not in allowed or j not in (0,1,2):return no()
            ports[j].append((tt,(action,j,origin)))
    for events in ports:
        for kind in ('raw_on','mark_on','error_on'):
            if sum(a[0]==kind for _,a in events)>1:return no()
        events.sort(key=lambda item:item[0].box().mid())
        previous=s['t']
        for tt,_ in events:
            if not (tt.box().lo>=previous.box().hi or tt.minus(previous).lo>=0):return no()
            if U.box().lo<tt.box().hi:return no()
            previous=tt
    state=s.copy()
    try:
        for events in ports:
            for tt,action in events:
                state=dict(state,t=tt)
                state=b.act(state,[action])
        ell=b.ac.bounds(state['actuation'],U,'ell')
    except (AssertionError,ValueError,ArithmeticError):return no()
    if ell.lo<=0:return no()
    state=dict(state,t=U,q=b.R*ell.exp(),p=2,memory=None)
    state['b']=b.ac.bounds(state['actuation'],U)
    state['bstop']=state['b'].lo==state['b'].hi==b.D('1.1')
    state['z']=[b.dz.bounds(hs,U) for hs in state['depot']]
    state['caps']=[all(h.clamped for h in hs) for hs in state['depot']]
    STATS['resolved']+=1
    if b.PROFILE is not None:
        b.PROFILE.relative_order_proofs.append(dict(cell=cell,batch=count,
            guard='protected_commuting_group',start=s['t'].box().pair(),end=U.box().pair(),
            ell=ell.pair(),events=len(group),
            predicate='closed gain gates; commuting port ledgers; U>=fire+1; ell(U)>0'))
    return state,1

def install(b):
    previous=b.protected_section_cluster
    def resolve(s,group,upper,cell,count):
        out=endpoint(b,s,group,upper,cell,count)
        return previous(s,group,upper,cell,count) if out is None else out
    b.protected_section_cluster=resolve
