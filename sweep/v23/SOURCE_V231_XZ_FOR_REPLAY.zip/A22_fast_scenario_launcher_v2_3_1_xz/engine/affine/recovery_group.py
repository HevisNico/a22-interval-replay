"""Fix R (v3.3): protected recovery return overlapping an exterior event group.

unit() resolves a slow-recovery (p=2) refusal against a SINGLE exterior event
with the kernel's local-cycle resolver (cycle_local_A20.pending_window): it
encloses every admissible order of the return and the pending events, and
joins the forest only when every branch ends READY with no emission. The
group path (several overlapping events) had no such fallback and refused.
This module applies the SAME resolver and the SAME join rule to that path.

Preconditions (otherwise None, and the caller re-raises the original refusal):
  * the state is in slow recovery (p == 2);
  * the resolver certifies the window (its own checks: at most one additional
    fire, window shorter than the fast phase, no terminal event, branch budget);
  * every branch of the forest is READY with no emission.
No kernel map is modified and no branch is discarded.
"""
STATS = {'recovery_groups': 0}


def resolve(b, s, pending, idx, cell, count):
    if s['p'] != 2:
        return None
    from cycle_local_A20 import pending_window
    used_tightening = False
    try:
        forest, nextidx, handled = pending_window(s, pending, idx, cell, count)
    except b.v.Ambiguous:
        forest = None
    if forest is None or not forest.branches or not all(not x.emissions and x.state['p'] == 0 for x in forest.branches):
        from recovery_tightening import window
        tightened = window(b, s, pending, idx, cell, count)
        if tightened is None:
            return None
        forest, nextidx, handled = tightened
        used_tightening = True
    joined = b.join_states([x.state for x in forest.branches],
                           dict(cell=cell, batch=count, kind='local_cycle_no_emission_group'))
    # Branch-specific recovery anchors can prevent dep.join from retaining a
    # common pulse memory. All branches are READY at the common join time.
    # Re-anchor the READY ODE from its enclosing charge and active inputs,
    # using the kernel's usual new_memory construction. This drops previous
    # correlations but keeps every represented state and future input tail.
    # Tightened return dates carry branch-conditional absolute constraints.
    # Even equal underlying time tokens must not reuse just one branch's
    # narrowed memory anchor. Re-anchor the enclosing common READY state.
    if used_tightening or joined.get('memory') is None:
        joined['memory'] = b.new_memory(joined)
    if b.PROFILE is not None:
        b.PROFILE.relative_order_proofs.append(dict(cell=cell, batch=count, guard='recovery_group_local_cycle',
            events=len(handled), branches=len(forest.branches), certificate=str(forest.certificate)[:2000]))
    STATS['recovery_groups'] += 1
    return joined, nextidx, len(handled) + 1, len(forest.branches)
