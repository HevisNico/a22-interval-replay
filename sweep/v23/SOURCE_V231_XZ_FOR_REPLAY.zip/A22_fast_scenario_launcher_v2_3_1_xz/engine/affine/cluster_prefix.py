"""Reuse identical prefixes while retaining every admissible event order.

The event objects remain alive throughout the generator; identity keys cannot
alias distinct events or branches. Only exact identical ordered prefixes are
shared. No state is modified in place: flowing/act copy before updating, and
histories are immutable. This changes remainder allocation and kernel identity.
The finite cache budget affects reuse only, never coverage.
"""
STATS = {'hits':0,'misses':0,'groups':0}

def states(b,s,group,U,max_entries=2048,guardfree=True):
    STATS['groups'] += 1
    cache={}
    for order in b.admissible_orders(s,group):
        ss=s;key=()
        for event in order:
            key=key+(id(event),)
            if key in cache:
                ss=cache[key];STATS['hits']+=1
            else:
                tt,actions=event
                ss=b.act(b.flowing(ss,tt,guardfree),actions)
                STATS['misses']+=1
                if len(cache)<max_entries:cache[key]=ss
        yield b.flowing(ss,U,guardfree)
