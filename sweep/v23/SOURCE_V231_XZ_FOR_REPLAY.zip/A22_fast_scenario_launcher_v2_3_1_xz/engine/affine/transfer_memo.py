"""Bounded, allocation-exact replay of immutable completed charge transfers.

Cache hits reproduce fresh affine remainder names, allocator advancement,
lazy input effects and Decimal flags. Identity is a conservative cache key,
never a criterion for identifying distinct physical histories.
"""
from collections import OrderedDict
from decimal import getcontext
import os
import affine_iv as af
import intervalles_decimaux as iv
import temporal
import temporal_memo as tm

ENABLED = os.environ.get('A22_TRANSFER_MEMO', '1') != '0'
MAX_ENTRIES = 1024
MAX_COEFFICIENTS = 500000
_CACHE = OrderedDict()
_WEIGHT = 0
STATS = {}

def clear():
    global _WEIGHT
    _CACHE.clear(); _WEIGHT = 0
    STATS.clear(); STATS.update(hits=0, misses=0, evictions=0, entries=0,
                               retained_coefficients=0)

clear()

def _prepared_recipe(x, inputs, prefix, start, end):
    recipe = tm._recipe(x, inputs)
    if recipe is None:
        return None
    names = []
    if prefix is not None and end > start and recipe[2] is None:
        for key in x._d:
            if key.startswith(prefix):
                tail = key[len(prefix):]
                if tail.isascii() and tail.isdigit() and start < int(tail) <= end:
                    names.append((key, int(tail) - start))
    return recipe, tuple(names)

def _replay(prepared, prefix, start, inputs, made):
    if prepared is None:
        return None
    (x, fields, input_index), names = prepared
    if input_index is not None:
        return inputs[input_index]
    if x in made:
        return made[x]
    renamed = {key: prefix + str(start + offset) for key, offset in names}
    if renamed:
        d = {renamed.get(key, key): value for key, value in x._d.items()}
    else:
        d = x._d
    result = af._new_form(af.I, x.clo, x.chi, d, x.e)
    for name, value in zip(tm._FIELDS, fields):
        if name == '_key' and value is not None and renamed:
            value = (x.clo, x.chi, tuple(sorted(d.items())), x.e)
        object.__setattr__(result, name, value)
    if not renamed:
        object.__setattr__(result, '_memo_form_key', getattr(x, '_memo_form_key', None))
    made[x] = result
    return result

def wrap(reference):
    def transfer(segment, lam, high, low, scale):
        global _WEIGHT
        from actuations_A19 import Segment
        from depot_A19 import History
        if (not ENABLED or tm.ENABLED or type(lam) is not af.I
                or any(type(v) not in (str, int) for v in (high, low, scale))):
            return reference(segment, lam, high, low, scale)
        if type(segment) is Segment and segment.end is not None:
            times = (segment.origin, segment.start, segment.end)
            extra = ()
        elif type(segment) is History and type(segment.partial) is tuple and segment.partial:
            if any(type(s) is not Segment for s in segment.partial):
                return reference(segment, lam, high, low, scale)
            times = tuple(t for s in segment.partial for t in (s.origin, s.start, s.end))
            extra = (segment.initial,)
        else:
            return reference(segment, lam, high, low, scale)
        if any(type(t) is not temporal.Time for t in times):
            return reference(segment, lam, high, low, scale)
        inputs = (lam,) + extra + tuple(x for t in times for x in tm._forms(t))
        if any(type(x) is not af.I for x in inputs):
            return reference(segment, lam, high, low, scale)
        contexts = (iv.DOWN, iv.UP, iv.NEAR)
        unique = tuple(dict.fromkeys(inputs))
        key = (reference, id(segment), id(lam), high, low, scale,
               tuple(id(t._box) for t in times),
               af.FRESH, af.KMAX, af.ETHRESH, tm.ENABLED,
               tuple(tm.context_key(c) for c in contexts),
               tm.context_key(getcontext()),
               tuple(tm.state_key(x) for x in unique))
        start = af._COUNTER[0]
        prefix = None if af.FRESH is None else af.FRESH + '#'
        cached = _CACHE.get(key)
        if cached is not None:
            held_segment, held_lam, result, boxes, old_start, old_end, raised, effects, weight = cached
            if start >= old_start:
                for x, changes in effects:
                    for name, value in changes:
                        object.__setattr__(x, name, value)
                made = {}
                result = _replay(result, prefix, start, inputs, made)
                for t, recipe in zip(times, boxes):
                    if t._box is None:
                        object.__setattr__(t, '_box', _replay(recipe, prefix, start, inputs, made))
                af._COUNTER[0] = start + old_end - old_start
                for c, flags in zip(contexts, raised):
                    for flag in flags:
                        c.flags[flag] = True
                _CACHE.move_to_end(key); STATS['hits'] += 1
                return result
        STATS['misses'] += 1
        input_before = tuple(tuple(getattr(x, n) for n in tm._NUMERIC_FIELDS) for x in unique)
        before = tuple(dict(c.flags) for c in contexts)
        for c in contexts:
            c.clear_flags()
        try:
            result = reference(segment, lam, high, low, scale)
        finally:
            raised = tuple(tuple(f for f, v in c.flags.items() if v) for c in contexts)
            for c, flags in zip(contexts, before):
                for f, value in flags.items():
                    if value:
                        c.flags[f] = True
        end = af._COUNTER[0]
        # The temporal memo has observable internal state, so bypass this cache
        # when it is enabled. Its own differential tests remain authoritative.
        if tm.ENABLED or end < start or tm._future_input(unique, prefix, start):
            return result
        boxes = tuple(t._box for t in times)
        weight = sum(len(x._d) for x in unique + (result,) + tuple(x for x in boxes if x is not None))
        if weight > MAX_COEFFICIENTS:
            return result
        if key in _CACHE:
            _WEIGHT -= _CACHE.pop(key)[-1]
        while _CACHE and (len(_CACHE) >= MAX_ENTRIES or _WEIGHT + weight > MAX_COEFFICIENTS):
            _WEIGHT -= _CACHE.popitem(last=False)[1][-1]; STATS['evictions'] += 1
        effects = []
        for x, old in zip(unique, input_before):
            changes = tuple((n, getattr(x, n)) for n, v in zip(tm._NUMERIC_FIELDS, old) if getattr(x, n) is not v)
            if changes:
                effects.append((x, changes))
        _CACHE[key] = (segment, lam, _prepared_recipe(result, inputs, prefix, start, end),
                       tuple(_prepared_recipe(x, inputs, prefix, start, end) for x in boxes),
                       start, end, raised, tuple(effects), weight)
        _WEIGHT += weight
        STATS['entries'] = len(_CACHE); STATS['retained_coefficients'] = _WEIGHT
        return result
    return transfer

def install(engine):
    import flux_charge_A19 as flux
    original = flux.transfer
    accelerated = wrap(original)
    flux.transfer = accelerated
    engine.b.ac.charge_transfer = accelerated
    engine.b.dz.transfer = accelerated
    original_completed = engine.b.dz.completed
    def completed_reference(history, lam, high, low, scale):
        # offered() is already inside the existing per-port LAM adapter.
        return original_completed(history)
    completed = wrap(completed_reference)
    engine.b.dz.completed = lambda h: completed(h, engine.b.dz.LAM, '.1', '.025', 8)
