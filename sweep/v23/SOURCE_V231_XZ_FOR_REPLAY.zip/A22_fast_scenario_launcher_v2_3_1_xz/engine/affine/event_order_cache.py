"""Enumerate the same admissible orders with incremental prefix checks.

Pairwise date enclosures depend only on the immutable input dates. Cache each
directed pair's bounds within this enumeration (never infer reverse bounds).
An already accepted prefix need not be checked again: retain its earliest
feasible absolute date and check only the new adjacent pair and endpoint.
Discrete stage transitions, traversal order and both search budgets are kept.
No branch is merged or pruned without the original predicates.
"""
STATS={'pairs':0,'hits':0,'nodes':0,'orders':0}

def admissible_orders(b,s,events,budget=4096):
    events=tuple(events);emitted=0;visited=0
    expected={'mark_on':0,'mark_off':1,'error_on':2,'error_off':3}
    following={'mark_on':1,'mark_off':2,'error_on':3,'error_off':0}
    dates=[event[0] for event in events]+[s['t']]
    boxes=[date.box() for date in dates]
    cache={}
    def difference(i,j):
        key=(i,j)
        if key not in cache:
            delta=dates[i].minus(dates[j])
            cache[key]=(delta.lo,delta.hi);STATS['pairs']+=1
        else:STATS['hits']+=1
        return cache[key]
    def search(prefix,remaining,stages,raw,earliest,previous):
        nonlocal emitted,visited
        visited+=1;STATS['nodes']+=1
        if visited>65536:raise b.v.Ambiguous('event-order search-node budget exceeded')
        if not remaining:
            emitted+=1
            if emitted>budget:raise b.v.Ambiguous('admissible event-order budget exceeded')
            STATS['orders']+=1
            yield tuple(events[i] for i in prefix);return
        for k in remaining:
            if any(difference(k,j)[0]>0 for j in remaining if j!=k):continue
            if difference(k,previous)[1]<0:continue
            next_earliest=max(earliest,boxes[k].lo)
            if next_earliest>boxes[k].hi:continue
            aphase=stages.copy();rphase=raw.copy();valid=True
            for action,j,_ in events[k][1]:
                if action in expected:
                    if aphase[j]!=expected[action]:valid=False;break
                    aphase[j]=following[action]
                elif action=='raw_on':
                    if rphase[j]:valid=False;break
                    rphase[j]=True
                elif action=='raw_off':
                    if not rphase[j]:valid=False;break
                    rphase[j]=False
                elif action not in ('end','principal_ready'):
                    raise b.v.Ambiguous('unknown discrete event in order enumeration')
            if valid:
                yield from search(prefix+(k,),tuple(j for j in remaining if j!=k),
                                  aphase,rphase,next_earliest,k)
    yield from search((),tuple(range(len(events))),s['aux'].copy(),
                      [x is not None for x in s['raw']],boxes[-1].lo,len(events))

def install(b):
    b.admissible_orders=lambda s,events,budget=4096:admissible_orders(b,s,events,budget)
