"""Outward sum of affine clock atoms, with one final coefficient truncation.

Centers use directed Decimal addition. Binary64 coefficient sums retain an
outward error bound, and all input remainders are added outward. Truncation
and fresh remainder allocation occur only after the complete sum.
This changes numerical representations: it requires a new campaign.
"""
from affine_iv import I
from rounding import accumulate_coeff, scale_coeff, add_up
import intervalles_decimaux as iv

def sum_atoms(offset, atoms):
    lo = hi = offset
    coefficients = {}
    error = 0.0
    for n, value in atoms:
        if not n:
            continue
        if n == 1:
            vlo, vhi, vd, ve = value.clo, value.chi, value._d, value.e
        elif n == -1:
            vlo, vhi = value.chi.copy_negate(), value.clo.copy_negate()
            vd, extra = scale_coeff(value._d, -1.0)
            assert extra == 0.0
            ve = value.e
        else:
            scaled = n * value
            vlo, vhi, vd, ve = scaled.clo, scaled.chi, scaled._d, scaled.e
        lo = iv.DOWN.add(lo, vlo)
        hi = iv.UP.add(hi, vhi)
        rounding_error = accumulate_coeff(coefficients, vd)
        error = add_up(add_up(error, ve), rounding_error)
    return I.make(lo, hi, coefficients, error)


_reference_sum_atoms = sum_atoms
try:
    from rounding import BACKEND
    if BACKEND != 'native':
        raise ImportError
    from _rounding_native import time_sum_parts
except ImportError:
    pass
else:
    try:
        from _rounding_native import time_sum_key, time_sum_centers
    except ImportError:
        # An older native extension retains the existing exact cache path.
        def time_sum_key(atoms, cls):
            if any(type(n) is not int or n not in (-1, 0, 1) or type(v) is not cls
                   for n, v in atoms):
                return None
            return tuple((n, v) for n, v in atoms if n and (v._d or v.e))

        def time_sum_centers(offset, atoms, down, up):
            lo = hi = offset
            for n, v in atoms:
                if not n:
                    continue
                vl, vh = ((v.clo, v.chi) if n == 1 else
                          (v.chi.copy_negate(), v.clo.copy_negate()))
                lo = down.add(lo, vl)
                hi = up.add(hi, vh)
            return lo, hi

    from collections import OrderedDict
    import affine_iv as _af
    _parts_cache = OrderedDict()
    _cache_weight = 0
    MAX_CACHED_COEFFICIENTS = 500000
    MAX_CACHED_SUMS = 4096
    CACHE_STATS = {'hits': 0, 'misses': 0, 'bypasses': 0}

    def clear_cache():
        global _cache_weight
        _parts_cache.clear()
        _cache_weight = 0
        CACHE_STATS.update(hits=0, misses=0, bypasses=0)

    def sum_atoms(offset, atoms):
        """Replay only the pure coefficient reduction, in its original order.

        Directed Decimal centers are recomputed for every call. Truncation
        precedes fresh-noise allocation, which still happens on every call.
        Keys retain the exact immutable input objects; equality of displayed
        intervals never identifies two inputs. General multipliers retain the
        original path because they can allocate intermediate noise symbols.
        """
        global _cache_weight
        atoms = tuple(atoms)
        atom_key = time_sum_key(atoms, I)
        if atom_key is None:
            CACHE_STATS['bypasses'] += 1
            return I.make(*time_sum_parts(offset, atoms, iv.DOWN, iv.UP))
        key = (_af.KMAX, atom_key)
        cached = _parts_cache.get(key)
        if cached is None:
            CACHE_STATS['misses'] += 1
            lo, hi, coefficients, error = time_sum_parts(offset, atoms, iv.DOWN, iv.UP)
            if len(coefficients) > _af.KMAX:
                coefficients, extra = _af.truncate_coeff(coefficients, _af.KMAX)
                error = add_up(error, extra)
            weight = len(coefficients) + sum(len(v._d) for _, v in key[1])
            if weight <= MAX_CACHED_COEFFICIENTS:
                while _parts_cache and (len(_parts_cache) >= MAX_CACHED_SUMS or
                        _cache_weight + weight > MAX_CACHED_COEFFICIENTS):
                    _cache_weight -= _parts_cache.popitem(last=False)[1][2]
                _parts_cache[key] = (coefficients, error, weight)
                _cache_weight += weight
        else:
            CACHE_STATS['hits'] += 1
            _parts_cache.move_to_end(key)
            coefficients, error, _ = cached
            lo, hi = time_sum_centers(offset, atoms, iv.DOWN, iv.UP)
        return I.make(lo, hi, coefficients, error)
