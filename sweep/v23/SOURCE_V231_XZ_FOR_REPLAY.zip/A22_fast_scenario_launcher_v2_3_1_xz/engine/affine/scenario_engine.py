"""Whole-history continuation with shared device parameters across scenarios."""
from dataclasses import replace
import time

class Split(Exception):
    def __init__(self,result,count):self.result=result;self.count=count

def record(h):
    return dict(branch=h.branch,index=h.index,count=h.count,lineage=h.lineage)

def compute(e,temporal,layer,lane,trains,producer,physical_namespace,wall_seconds,budget):
    import histoires_A21 as histories
    import reprise_groupe_A22 as hook
    import retour_file_A22 as queue
    import cycle_local_A20 as cycle
    import recovery_tightening as tightening
    b=e.b;started=time.perf_counter()
    old_group=b.RECOVERY_GROUP
    old_anticipate,old_window=queue.anticipate,queue.pending_window
    old_step,old_share=histories.step,histories.share_identical
    def split(s,pending,idx,cell,count):
        # Same contract as recovery_group.resolve: only a SLOW recovery
        # return is eligible. Otherwise the caller re-raises its refusal.
        if s['p']!=2:return None
        result=tightening.window(b,s,pending,idx,cell,count)
        if result is None:result=cycle.pending_window(s,pending,idx,cell,count)
        if not result[0].branches:raise b.v.Ambiguous('Empty recovery cover')
        raise Split(result,count)
    b.RECOVERY_GROUP=split
    try:
        try:
            single=e.compute_cell(layer,lane,trains,producer,physical_namespace=physical_namespace)
        except (Split,b.v.Ambiguous,AssertionError) as error:
            # Only documented exterior-cluster assertions are eligible.
            if isinstance(error,AssertionError) and str(error) not in (
                'slow section inside external cluster (actuation ledger)',
                'internal crossing inside uncertain external cluster',
                'fast section inside external cluster'):
                raise
            tb=error.__traceback__
            while tb and tb.tb_frame.f_code is not b.unit.__code__:tb=tb.tb_next
            if tb is None:raise
            loc=tb.tb_frame.f_locals
            pending=tuple(loc['pending']);prefix=tuple(loc['out'])
            if isinstance(error,Split):
                forest,stop,handled=error.result
                initial=tuple(histories.History(replace(x,emissions=prefix+x.emissions),
                    stop,error.count+len(handled)+1,(i,)) for i,x in enumerate(forest.branches))
            else:
                initial=(histories.History(cycle.Branch(loc['s'],prefix),loc['idx'],loc['count'],(0,)),)
            def anticipate(s,pending,idx,key,return_solver=None):
                return old_anticipate(s,pending,idx,key,return_solver or
                    (lambda s,key:tightening.contract_return(b,s,key)))
            def window(s,pending,idx,cell,count,return_solver=None,contract_order=True):
                return old_window(s,pending,idx,cell,count,return_solver or
                    (lambda s,key:tightening.contract_return(b,s,key)),contract_order)
            queue.anticipate,queue.pending_window=anticipate,window
            histories.share_identical=lambda parent,children:(children,0)
            def step(h,pending,suffix,cell):
                if time.perf_counter()-started>wall_seconds:
                    raise b.v.Ambiguous('Scenario job time budget reached; frontier retained')
                return hook.step(h,pending,suffix,cell)
            histories.step=step
            try:
                done,metrics=histories.run(initial,pending,cell=f'{layer},{lane}:scenario',budget=budget)
            except histories.Refusal as refused:
                return dict(status='refused',finished=tuple(map(record,refused.finished)),
                    frontier=tuple(map(record,refused.frontier)),pending=pending,reason=str(refused))
            result=[]
            for h in done:
                validate_terminal(b,h.branch.state,h.branch.emissions)
                if h.index!=len(pending):raise ValueError('Unconsumed queue')
                result.append(dict(outputs=h.branch.emissions,state=h.branch.state,
                    conditions=h.branch.conditions,trace=h.branch.trace,lineage=h.lineage))
            if not result:raise ValueError('Empty terminal cover')
            return dict(status='complete',scenarios=tuple(result),metrics=metrics)
        else:
            state=single['state']['terminal_affine']
            validate_terminal(b,state,single['outputs'])
            return dict(status='complete',scenarios=(dict(outputs=single['outputs'],state=state,
                conditions=(),trace=(),lineage=()),),metrics=single['metrics'])
    finally:
        b.RECOVERY_GROUP=old_group
        queue.anticipate,queue.pending_window=old_anticipate,old_window
        histories.step,histories.share_identical=old_step,old_share

def validate_terminal(b,s,outputs):
    if s['t'].box().pair()!=['1116','1116'] or s['p']!=0 or s['raw']!=[None]*3 or s['aux']!=[0]*3:
        raise ValueError('Incomplete terminal state')
    if max(abs(x-b.D('.1')) for x in (s['q'].lo,s['q'].hi))>=b.D('1e-10'):
        raise ValueError('Terminal charge invariant')
    if not 0<s['b'].lo<=s['b'].hi<=b.D('1.1'):raise ValueError('Actuator invariant')
    if any(h.active is not None for hs in s['depot'] for h in hs):raise ValueError('Active terminal deposit')
    if any(h.fire is not None or h.marks for h in s['actuation']):raise ValueError('Protected terminal ledger')
    if not all(outputs[k+1].minus(outputs[k]).lo>b.D('1.3') for k in range(len(outputs)-1)):
        raise ValueError('Uncertified output pulse separation')
