"""Pointwise affine union without a dense branches-by-symbols scan.

Min/max coefficients include zero exactly when a symbol is absent from a
branch. The mass of missing common coefficients is summed exactly in binary
integer units (2**-1074) and then rounded upward once. Present coefficient
deviations keep the original directed rounding. Every input affine form is
therefore enclosed pointwise. Numerical representations may be tighter than
the reference hull; this requires a new kernel identity.
"""
from fractions import Fraction
import math,sys
import affine_iv as af
from rounding import add_up,finite

SCALE=1<<1074
STATS={'calls':0,'branches':0,'coefficients':0}

def mass_units(x):
    numerator,denominator=abs(x).as_integer_ratio()
    return numerator << (1074-(denominator.bit_length()-1))

def upward_mass(units):
    if not units:return 0.0
    value=Fraction(units,SCALE)
    out=finite(float(value))
    if Fraction.from_float(out)<value:out=finite(math.nextafter(out,math.inf))
    return out

def hull(values):
    values=list(values)
    if not values:raise ValueError('empty affine hull')
    if all(af._same(values[0],x) for x in values[1:]):return values[0]
    STATS['calls']+=1;STATS['branches']+=len(values)
    ranges={}
    for x in values:
        STATS['coefficients']+=len(x._d)
        for key,c in x._d.items():
            if key in ranges:
                entry=ranges[key]
                if c<entry[0]:entry[0]=c
                if c>entry[1]:entry[1]=c
                entry[2]+=1
            else:ranges[key]=[c,c,1]
    common={};weights={};total=0
    for key,(lo,hi,count) in ranges.items():
        if count<len(values):lo=min(lo,0.0);hi=max(hi,0.0)
        mid=lo if lo==hi else finite(0.5*lo+0.5*hi)
        if mid:
            common[key]=mid;weight=mass_units(mid);weights[key]=weight;total+=weight
    lower=[];upper=[]
    for x in values:
        radius=x.e;present=0
        for key,c in x._d.items():
            radius=add_up(radius,af._dev_up(c,common.get(key,0.0)))
            present+=weights.get(key,0)
        radius=add_up(radius,upward_mass(total-present))
        lower.append(af.iv.DOWN.subtract(x.clo,af.D(radius)) if radius else x.clo)
        upper.append(af.iv.UP.add(x.chi,af.D(radius)) if radius else x.chi)
    return af.I.make(min(lower),max(upper),common,0.0)

def install():
    old=af.hull
    for module in list(sys.modules.values()):
        if module is not None and getattr(module,'hull',None) is old:
            setattr(module,'hull',hull)
