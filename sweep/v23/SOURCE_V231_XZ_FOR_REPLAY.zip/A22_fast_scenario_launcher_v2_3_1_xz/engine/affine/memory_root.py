"""Fallback first root with a certified increasing pulse-memory trajectory.

A bracket proposal is accepted only with strict subthreshold initial value,
positive derivative over the entire pre-root window, positive endpoint and
a certified root strictly earlier than the next external boundary.
No parameter or event-order branch is discarded.
"""
STATS={'attempts':0,'resolved':0}

def install(e):
    b,I,D,iv=e.b,e.I,e.D,e.iv
    original=b.advance
    def advance(s,boundary,cell,count):
        try:return original(s,boundary,cell,count)
        except b.v.Ambiguous as error:
            if (str(error)!='ready guard still overlaps external boundary or possible tangency'
                    or s['p']!=0 or s.get('memory') is None):raise
            STATS['attempts']+=1
            import os
            verbose=os.environ.get('A22_ROOT_DEBUG')=='1'
            if verbose:print('MEMORY_ROOT_START',count,flush=True)
            H=boundary.minus(s['t']).lo
            if H<=0:raise
            probe=lambda u:b.shift(s['t'],u,f'{cell}:{count}:memory-root')
            f=lambda u:b.dep.evaluate(s['memory'],probe(u))-1
            df=lambda u:b.dep.evaluate(s['memory'],probe(u),True)
            if f(I(0)).hi>=0:raise
            for k in range(1,17):
                hi=iv.DOWN.divide(iv.DOWN.multiply(H,D(k)),D(16))
                value=f(I(hi));slope=df(I(0,hi))
                if verbose:print('MEMORY_ROOT_PROBE',count,k,str(hi),value.pair(),slope.pair(),flush=True)
                if hi<=0 or value.lo<0:continue
                if slope.lo<=0:continue
                try:
                    root=b.v.root(f,df,D(0),hi,b.v.guessroot(f,hi))
                    fire=probe(root)
                    if boundary.minus(fire).lo<=0:continue
                except (b.v.Ambiguous,ArithmeticError,AssertionError,ValueError):continue
                out=b.fire_reset(b.flowing(s,fire))
                STATS['resolved']+=1
                if b.PROFILE is not None:
                    b.PROFILE.guard('fire',fire)
                    b.PROFILE.relative_order_proofs.append(dict(cell=cell,batch=count,
                        guard='memory_monotone_root',bracket=root.pair(),
                        predicate='q(0)<1; q(hi)>=1; q_prime([0,hi])>0; fire<boundary'))
                return out,'fire'
            raise error
    b.advance=advance
