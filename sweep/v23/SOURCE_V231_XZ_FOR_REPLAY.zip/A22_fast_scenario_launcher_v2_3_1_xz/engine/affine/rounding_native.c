/* Conservative binary64 affine coefficient primitives.
 * IEEE round-to-nearest; no fast-math, no contraction. Each bound operation
 * advances to the next representable value separately. Overflow fails closed.
 */
#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <math.h>
#include <float.h>
#include <fenv.h>

static int valid(double a){
 if(!isfinite(a)){PyErr_SetString(PyExc_ArithmeticError,"non-finite affine arithmetic");return 0;}
 return 1;
}
static double au(double a,double b){double s=a+b;if(a&&b)s=nextafter(s,INFINITY);return s;}
static double mu(double a,double b){double p=a*b;if(a&&b)p=nextafter(p,INFINITY);return p;}
static double err(double v){return fmax(fabs(nextafter(v,INFINITY)-v),fabs(v-nextafter(v,-INFINITY)));}
static int put(PyObject*d,PyObject*k,double v){
 if(!valid(v))return 0;PyObject*p=PyFloat_FromDouble(v);if(!p)return 0;
 int ok=PyDict_SetItem(d,k,p)==0;Py_DECREF(p);return ok;
}
static PyObject *scale(PyObject*a,double s,double*error){
 PyObject*d=PyDict_New(),*k,*v;if(!d||!valid(s)){Py_XDECREF(d);return NULL;}
 Py_ssize_t pos=0;*error=0;
 while(PyDict_Next(a,&pos,&k,&v)){
  double x=PyFloat_AsDouble(v);if(PyErr_Occurred()||!valid(x)){Py_DECREF(d);return NULL;}
  double p=s*x;if(!put(d,k,p)){Py_DECREF(d);return NULL;}
  if(s&&x&&fabs(s)!=1)*error=au(*error,err(p));
 }
 if(!valid(*error)){Py_DECREF(d);return NULL;}return d;
}
/* Mutate only a private accumulator. Operation order and errors match add(). */
static int add_into(PyObject*d,PyObject*b,double*error){
 PyObject*k,*v;Py_ssize_t pos=0;*error=0;
 while(PyDict_Next(b,&pos,&k,&v)){
  double x=PyFloat_AsDouble(v);if(PyErr_Occurred()||!valid(x))return 0;
  PyObject*old=PyDict_GetItemWithError(d,k);
  if(old){
   double y=PyFloat_AsDouble(old);if(PyErr_Occurred()||!valid(y))return 0;
   double s=y+x;if(!put(d,k,s))return 0;
   if(x&&y&&y!=-x)*error=au(*error,err(s));
  } else if(PyErr_Occurred()||PyDict_SetItem(d,k,v)<0)return 0;
 }
 return valid(*error);
}
static PyObject *add(PyObject*a,PyObject*b,double*error){
 PyObject*d=PyDict_Copy(a);if(!d)return NULL;
 if(!add_into(d,b,error)){Py_DECREF(d);return NULL;}return d;
}
static PyObject *wrap_accumulate(PyObject*self,PyObject*args){
 PyObject*d,*b;if(!PyArg_ParseTuple(args,"O!O!",&PyDict_Type,&d,&PyDict_Type,&b))return NULL;
 if(d==b){PyErr_SetString(PyExc_ValueError,"accumulator must not alias input");return NULL;}
 double e;if(!add_into(d,b,&e))return NULL;
 return PyFloat_FromDouble(e);
}
/* Batch a clock sum without copying its growing coefficient dictionary.
 * Decimal centers and binary64 errors follow the reference order exactly.
 * General integer multipliers still invoke the original affine __mul__.
 */
static PyObject *wrap_time_sum(PyObject*self,PyObject*args){
 PyObject *offset,*atoms,*down,*up;
 if(!PyArg_ParseTuple(args,"OOOO",&offset,&atoms,&down,&up))return NULL;
 PyObject *iter=PyObject_GetIter(atoms),*coeff=PyDict_New();
 PyObject *lo=Py_NewRef(offset),*hi=Py_NewRef(offset),*item=NULL;
 PyObject *one=PyLong_FromLong(1),*minus=PyLong_FromLong(-1);
 PyObject *da=PyObject_GetAttrString(down,"add"),*ua=PyObject_GetAttrString(up,"add");
 double error=0.;
 if(!iter||!coeff||!one||!minus||!da||!ua)goto fail;
 while((item=PyIter_Next(iter))){
  PyObject *pair=PySequence_Fast(item,"atom pair required");Py_CLEAR(item);
  if(!pair)goto fail;
  if(PySequence_Fast_GET_SIZE(pair)!=2){Py_DECREF(pair);PyErr_SetString(PyExc_ValueError,"atom pair required");goto fail;}
  PyObject *n=PySequence_Fast_GET_ITEM(pair,0),*value=PySequence_Fast_GET_ITEM(pair,1);
  int nonzero=PyObject_IsTrue(n);
  if(nonzero<0){Py_DECREF(pair);goto fail;}
  if(!nonzero){Py_DECREF(pair);continue;}
  int positive=PyObject_RichCompareBool(n,one,Py_EQ);
  int negative=positive==0?PyObject_RichCompareBool(n,minus,Py_EQ):0;
  if(positive<0||negative<0){Py_DECREF(pair);goto fail;}
  PyObject *v=positive||negative?Py_NewRef(value):PyNumber_Multiply(n,value);
  Py_DECREF(pair);if(!v)goto fail;
  PyObject *vl=PyObject_GetAttrString(v,negative?"chi":"clo");
  PyObject *vh=PyObject_GetAttrString(v,negative?"clo":"chi");
  PyObject *vd=PyObject_GetAttrString(v,"_d"),*ve=PyObject_GetAttrString(v,"e");
  Py_DECREF(v);
  if(vl&&vh&&negative){
   PyObject *nl=PyObject_CallMethod(vl,"copy_negate",NULL);
   PyObject *nh=nl?PyObject_CallMethod(vh,"copy_negate",NULL):NULL;
   Py_SETREF(vl,nl);Py_SETREF(vh,nh);
  }
  if(!vl||!vh||!vd||!ve){Py_XDECREF(vl);Py_XDECREF(vh);Py_XDECREF(vd);Py_XDECREF(ve);goto fail;}
  if(!PyDict_Check(vd)){
   Py_DECREF(vl);Py_DECREF(vh);Py_DECREF(vd);Py_DECREF(ve);
   PyErr_SetString(PyExc_TypeError,"affine coefficients must be a dictionary");goto fail;
  }
  /* The reference scales -1 coefficients before adding Decimal centers. */
  PyObject *source=vd;
  if(negative){double ignored;source=scale(vd,-1.,&ignored);Py_DECREF(vd);}
  if(!source){Py_DECREF(vl);Py_DECREF(vh);Py_DECREF(ve);goto fail;}
  PyObject *nl=PyObject_CallFunctionObjArgs(da,lo,vl,NULL);
  PyObject *nh=nl?PyObject_CallFunctionObjArgs(ua,hi,vh,NULL):NULL;
  Py_DECREF(vl);Py_DECREF(vh);
  if(!nl||!nh){Py_XDECREF(nl);Py_XDECREF(nh);Py_DECREF(source);Py_DECREF(ve);goto fail;}
  Py_SETREF(lo,nl);Py_SETREF(hi,nh);
  double rounding_error,ev=PyFloat_AsDouble(ve);Py_DECREF(ve);
  if(PyErr_Occurred()||!valid(ev)){Py_DECREF(source);goto fail;}
  if(ev<0){Py_DECREF(source);PyErr_SetString(PyExc_ArithmeticError,"negative error bound");goto fail;}
  if(!add_into(coeff,source,&rounding_error)){Py_DECREF(source);goto fail;}
  Py_DECREF(source);
  error=au(error,ev);if(!valid(error))goto fail;
  error=au(error,rounding_error);if(!valid(error))goto fail;
 }
 if(PyErr_Occurred())goto fail;
 Py_DECREF(iter);Py_DECREF(one);Py_DECREF(minus);Py_DECREF(da);Py_DECREF(ua);
 return Py_BuildValue("NNNd",lo,hi,coeff,error);
fail:
 Py_XDECREF(item);Py_XDECREF(iter);Py_XDECREF(coeff);Py_XDECREF(lo);Py_XDECREF(hi);
 Py_XDECREF(one);Py_XDECREF(minus);Py_XDECREF(da);Py_XDECREF(ua);return NULL;
}
static PyObject *wrap_add(PyObject*self,PyObject*args){
 PyObject*a,*b;if(!PyArg_ParseTuple(args,"O!O!",&PyDict_Type,&a,&PyDict_Type,&b))return NULL;
 double e;PyObject*d=add(a,b,&e);return d?Py_BuildValue("Nd",d,e):NULL;
}
static PyObject *wrap_scale(PyObject*self,PyObject*args){
 PyObject*a;double s;if(!PyArg_ParseTuple(args,"O!d",&PyDict_Type,&a,&s))return NULL;
 double e;PyObject*d=scale(a,s,&e);return d?Py_BuildValue("Nd",d,e):NULL;
}
static PyObject *wrap_multiply(PyObject*self,PyObject*args){
 PyObject*a,*b;double mx,my;if(!PyArg_ParseTuple(args,"O!O!dd",&PyDict_Type,&a,&PyDict_Type,&b,&mx,&my))return NULL;
 double ae,be,ce;PyObject*ad=scale(a,my,&ae);if(!ad)return NULL;
 PyObject*bd=scale(b,mx,&be);if(!bd){Py_DECREF(ad);return NULL;}
 int ok=add_into(ad,bd,&ce);Py_DECREF(bd);
 if(!ok){Py_DECREF(ad);return NULL;}PyObject*d=ad;
 double e=au(au(ae,be),ce);if(!valid(e)){Py_DECREF(d);return NULL;}
 return Py_BuildValue("Nd",d,e);
}
static PyObject *wrap_sum(PyObject*self,PyObject*a){
 if(!PyDict_Check(a)){PyErr_SetString(PyExc_TypeError,"dictionary required");return NULL;}
 PyObject*k,*v;Py_ssize_t pos=0;double s=0;
 while(PyDict_Next(a,&pos,&k,&v)){
  double x=PyFloat_AsDouble(v);if(PyErr_Occurred()||!valid(x))return NULL;
  s=au(s,fabs(x));
 }
 return valid(s)?PyFloat_FromDouble(s):NULL;
}
static PyObject *bound(PyObject*args,int mult){
 double a,b;if(!PyArg_ParseTuple(args,"dd",&a,&b))return NULL;
 if(!valid(a)||!valid(b))return NULL;
 if(a<0||b<0){PyErr_SetString(PyExc_ArithmeticError,"negative error bound");return NULL;}
 double s=mult?mu(a,b):au(a,b);return valid(s)?PyFloat_FromDouble(s):NULL;
}
static PyObject *wrap_au(PyObject*s,PyObject*a){return bound(a,0);}
static PyObject *wrap_mu(PyObject*s,PyObject*a){return bound(a,1);}
/* Initialize already-validated affine values without ten Python-level
 * __setattr__ calls. Does not change arithmetic, truncate or promote noise. */
static PyObject *form_names[10];
static PyObject *wrap_new_form(PyObject*self,PyObject*args){
 PyObject *cls,*lo,*hi,*coeff,*error;
 if(!PyArg_ParseTuple(args,"OOOO!O",&cls,&lo,&hi,&PyDict_Type,&coeff,&error))return NULL;
 if(!PyType_Check(cls)){PyErr_SetString(PyExc_TypeError,"type required");return NULL;}
 PyObject *obj=((PyTypeObject*)cls)->tp_alloc((PyTypeObject*)cls,0);
 if(!obj)return NULL;
 PyObject *d=PyDict_Copy(coeff);
 if(!d){Py_DECREF(obj);return NULL;}
 PyObject *values[]={lo,hi,d,error,Py_None,Py_None,Py_None,Py_None,Py_None,Py_None};
 for(int i=0;i<10;i++){
  if(PyObject_GenericSetAttr(obj,form_names[i],values[i])<0){Py_DECREF(d);Py_DECREF(obj);return NULL;}
 }
 Py_DECREF(d);return obj;
}

/* Keep the kmax largest |coefficients| (ties: first in dict order), return
   (kept dict, upward-rounded sum of the dropped |coefficients|).
   Same rule and same left-to-right outward summation as rounding.truncate_coeff. */
static PyObject *wrap_truncate(PyObject*self,PyObject*args){
 PyObject*a,*k,*v;Py_ssize_t kmax,pos=0,n,i=0;
 if(!PyArg_ParseTuple(args,"O!n",&PyDict_Type,&a,&kmax))return NULL;
 if(kmax<1){PyErr_SetString(PyExc_ValueError,"kmax must be positive");return NULL;}
 n=PyDict_Size(a);
 if(n<=kmax){PyObject*c=PyDict_Copy(a);return c?Py_BuildValue("Nd",c,0.0):NULL;}
 double*m=PyMem_Malloc((size_t)n*sizeof(double));if(!m)return PyErr_NoMemory();
 while(PyDict_Next(a,&pos,&k,&v)){
  double x=PyFloat_AsDouble(v);if(PyErr_Occurred()||!valid(x)){PyMem_Free(m);return NULL;}
  m[i++]=fabs(x);
 }
 /* quickselect: value of rank kmax-1 in descending order (exact, no float ops) */
 Py_ssize_t lo=0,hi=n-1,want=kmax-1;
 while(lo<hi){
  double piv=m[lo+(hi-lo)/2];Py_ssize_t i2=lo,j2=hi;
  while(i2<=j2){while(m[i2]>piv)i2++;while(m[j2]<piv)j2--;if(i2<=j2){double t=m[i2];m[i2]=m[j2];m[j2]=t;i2++;j2--;}}
  if(want<=j2)hi=j2;else if(want>=i2)lo=i2;else break;
 }
 double thr=m[want];Py_ssize_t above=0;for(Py_ssize_t r=0;r<n;r++)if(m[r]>thr)above++;
 Py_ssize_t ties=kmax-above;PyMem_Free(m);
 PyObject*d=PyDict_New();if(!d)return NULL;double extra=0;pos=0;
 while(PyDict_Next(a,&pos,&k,&v)){
  double x=PyFloat_AsDouble(v),ax=fabs(x);
  if(ax>thr||(ax==thr&&ties>0)){
   if(ax==thr)ties--;
   if(PyDict_SetItem(d,k,v)<0){Py_DECREF(d);return NULL;}
  } else extra=au(extra,ax);
 }
 if(!valid(extra)){Py_DECREF(d);return NULL;}
 return Py_BuildValue("Nd",d,extra);
}

/* Cache helpers: do not perform coefficient arithmetic or allocate symbols.
 * Keep the exact original ordered Decimal operations, including flags/traps. */
static PyObject *wrap_time_sum_key(PyObject*self,PyObject*args){
 PyObject *atoms,*cls,*items=NULL,*keys=NULL,*result=NULL;
 if(!PyArg_ParseTuple(args,"OO",&atoms,&cls))return NULL;
 if(!PyType_Check(cls)){PyErr_SetString(PyExc_TypeError,"affine type required");return NULL;}
 items=PySequence_Fast(atoms,"time atoms required");if(!items)return NULL;
 keys=PyList_New(0);if(!keys)goto end;
 for(Py_ssize_t i=0;i<PySequence_Fast_GET_SIZE(items);i++){
  PyObject *pair=PySequence_Fast(PySequence_Fast_GET_ITEM(items,i),"time atom pair required");
  if(!pair)goto end;
  if(PySequence_Fast_GET_SIZE(pair)!=2){Py_DECREF(pair);PyErr_SetString(PyExc_ValueError,"time atom pair required");goto end;}
  PyObject *n=PySequence_Fast_GET_ITEM(pair,0),*v=PySequence_Fast_GET_ITEM(pair,1);
  if(!PyLong_CheckExact(n)||Py_TYPE(v)!=(PyTypeObject*)cls){Py_DECREF(pair);result=Py_NewRef(Py_None);goto end;}
  int overflow=0;long count=PyLong_AsLongAndOverflow(n,&overflow);
  if(PyErr_Occurred()){Py_DECREF(pair);goto end;}
  if(overflow||count < -1||count > 1){Py_DECREF(pair);result=Py_NewRef(Py_None);goto end;}
  if(count){
   PyObject *d=PyObject_GetAttr(v,form_names[2]),*e=NULL;
   if(!d){Py_DECREF(pair);goto end;}
   int nonempty=PyObject_IsTrue(d);Py_DECREF(d);
   if(nonempty<0){Py_DECREF(pair);goto end;}
   if(!nonempty){e=PyObject_GetAttr(v,form_names[3]);if(!e){Py_DECREF(pair);goto end;}nonempty=PyObject_IsTrue(e);Py_DECREF(e);}
   if(nonempty<0){Py_DECREF(pair);goto end;}
   if(nonempty){PyObject *key=PyTuple_Pack(2,n,v);if(!key){Py_DECREF(pair);goto end;}int ok=PyList_Append(keys,key);Py_DECREF(key);if(ok<0){Py_DECREF(pair);goto end;}}
  }
  Py_DECREF(pair);
 }
 result=PyList_AsTuple(keys);
end:
 Py_XDECREF(items);Py_XDECREF(keys);return result;
}

static PyObject *wrap_time_sum_centers(PyObject*self,PyObject*args){
 PyObject *offset,*atoms,*down,*up,*items=NULL,*da=NULL,*ua=NULL,*lo=NULL,*hi=NULL,*result=NULL;
 if(!PyArg_ParseTuple(args,"OOOO",&offset,&atoms,&down,&up))return NULL;
 items=PySequence_Fast(atoms,"time atoms required");if(!items)return NULL;
 da=PyObject_GetAttrString(down,"add");ua=PyObject_GetAttrString(up,"add");
 if(!da||!ua)goto end;
 lo=Py_NewRef(offset);hi=Py_NewRef(offset);
 for(Py_ssize_t i=0;i<PySequence_Fast_GET_SIZE(items);i++){
  PyObject *pair=PySequence_Fast(PySequence_Fast_GET_ITEM(items,i),"time atom pair required");
  if(!pair)goto end;
  if(PySequence_Fast_GET_SIZE(pair)!=2){Py_DECREF(pair);PyErr_SetString(PyExc_ValueError,"time atom pair required");goto end;}
  PyObject *n=PySequence_Fast_GET_ITEM(pair,0),*v=PySequence_Fast_GET_ITEM(pair,1);
  if(!PyLong_CheckExact(n)){Py_DECREF(pair);PyErr_SetString(PyExc_TypeError,"exact integer multiplier required");goto end;}
  int overflow=0;long count=PyLong_AsLongAndOverflow(n,&overflow);
  if(PyErr_Occurred()){Py_DECREF(pair);goto end;}
  if(overflow||count < -1||count > 1){Py_DECREF(pair);PyErr_SetString(PyExc_ValueError,"unit multiplier required");goto end;}
  if(!count){Py_DECREF(pair);continue;}
  PyObject *vl=PyObject_GetAttr(v,form_names[count==1?0:1]),*vh=PyObject_GetAttr(v,form_names[count==1?1:0]);
  Py_DECREF(pair);
  if(!vl||!vh){Py_XDECREF(vl);Py_XDECREF(vh);goto end;}
  if(count<0){
   PyObject *nl=PyObject_CallMethod(vl,"copy_negate",NULL),*nh=nl?PyObject_CallMethod(vh,"copy_negate",NULL):NULL;
   Py_DECREF(vl);Py_DECREF(vh);vl=nl;vh=nh;
   if(!vl||!vh){Py_XDECREF(vl);Py_XDECREF(vh);goto end;}
  }
  PyObject *nl=PyObject_CallFunctionObjArgs(da,lo,vl,NULL),*nh=nl?PyObject_CallFunctionObjArgs(ua,hi,vh,NULL):NULL;
  Py_DECREF(vl);Py_DECREF(vh);
  if(!nl||!nh){Py_XDECREF(nl);Py_XDECREF(nh);goto end;}
  Py_SETREF(lo,nl);Py_SETREF(hi,nh);
 }
 result=PyTuple_Pack(2,lo,hi);
end:
 Py_XDECREF(items);Py_XDECREF(da);Py_XDECREF(ua);Py_XDECREF(lo);Py_XDECREF(hi);return result;
}

static PyMethodDef methods[]={
 {"time_sum_key",wrap_time_sum_key,METH_VARARGS,NULL},
 {"time_sum_centers",wrap_time_sum_centers,METH_VARARGS,NULL},
 {"time_sum_parts",wrap_time_sum,METH_VARARGS,NULL},
 {"accumulate_coeff",wrap_accumulate,METH_VARARGS,NULL},{"sum_abs",wrap_sum,METH_O,NULL},{"add_coeff",wrap_add,METH_VARARGS,NULL},
 {"scale_coeff",wrap_scale,METH_VARARGS,NULL},{"multiply_coeff",wrap_multiply,METH_VARARGS,NULL},
 {"add_up",wrap_au,METH_VARARGS,NULL},{"mul_up",wrap_mu,METH_VARARGS,NULL},
 {"new_form",wrap_new_form,METH_VARARGS,NULL},{"truncate_coeff",wrap_truncate,METH_VARARGS,NULL},{NULL,NULL,0,NULL}};
static struct PyModuleDef mod={PyModuleDef_HEAD_INIT,"_rounding_native",NULL,-1,methods};
PyMODINIT_FUNC PyInit__rounding_native(void){
 if(FLT_RADIX!=2||DBL_MANT_DIG!=53||DBL_MAX_EXP!=1024||fegetround()!=FE_TONEAREST){
  PyErr_SetString(PyExc_ImportError,"IEEE binary64 round-to-nearest required");return NULL;
 }
 const char *names[]={"clo","chi","_d","e","_r","_lo","_hi","_dr","_mc","_key"};
 for(int i=0;i<10;i++){form_names[i]=PyUnicode_InternFromString(names[i]);if(!form_names[i])return NULL;}
 return PyModule_Create(&mod);
}
