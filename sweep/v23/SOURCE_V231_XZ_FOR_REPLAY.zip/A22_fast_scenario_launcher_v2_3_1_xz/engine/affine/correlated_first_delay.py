"""Uniform optional enclosure rule for each port's first auxiliary delay.

Use the engine's initial uncertainty DELTA. Initial ERROR tails have finished
by U0; READY offsets decay freely. If any hypothesis is unverified, keep the
existing enclosure. There is no layer, lane or namespace selection.
"""
def tighten(b, inputs):
    I=b.I
    delays=list(b.D1_PORTS)
    records=[]
    for port,train in enumerate(inputs):
        row={'port':port, 'status':'unchanged'}
        records.append(row)
        if not train:
            row['reason']='empty_input'
            continue
        lower=train[0].box().lo
        row['first_arrival_lower']=str(lower)
        row['initial_delta_upper']=str(b.DELTA.hi)
        if lower<=b.U0.hi:
            row['reason']='first_arrival_not_strictly_after_U0'
            continue
        memory=I(b.DELTA.hi)*(-b.K*I(lower)).exp()
        dh=b.A/(b.A-b.K)*(b.A*(-b.A*I('.1')).exp()-b.K*(-b.K*I('.1')).exp())
        slope=I(b.M.lo)*dh-b.K*memory
        row.update(memory_upper=str(memory.hi), slope_lower=str(slope.lo))
        if slope.lo<=0:
            row['reason']='slope_not_proved_positive'
            continue
        radius=(memory/I(slope.lo)).hi
        d=b.D0_PORTS[port]+I(-radius,radius)
        row['delay_radius']=str(radius)
        if not 0<d.lo<=d.hi<I('.1').lo:
            row['reason']='root_domain_not_proved'
            continue
        # Require marginal containment as well as the physical correlation
        # lemma, so the rule cannot enlarge the previous first-delay range.
        old=delays[port]
        if not old.lo<=d.lo<=d.hi<=old.hi:
            row['reason']='marginal_containment_not_proved'
            continue
        delays[port]=d
        row.update(status='tightened', old_D1=old.pair(), new_D1=d.pair())
    b.D1_PORTS=tuple(delays)
    return records
