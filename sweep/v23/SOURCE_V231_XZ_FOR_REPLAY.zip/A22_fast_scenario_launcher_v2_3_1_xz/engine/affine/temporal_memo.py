"""Bounded exact replay of Time.minus, including affine allocation effects.

This cache never identifies atoms by their labels or by marginal intervals.
Keys retain complete ordered affine representations, input alias patterns,
lazy arithmetic state, complete time expressions, box-cache state, Decimal
context settings/traps and affine configuration. Hashes are lookup aids;
full representations are always compared, never hashes alone.
Fresh remainder names are replayed at their original relative allocation
positions, including allocations whose values were discarded. Thus a cache
hit reproduces the uncached operation rather than adding correlations.
"""
from collections import OrderedDict
from decimal import getcontext
import os
import affine_iv as af
import intervalles_decimaux as iv

# Optimized profile: transfer/subtotal replay replaces the heavier time memo.
# Explicit A22_EXACT_TIME_MEMO=1 remains available for differential checks.
ENABLED = os.environ.get('A22_EXACT_TIME_MEMO', '0') != '0'
MAX_ENTRIES = 4096
MAX_COEFFICIENTS = 2000000
_CACHE = OrderedDict()
_WEIGHT = 0
STATS = {}

def clear():
    global _WEIGHT
    _CACHE.clear(); _WEIGHT = 0
    STATS.clear(); STATS.update(hits=0, misses=0, evictions=0,
                               replayed_allocations=0, entries=0,
                               retained_coefficients=0)

clear()

def context_key(c):
    return (c.prec, c.rounding, c.Emin, c.Emax, c.capitals, c.clamp,
            tuple(c.traps.items()))

class _FormKey:
    __slots__ = ('value','cached_hash')
    def __init__(self,value):
        self.value=value;self.cached_hash=hash(value)
    def __hash__(self):return self.cached_hash
    def __eq__(self,other):
        if self is other:return True
        if type(other) is not _FormKey:return NotImplemented
        return self.value==other.value

def form_key(x):
    value = getattr(x,'_memo_form_key',None)
    if value is None:
        value = _FormKey((str(x.clo),str(x.chi),tuple((k,v.hex()) for k,v in x._d.items()),x.e.hex()))
        object.__setattr__(x,'_memo_form_key',value)
    return value

_NUMERIC_FIELDS = ('_r','_lo','_hi','_dr','_mc')

def state_key(x):
    values = (x._r,x._lo,x._hi,x._dr,x._mc)
    cached = getattr(x,'_memo_state_key',None)
    if cached is not None:
        old=cached[0]
        if values[0] is old[0] and values[1] is old[1] and values[2] is old[2] and values[3] is old[3] and values[4] is old[4]:
            return cached[1]
    r,lo,hi,dr,mc = values
    key = (None if r is None else r.hex(),None if lo is None else str(lo),
           None if hi is None else str(hi),None if dr is None else dr.hex(),
           None if mc is None else tuple(v.hex() for v in mc))
    object.__setattr__(x,'_memo_state_key',(values,key))
    return key

def time_key(t):
    return (form_key(t.base),str(t.offset),
            tuple((k,n,form_key(v)) for k,n,v in t.terms),
            None if t._box is None else form_key(t._box))

def _forms(t):
    return (t.base,) + tuple(v for _, _, v in t.terms) + (() if t._box is None else (t._box,))

def _future_input(forms, prefix, start):
    if prefix is None:
        return False
    for x in forms:
        for key in x._d:
            if key.startswith(prefix):
                tail = key[len(prefix):]
                if tail.isascii() and tail.isdigit() and int(tail) > start:
                    return True
    return False

_FIELDS = ('_r','_lo','_hi','_dr','_mc','_key')

def _recipe(x, inputs):
    if x is None:
        return None
    index = next((i for i,v in enumerate(inputs) if x is v),None)
    return (x, tuple(getattr(x,name) for name in _FIELDS), index)

def _replay(recipe, prefix, old_start, old_end, new_start, inputs, made):
    if recipe is None:
        return None
    x, fields, input_index = recipe
    if input_index is not None:
        return inputs[input_index]
    if x in made:
        return made[x]
    d = {}
    changed = False
    for key, value in x._d.items():
        renamed = key
        if prefix is not None and key.startswith(prefix):
            tail = key[len(prefix):]
            if tail.isascii() and tail.isdigit():
                n = int(tail)
                if old_start < n <= old_end:
                    renamed = prefix + str(new_start + n - old_start)
        changed |= renamed != key
        d[renamed] = value
    # No make(): replay must neither truncate again nor allocate extra noise.
    result = af._new_form(af.I, x.clo, x.chi, d, x.e)
    for name, value in zip(_FIELDS, fields):
        if name == '_key' and value is not None:
            value = (x.clo,x.chi,tuple(sorted(d.items())),x.e)
        object.__setattr__(result,name,value)
    if not changed:
        object.__setattr__(result,'_memo_form_key',getattr(x,'_memo_form_key',None))
    made[x] = result
    return result

def difference(left, right, reference):
    global _WEIGHT
    if not ENABLED:
        return reference(left, right)
    # Custom subclasses can override numerical methods; the reference path
    # remains authoritative for values outside the installed concrete types.
    time_type = reference.__globals__['Time']
    if type(left) is not time_type or type(right) is not time_type:
        return reference(left, right)
    inputs = _forms(left) + _forms(right)
    if any(type(x) is not af.I for x in inputs):
        return reference(left, right)
    contexts = (iv.DOWN, iv.UP, iv.NEAR)
    seen = {};first_indices=[];alias_list=[]
    for index,x in enumerate(inputs):
        group=seen.get(x)
        if group is None:
            group=len(seen);seen[x]=group;first_indices.append(index)
        alias_list.append(group)
    unique=tuple(seen);aliases=tuple(alias_list)
    key = (time_key(left), time_key(right), af.FRESH, af.KMAX, af.ETHRESH,
           tuple(context_key(c) for c in contexts), context_key(getcontext()),
           aliases,tuple(state_key(x) for x in unique))
    input_before = tuple(getattr(x,'_memo_state_key')[0] for x in unique)
    start = af._COUNTER[0]
    cached = _CACHE.get(key)
    if cached is not None:
        result, boxes, old_start, old_end, raised, input_effects, weight = cached
        # A counter reset inside the same producer must not collide with an
        # input's existing symbols. Normal producer resets clear the cache.
        prefix = None if af.FRESH is None else af.FRESH + '#'
        if start < old_start and _future_input(_forms(left) + _forms(right), prefix, start):
            cached = None
        else:
            for index,effects in input_effects:
                for name,value in effects:
                    object.__setattr__(inputs[index],name,value)
            made = {}
            result = _replay(result, prefix, old_start, old_end, start,inputs,made)
            if left._box is None:
                object.__setattr__(left, '_box', _replay(boxes[0], prefix, old_start, old_end, start,inputs,made))
            if right._box is None:
                object.__setattr__(right, '_box', _replay(boxes[1], prefix, old_start, old_end, start,inputs,made))
            af._COUNTER[0] = start + old_end - old_start
            for c, flags in zip(contexts, raised):
                for flag in flags:
                    c.flags[flag] = True
            _CACHE.move_to_end(key)
            STATS['hits'] += 1
            STATS['replayed_allocations'] += old_end - old_start
            return result
    STATS['misses'] += 1
    before = tuple(dict(c.flags) for c in contexts)
    for c in contexts:
        c.clear_flags()
    try:
        result = reference(left, right)
    finally:
        raised = tuple(tuple(f for f, v in c.flags.items() if v) for c in contexts)
        for c, flags in zip(contexts, before):
            for f, value in flags.items():
                if value:
                    c.flags[f] = True
    end = af._COUNTER[0]
    forms = _forms(left) + _forms(right)
    prefix = None if af.FRESH is None else af.FRESH + '#'
    # Never cache forged/future allocator names supplied as input.
    if end < start or _future_input(forms, prefix, end):
        return result
    # Only the pre-call inputs can conflict with the newly allocated span;
    # boxes created by this call legitimately contain those new names.
    if _future_input(unique, prefix, start):
        return result
    boxes = (left._box, right._box)
    weight = sum(len(x._d) for x in inputs + (result,) + tuple(x for x in boxes if x is not None))
    if weight > MAX_COEFFICIENTS:
        return result
    if key in _CACHE:
        _WEIGHT -= _CACHE.pop(key)[-1]
    while _CACHE and (len(_CACHE) >= MAX_ENTRIES or _WEIGHT + weight > MAX_COEFFICIENTS):
        _WEIGHT -= _CACHE.popitem(last=False)[1][-1]
        STATS['evictions'] += 1
    input_effects=[]
    for index,x,old in zip(first_indices,unique,input_before):
        effects=tuple((name,getattr(x,name)) for name,value in zip(_NUMERIC_FIELDS,old) if getattr(x,name) is not value)
        if effects:input_effects.append((index,effects))
    _CACHE[key] = (_recipe(result,inputs), tuple(_recipe(x,inputs) for x in boxes), start, end, raised, tuple(input_effects), weight)
    _WEIGHT += weight
    STATS['entries'] = len(_CACHE)
    STATS['retained_coefficients'] = _WEIGHT
    return result
