# Scope of the scenario launcher

Each source record describes one whole output history and its joint ancestry.
A source choice is copied consistently to all three destinations. A consumer
joins selector maps only when all shared ancestor keys have equal values.
Distinct keys do not assert independence of physical parameters; their boxes
and affine symbols are retained. Infeasible combinations may remain, giving
an outer cover. No conflicting source history is flattened into a pulse union.

Every compatible triple is a separate job. Its device parameter namespace is
the campaign/cell identity, independent of the selected parents. Its numerical
producer namespace additionally includes the job identity. This retains the
same physical device across alternatives while preventing accidental reuse of
fresh rounding/remainder symbols belonging to different calculations.

The cell adapter retains complete terminal histories, conditions and traces.
It uses the previously tested recovery contraction and history continuation.
The legacy plain-interval structural sharing shortcut is disabled. Unsupported
guards and budgets refuse the job; an unresolved frontier cannot issue an
acceptance receipt. Only documented guard ambiguities enter continuation.

Receipt views include the complete typed graph, output trains, terminal states,
time expressions and joint ancestry. A fresh verifier reconstructs expected
jobs for the entire prefix, checks catalogues, rereads payloads and validates
views and selector derivation. A layer completes only after all jobs and the
fresh verification succeed. Source identity includes the new launcher and all
affine/kernel executable sources and native binaries.

An unchanged invocation can reuse complete jobs. A changed kernel, arithmetic
environment or configured limits requires a new campaign directory. Historical
single-history receipts are not accepted under the new schema.

The validation here covers transport with synthetic branches and two real
canonical layers. It does not establish completion, invariant-domain inclusion
or independent mathematical qualification of an 18-layer scenario campaign.
