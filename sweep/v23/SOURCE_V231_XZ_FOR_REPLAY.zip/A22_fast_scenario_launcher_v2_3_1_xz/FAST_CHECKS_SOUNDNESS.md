# Reusing checks without weakening their content

`write_checked_views` uses the unchanged typed Encoder for each original
view, preserving node traversal, canonical bytes and digests. The complete
graph captured before writing is the graph actually written. Exactly one
real disk decode is then used to regenerate and compare all five view hashes.
No numerical tolerance or approximate representation is introduced. The
old generic `write_checked` remains available and unchanged.

The controller binds worker-returned receipts to their exact file hashes
instead of performing an additional typed reread immediately after the
worker's own verified reread. The independent fresh process still verifies
every new job, every view and the exhaustive compatible-job catalogue.

An ancestor layer may avoid repeated typed decoding only when its previous
successful verification is sealed by `complete.json`: manifest and proof
digests match, the proof's run/kernel/layer identity matches, all receipt
hashes match that proof, and every payload's SHA-256 matches its bound
receipt. The expected compatible jobs and resulting catalogue are still
reconstructed and compared. This reuses the exact same scientific bytes
that previously passed the full verification. Modified bytes, proofs,
receipts or kernel identities refuse reuse, regardless of size or mtime.

Only artifact I/O and launcher verification scheduling change. Every other
affine and physical-kernel source/binary is byte-identical to the preceding
launcher. This is a new source identity and requires a new canonical run.
As before, these software checks are not independent qualification of the
mathematical kernel or of a complete 18-layer campaign.
