# Enclosure obligations and review notes

## READY no-fire cover

For a READY state with admitted pulse memory, evaluate the original correlated
memory on each closed subinterval covering the full time window. Every upper
charge bound must be strictly below one. Adaptive bisection has a finite depth
and refuses if it cannot establish the condition. It never accepts a nominal
trajectory or an isolated endpoint as a substitute for this window condition.

## Common READY endpoint

The shortcut requires no active gain deposits, no protected actuator history,
and only raw and mark on/off events. Each port's event order is certified with
interval time differences. At most one new raw arrival per port is allowed.
Gains and the actuator remain constant. Cross-port flag updates commute and
the pulse amplitudes are consequently fixed. The final admitted memory
contains all future arrivals, with zero response before each arrival. A strict
no-fire cover of that memory over the entire group proves no reset intervenes.
One final flow then encloses the common endpoint of every admissible ordering.
The code retains exact origins and shared parameter symbols.

## Common protected endpoint

The shortcut requires the FAST phase, closed gain gates, histories tied to the
same fire, events starting after the current state, and an endpoint certainly
at or beyond fire+1. Only raw, mark and error on/off events are allowed; their
per-port order and terminal containment are certified. During protection the
gain gates remain closed. Distinct-port updates commute on the exact mark
ledger; same-port ordering is retained. Auxiliary bookkeeping is applied at
its actual event dates without advancing the continuous state between ports.

The complete ledger bounds the nonnegative capped recovery dose through the
endpoint. Its ell lower bound must be strictly positive. Since that dose is
nondecreasing along every physical realization, no READY return can occur
earlier. The common endpoint is therefore SLOW with q=R*exp(ell). Terminal
actuator and gain bounds are recomputed from their original histories. The
shortcut refuses when any condition or the strict ell test fails.

This argument depends on the existing ledger implementation clipping future
contributions, retaining exact mark origins/endpoints, and nonnegative capped
recovery rates. It is not permission to commute arbitrary hybrid events.

## Root fallback

Only the named READY boundary/tangency refusal is eligible. The memory must
prove q(0)<1, q(h)>=1 and q'([0,h])>0. The original interval root solver is used,
and the resulting fire must be strictly before the next external boundary.
This proves a first crossing within the bracket. Otherwise the original
refusal is raised. The physical threshold is unchanged.

## Enumeration and prefix reuse

Directed event-pair bounds are cached only within one immutable event group.
Incremental prefix feasibility retains the original stage transitions,
adjacent-difference rejection, absolute earliest-date test, traversal and
search budgets. Ordered pairs are distinct: reverse bounds are not inferred
from rounded forward bounds. Identical prefix states are reused only within
one group's original start state. Distinct complete branches remain covered.

## Affine arithmetic

Time sums batch coefficients and accumulate directed rounding residuals before
a final symbol truncation. Existing input residuals remain included. This can
change representation and allocation; it requires a new source/kernel identity.

Sparse hull construction includes a missing coefficient as zero in its range.
For each input branch, present-coefficient deviation uses directed arithmetic.
Missing common-coefficient mass is accumulated exactly in integer units of
2^-1074 and converted upward. The resulting hull encloses each input pointwise
under the same shared noise assignment. This is stronger than checking only
marginal interval containment. Tests include exact rational witnesses.

## Campaign lineage

The original layer 9 parents are used only for explicitly labelled diagnostic
replays. A changed engine must start at the canonical source and use its own
run ID, kernel ID, parent receipts and fresh typed-payload verification for
every accepted layer. All included campaign summaries distinguish that lineage
from the isolated diagnostic. The physical epsilon remains 0.01 and initial
delta remains 1e-5 throughout this experiment.


## Allocation-exact acceleration added in this package

Completed charge transfers and completed deposit subtotals are memoized only
for exact immutable input objects. Cached context keys include all directed
Decimal contexts, traps, affine truncation settings, producer namespace,
lazy numeric input state and time-box identities. Every cache entry retains
its input objects; object identifiers therefore cannot be reused underneath it.
The subtotal extraction preserves the original order of additions and all
physical expressions. Per-port LAM selection remains in the existing adapter.

A hit replays the full affine allocator span (including discarded allocations),
renames only the result/box symbols allocated in that span, restores lazy input
effects, and propagates Decimal flags. It does not return a correlated result
with old fresh-noise names. Future allocator names and incompatible/reset
states refuse reuse. Memory is bounded by entries and retained coefficient
counts; eviction changes performance only. The prior temporal memo is disabled
by default in this optimized profile; enabling it bypasses transfer/subtotal
memoization. Both modes retain their reference paths.

The native clock sum preserves atom order, directed center operations,
coefficient insertion order, signed zeros, rounding-error accumulation and
final truncation/allocation. It uses one private dictionary accumulator.
Native multiplication likewise mutates only its newly created temporary.
Public affine construction continues to copy caller-owned dictionaries.

Canonical JSON uses the C encoder with the same sorting, separators, Unicode
escaping and non-finite refusal as the previous streaming encoder. Whole
payload, typed reread and independent verification checks remain in place.
This uses more transient memory for a contiguous JSON byte buffer. No
verification view is removed. Cached history keys keep full structural equality;
a hash collision alone can never merge histories.

These changes require a new source/kernel identity. Isolated replay of existing
parents is diagnostic only and issues no acceptance receipts. Exact equality
on sampled complete cells and differential tests is software evidence, not an
independent qualification of the mathematical proof or a complete campaign.
