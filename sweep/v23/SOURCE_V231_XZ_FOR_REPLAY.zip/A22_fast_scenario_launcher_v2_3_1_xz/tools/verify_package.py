"""Verify every packaged file against the manifest; starts no computation."""
from pathlib import Path
import hashlib,json,sys

def main():
    root=Path(__file__).resolve().parents[1]
    manifest=json.loads((root/'MANIFEST_V23.json').read_text())
    errors=[]
    for name,expected in manifest['files'].items():
        path=root/name
        if not path.is_file():errors.append(name+': missing');continue
        h=hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
        if h.hexdigest()!=expected['sha256'] or path.stat().st_size!=expected['bytes']:
            errors.append(name+': changed')
    for path in (root/'engine').rglob('*'):
        if (path.is_file() and '__pycache__' not in path.parts and
                path.suffix in ('.py','.c','.h','.so','.pyd','.dll','.dylib') and
                str(path.relative_to(root)) not in manifest['files']):
            errors.append(str(path.relative_to(root))+': unexpected executable source or binary')
    if errors:
        print('\n'.join(errors));return 1
    print('PACKAGE VERIFIED:',len(manifest['files']),'files')
    print('Engine source identity:',manifest['source_identity'])
    print('Physical kernel sources unchanged:',manifest['physical_kernel_sources_unchanged'])
    print('Physical kernel binaries unchanged:',manifest['physical_kernel_binaries_unchanged'])
    return 0

if __name__=='__main__':raise SystemExit(main())
