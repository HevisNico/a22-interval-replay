# Fast Scenario Launcher v2.3

Deux accélérations ajoutées à v2.1. Le noyau physique (`engine/kernel/`) et
ses binaires sont identiques à v2.1. Précision 160, KMAX 256, budgets, cinq
vues, relecture typée et vérification indépendante de chaque couche sont
conservés. Statut : `experimental_not_qualified`.

Les mesures sont dans `VALIDATION_V23.json` (même machine, même commande,
v2.1 puis v2.3).

## Changements

### 1. Proposition de racine paresseuse (`engine/affine/engine.py`)

En v2.1, chaque recherche de racine commence par `guessroot` : un brentq
flottant qui évalue la garde affine complète, en Decimal à 160 chiffres,
une dizaine de fois, uniquement pour proposer un centre de crochet. Sur la
cellule 5/4 de la campagne v2.1, c'était environ 16 % du calcul, alors que la
racine précédente de la même garde tombait à moins de 1e-6 de cette
proposition dans 111 cas sur 127.

v2.3 essaie d'abord, une seule fois et au rayon d'indice habituel, le centre
de la dernière racine acceptée pour la même garde (mêmes objets code de
`fun` et `deriv`, mémoire remise à zéro à chaque cellule). Si ce crochet
n'est pas accepté, la proposition flottante est calculée et la recherche
v2.1 est exécutée telle quelle.

Ce qui ne change pas : l'acceptation exige toujours f(l) ≤ 0, f(h) ≥ 0 et une
pente strictement positive sur [l, h], puis le même raffinement de Newton et
le même `affine_refine`. Une proposition ne certifie jamais rien ; elle choisit
seulement où le crochet est testé. Les bornes produites peuvent différer de
v2.1 dans les derniers chiffres (crochet testé ailleurs), d'où une nouvelle
identité de moteur.

### 2. Ordonnancement en flux (`engine/run_scenarios.py`, fonction `dataflow`)

En v2.1, une couche entière devait être calculée puis vérifiée avant de
commencer la suivante. Or la cellule (n, j) ne lit que les voies
(n−1, j−1), (n−1, j) et (n−1, j+1).

v2.3 planifie une cellule dès que ses trois voies parentes ont tous leurs
jobs terminés. Les jobs prêts passent par ordre de couche croissante, puis
du plus coûteux au moins coûteux (coût estimé sur les parents), pour réduire
la traîne de fin de couche.

L'acceptation des couches est inchangée : manifeste complet, sous-processus
de vérification indépendante du préfixe, puis `complete.json`. Les
vérifications se font une couche à la fois, dans l'ordre, pendant que les
jobs suivants calculent. Un job calculé avant l'acceptation de sa couche
parente reste un simple job : sa couche ne peut pas être acceptée avant
toutes les couches ancêtres. Un échec de vérification arrête tout et écrit
`stopped.json`. `complete.json` porte `"scheduler": "dataflow-v2.3"`, et ses
temps se recouvrent d'une couche à l'autre.

La reprise fonctionne comme avant : les couches scellées sont revérifiées et
réutilisées, les jobs déjà terminés sont relus par leur reçu.

## Installation et contrôle, sans lancer de campagne

Linux/POSIX, CPython 3.12, NumPy 2.3.5, SciPy 1.17.0. Binaires Linux
CPython 3.12 inclus. Depuis ce dossier :

```bash
python -B tools/verify_package.py
python -m pip install -r engine/requirements.txt
python -B -m unittest discover -s engine/tests     # 188 tests
```

Sur une autre machine, reconstruire si nécessaire avec
`python -B engine/build_all_native.py` avant toute campagne (cela peut
changer l'identité binaire).

## Lancement

Nouvelle identité : il faut un dossier neuf. Ne pas reprendre une campagne
v2.1 avec ce moteur.

```bash
python -u -B engine/launch_v2.py --out results/A22_v23_001 \
  --through 18 --epsilon 0.01 --workers 4 --zip-every 3
```

Mettre `--workers` au nombre de cœurs **physiques** disponibles (maximum 12).
Avec l'ordonnancement en flux, des workers en plus restent utiles même
quand une couche n'a que quelques cellules actives. Compter environ 1 à
1,5 Gio de RAM par worker. La vérification indépendante tourne en parallèle
du calcul et prend brièvement `--workers` processus en plus.

Reprise après une coupure de l'environnement, avec exactement le même
moteur, les mêmes binaires et les mêmes versions :

```bash
python -u -B engine/run_scenarios.py --out results/A22_v23_001 \
  --through 18 --epsilon 0.01 --workers 4 --zip-every 3
```

## Ce qui n'est pas établi

- Aucune campagne complète de 18 couches n'a été lancée avec v2.3.
- Jusqu'à la couche 8 de la campagne v2.1, aucune cellule n'a eu plus d'une
  histoire. Si des dédoublements apparaissent plus profond, le nombre de jobs
  peut croître fortement ; v2.3 n'y change rien (budgets inchangés :
  512 histoires et 10 000 jobs par cellule).
- Ces contrôles logiciels ne qualifient ni le noyau mathématique ni une
  campagne complète.
