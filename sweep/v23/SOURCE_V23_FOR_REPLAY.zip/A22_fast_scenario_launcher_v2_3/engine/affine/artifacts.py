"""Exact typed DAG artifacts. No pickle or executable deserialization.
Sharing is a storage optimization, never a criterion for deleting a history.
"""
from pathlib import Path
from decimal import Decimal
from dataclasses import is_dataclass,fields
import hashlib,json,os,math
from affine_iv import I
from temporal import Time,same_form
SCHEMA='A22-affine-research-DAG-1'
STORAGE_SCHEMA='A22-affine-symbol-table-1'

def pack_graph(doc):
    """Lossless symbol dictionary. The scientific DAG and its hashes stay exact.

    Only repeated coefficient-name strings become table indices. Node order,
    coefficient order, float.hex strings, Decimal strings and graph edges are
    retained. The original Encoder remains the independent view definition.
    """
    if doc.get('schema') != SCHEMA:
        raise ValueError('unattested scientific graph')
    symbols=[];indices={};nodes=[]
    for node in doc['nodes']:
        if node[0] != 'affine':
            nodes.append(node)
            continue
        pairs=[]
        for name,value in node[3]:
            if name not in indices:
                indices[name]=len(symbols);symbols.append(name)
            pairs.append((indices[name],value))
        nodes.append(('affine',node[1],node[2],pairs,node[4]))
    return dict(storage_schema=STORAGE_SCHEMA,schema=SCHEMA,
                symbols=symbols,nodes=nodes,root=doc['root'])

def unpack_graph(doc):
    if 'storage_schema' not in doc:
        return doc
    if doc['storage_schema'] != STORAGE_SCHEMA or doc.get('schema') != SCHEMA:
        raise ValueError('unattested artifact storage schema')
    symbols=doc.get('symbols')
    if (type(symbols) is not list or any(type(x) is not str for x in symbols)
            or len(set(symbols)) != len(symbols)):
        raise ValueError('invalid coefficient symbol table')
    nodes=[]
    for node in doc['nodes']:
        if node[0] != 'affine':
            nodes.append(node)
            continue
        if len(node) != 5:
            raise ValueError('invalid affine node')
        pairs=[]
        for index,value in node[3]:
            if type(index) is not int or not 0 <= index < len(symbols):
                raise ValueError('invalid coefficient symbol index')
            pairs.append((symbols[index],value))
        nodes.append(('affine',node[1],node[2],pairs,node[4]))
    return dict(schema=SCHEMA,nodes=nodes,root=doc['root'])

def atomic_graph(path,doc):
    return atomic_json(path,pack_graph(doc))

def file_hash(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(65536),b''):h.update(chunk)
    return h.hexdigest()

def canonical_hash(x):
    return hashlib.sha256(canonical_bytes(x)).hexdigest()

def canonical_bytes(x):
    # CPython's C encoder; exactly the existing canonical JSON representation.
    return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')

def atomic_json(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+'.tmp')
    with tmp.open('wb') as f:
        f.write(canonical_bytes(obj))
        f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)
    return file_hash(path)

class _AffineLeafCache:
    """Only serialized leaves, scoped to one collection of views.

    Exact I leaves alone are eligible. Snapshots retain original coefficient
    values, so even private dictionary mutation (including +/-0 changes) is
    detected by identity. There is no cache across the physical disk reread.
    """
    MAX_COEFFICIENTS = 500000
    MAX_ENTRIES = 16384
    def __init__(self):
        self.entries={};self.weight=0
    def leaf(self,x):
        previous=self.entries.get(id(x))
        if previous is not None:
            obj,clo,chi,error,snapshot,node=previous
            if (obj is x and type(x) is I and x.clo is clo and x.chi is chi and x.e is error
                    and type(x._d) is dict and len(x._d)==len(snapshot)
                    and all(type(k) is str and snapshot.get(k) is v for k,v in x._d.items())):
                return node
        node=('affine',str(x.clo),str(x.chi),tuple((k,v.hex()) for k,v in sorted(x.d.items())),x.e.hex())
        if (type(x) is I and type(x._d) is dict and type(x.clo) is Decimal and type(x.chi) is Decimal
                and type(x.e) is float and len(self.entries)<self.MAX_ENTRIES
                and self.weight+len(x._d)<=self.MAX_COEFFICIENTS
                and all(type(k) is str and type(v) is float for k,v in x._d.items())):
            snapshot=x._d.copy()
            if previous is not None:self.weight-=len(previous[4])
            self.entries[id(x)]=(x,x.clo,x.chi,x.e,snapshot,node)
            self.weight+=len(snapshot)
        return node

class Encoder:
    def __init__(self,node_limit=500000,leaf_cache=None):
        self.nodes=[];self.memo={};self.active=set();self.intern={};self.limit=node_limit
        self.leaf_cache=leaf_cache
    def walk(self,x):
        oid=id(x)
        if oid in self.memo:return self.memo[oid][1]
        if oid in self.active:raise ValueError('cyclic scientific payload')
        self.active.add(oid)
        if x is None or type(x) in (bool,int,str):node=('scalar',x)
        elif type(x) is float:
            if not math.isfinite(x):raise ValueError('non-finite float')
            node=('float',x.hex())
        elif isinstance(x,Decimal):
            if not x.is_finite():raise ValueError('non-finite Decimal')
            node=('decimal',str(x))
        elif isinstance(x,I):
            node=(self.leaf_cache.leaf(x) if self.leaf_cache is not None else
                  ('affine',str(x.clo),str(x.chi),tuple((k,v.hex()) for k,v in sorted(x.d.items())),x.e.hex()))
        elif isinstance(x,Time):node=('time',x.key,self.walk(x.base),str(x.offset),self.walk(x.terms))
        elif type(x) in (list,tuple):node=(type(x).__name__,tuple(self.walk(v) for v in x))
        elif type(x) is dict:node=('dict',tuple((self.walk(k),self.walk(v)) for k,v in x.items()))
        elif is_dataclass(x):node=('record',type(x).__module__,type(x).__name__,tuple((f.name,self.walk(getattr(x,f.name))) for f in fields(x)))
        else:raise TypeError('unsupported payload type: '+type(x).__name__)
        self.active.remove(oid)
        # bool and int must remain different types despite True == 1.
        key=(type(x).__name__,node)
        idx=self.intern.get(key)
        if idx is None:
            if len(self.nodes)>=self.limit:raise MemoryError('artifact node budget exceeded')
            idx=len(self.nodes);self.nodes.append(node);self.intern[key]=idx
        self.memo[oid]=(x,idx)
        return idx
    def encode(self,x):
        root=self.walk(x)
        return {'schema':SCHEMA,'nodes':self.nodes,'root':root}

def decode(doc):
    import actuations_A19 as ac,depot_A19 as dz,cycle_local_A20 as cy
    allowed={('actuations_A19','Segment'):ac.Segment,('actuations_A19','History'):ac.History,('depot_A19','History'):dz.History,('cycle_local_A20','Branch'):cy.Branch,('cycle_local_A20','Forest'):cy.Forest}
    if doc.get('schema')!=SCHEMA:raise ValueError('unattested or old artifact schema')
    nodes=doc['nodes'];values=[];atoms={}
    def child(i):
        if type(i) is not int or not 0<=i<len(values):raise ValueError('invalid DAG edge')
        return values[i]
    for node in nodes:
        tag=node[0]
        if tag=='scalar':
            x=node[1]
            if x is not None and type(x) not in (str,bool,int):raise TypeError('invalid scalar')
        elif tag=='float':
            x=float.fromhex(node[1])
            if not math.isfinite(x):raise ValueError('non-finite float')
        elif tag=='decimal':
            x=Decimal(node[1])
            if not x.is_finite():raise ValueError('non-finite Decimal')
        elif tag=='affine':
            pairs=node[3];d=dict((k,float.fromhex(v)) for k,v in pairs)
            if len(d)!=len(pairs):raise ValueError('duplicate affine symbol')
            x=object.__new__(I);x.__setstate__((Decimal(node[1]),Decimal(node[2]),d,float.fromhex(node[4])))
        elif tag=='time':
            terms=child(node[4])
            if not isinstance(terms,tuple):raise ValueError('explicit time expression required')
            x=Time(node[1],child(node[2]),Decimal(node[3]),terms)
            for key,n,v in x.terms:
                if key in atoms and not same_form(atoms[key],v):raise ValueError('time atom definition changed')
                atoms[key]=v
        elif tag in ('list','tuple'):
            x=[child(i) for i in node[1]]
            if tag=='tuple':x=tuple(x)
        elif tag=='dict':
            pairs=[(child(k),child(v)) for k,v in node[1]];x=dict(pairs)
            if len(x)!=len(pairs):raise ValueError('duplicate dictionary key')
        elif tag=='record':
            cls=allowed.get((node[1],node[2]))
            if cls is None:raise TypeError('unsupported record type')
            names=[k for k,v in node[3]]
            if names!=[f.name for f in fields(cls)]:raise ValueError('record fields changed')
            x=cls(**{k:child(v) for k,v in node[3]})
        else:raise ValueError('unknown DAG tag')
        values.append(x)
    return child(doc['root'])

def read(path,expected_sha=None,max_bytes=256*1024*1024):
    path=Path(path)
    if path.stat().st_size>max_bytes:raise MemoryError('artifact byte budget exceeded')
    if expected_sha is not None and file_hash(path)!=expected_sha:raise ValueError('artifact hash mismatch')
    with path.open() as f:return decode(unpack_graph(json.load(f)))

def write_checked(path,payload):
    """Capture before write, decode from disk, compare exact typed content."""
    before=Encoder().encode(payload);digest=canonical_hash(before)
    sha=atomic_graph(path,before)
    reread=read(path,sha)
    after=Encoder().encode(reread)
    # Compare bytes represented by the full typed graph, not float tolerances.
    if canonical_hash(after)!=digest:raise ValueError('fresh/disk content mismatch')
    return sha,{'full_content_equal':True,'typed_content_sha256':digest,'nodes':len(before['nodes'])}

def encode_views(payload,view_fn):
    """Exact original graphs for every view.

    Each graph keeps its own node numbering, traversal and interning.
    Only exact serialized affine leaves are reused within this collection.
    """
    cache=_AffineLeafCache()
    return {name:Encoder(leaf_cache=cache).encode(value)
            for name,value in view_fn(payload).items()}

def digest_views(payload,view_fn):
    result={};cache=_AffineLeafCache()
    for name,value in view_fn(payload).items():
        result[name]=canonical_hash(Encoder(leaf_cache=cache).encode(value))
    return result

def write_checked_views(path,payload,view_fn):
    """One real disk decode, comparing all five exact before/after graphs."""
    before={};full=None;cache=_AffineLeafCache()
    for name,value in view_fn(payload).items():
        doc=Encoder(leaf_cache=cache).encode(value)
        before[name]=canonical_hash(doc)
        if name=='complete':full=doc
    if full is None:raise ValueError('Complete view required')
    sha=atomic_graph(path,full)
    after=digest_views(read(path,sha),view_fn)
    if before!=after:raise ValueError('fresh/disk view mismatch')
    return sha,dict(full_content_equal=True,typed_content_sha256=before['complete'],nodes=len(full['nodes'])),before
