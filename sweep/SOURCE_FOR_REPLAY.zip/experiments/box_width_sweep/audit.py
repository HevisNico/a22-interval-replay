"""Read-only sweep integrity audit; no new mathematical qualification."""
from pathlib import Path
import hashlib
import json
import sys

REPO = Path(__file__).resolve().parents[2]


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def main():
    out = Path(sys.argv[1]).resolve()
    status = json.loads((out / 'sweep_status.json').read_text())
    assert status['status'] == 'finished', 'Only audit a finished sweep'
    manifest = json.loads((out / 'SOURCE_MANIFEST.json').read_text())
    for name, digest in manifest['files'].items():
        assert sha(REPO / name) == digest, name
    sys.path.insert(0, str(REPO / 'engine'))
    import run
    assert run.identity() == manifest['source_identity']
    kernel_ids = set()
    runs = []
    for row in status['runs']:
        campaign = out / Path(row['campaign']).name
        cfg = json.loads((campaign / 'campaign.json').read_text())
        from decimal import Decimal
        assert Decimal(cfg['parameters']['epsilon_relative']) == Decimal(row['epsilon'])
        assert Decimal(cfg['parameters']['initial_delta']) == Decimal('1e-5')
        assert cfg['kernel_id'] not in kernel_ids
        kernel_ids.add(cfg['kernel_id'])
        count = 0
        for layer in row['layers']:
            n = layer['layer']
            directory = campaign / f'layer_{n:02d}'
            complete = json.loads((directory / 'complete.json').read_text())
            verification = json.loads((directory / 'verification.json').read_text())
            assert complete['layer'] == verification['layer'] == n
            assert verification['kernel_id'] == cfg['kernel_id']
            assert verification['run_id'] == cfg['run_id']
            parents = ([sha(campaign / f'layer_{n-1:02d}' / f'cell_{j:02d}' / 'receipt.json')
                        for j in range(12)] if n > 1 else [])
            widths = []
            for lane in range(12):
                cd = directory / f'cell_{lane:02d}'
                receipt_path = cd / 'receipt.json'
                receipt = json.loads(receipt_path.read_text())
                assert receipt['case'] == {'run_id': cfg['run_id'], 'kernel_id': cfg['kernel_id'],
                                           'layer': n, 'lane': lane, 'parent_receipts': parents}
                assert sha(receipt_path) == complete['receipts'][lane] == verification['receipts'][lane]
                assert sha(cd / 'result.json') == receipt['payload_sha256'] == verification['payloads'][lane]
                widths.append(float(receipt['metrics']['max_width']))
                count += 1
            assert max(widths) == layer['max_date_width']
            assert complete['critical_path_seconds'] == layer['compute_and_plan_seconds']
        assert len(row['layers']) == row['last_accepted_layer']
        if row['status'] == 'refused':
            assert row['failure']['layer'] == row['last_accepted_layer'] + 1
            assert (campaign / row['failure']['file']).exists()
        assert row['summary_reader_returncode'] == 0
        runs.append({'epsilon': row['epsilon'], 'accepted_layers': row['last_accepted_layer'],
                     'checked_cells': count, 'campaign_sha256': sha(campaign / 'campaign.json')})
    audit = {'status': 'PASS', 'scope': 'Recorded source and artifact integrity only; B remains open',
             'source_identity': run.identity(), 'program_sha256': sha(Path(__file__)), 'runs': runs}
    (out / 'SWEEP_AUDIT.json').write_text(json.dumps(audit, indent=2) + '\n')
    print(json.dumps(audit, indent=2))


if __name__ == '__main__':
    main()
