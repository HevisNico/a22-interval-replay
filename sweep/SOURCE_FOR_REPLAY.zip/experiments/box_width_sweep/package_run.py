"""Deflate package of one finished fresh campaign, without editing its files."""
from pathlib import Path
import hashlib
import json
import sys
import zipfile


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def main():
    out = Path(sys.argv[1]).resolve()
    epsilon = sys.argv[2]
    state = json.loads((out / 'sweep_status.json').read_text())
    row = next(r for r in state['runs'] if r['epsilon'] == epsilon)
    assert row['status'] in ('completed', 'refused')
    assert row['summary_reader_returncode'] == 0
    campaign = out / Path(row['campaign']).name
    name = campaign.name
    files = sorted(p for p in campaign.rglob('*')
                   if p.is_file() and p.name != 'controller.lock' and not p.name.endswith('.tmp'))
    manifest_path = out / (name + '_MANIFEST.json')
    manifest = {'campaign_name': name, 'epsilon': epsilon,
                'scientific_status': 'experimental_not_qualified',
                'last_accepted_layer': row['last_accepted_layer'],
                'note': 'Files of the refused layer are diagnostics and partial results, never an accepted layer.',
                'files': {str(p.relative_to(out)): {'sha256': sha(p), 'bytes': p.stat().st_size} for p in files}}
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    status_path = out / (name + '_RUN_STATUS.json')
    status_path.write_text(json.dumps(row, indent=2) + '\n')
    archive = out / ('A22_box_sweep_' + name + '.zip')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=1, allowZip64=True) as z:
        for path in files:
            z.write(path, str(path.relative_to(out)))
        for path in (manifest_path, status_path, out / (name + '_summary.json'), out / (name + '.log')):
            z.write(path, path.name)
    with zipfile.ZipFile(archive) as z:
        assert all(i.compress_type == zipfile.ZIP_DEFLATED for i in z.infolist())
        assert z.testzip() is None
    receipt = {'archive': archive.name, 'archive_sha256': sha(archive),
               'campaign_identity_sha256': sha(campaign / 'campaign.json'),
               'source_archive_sha256': sha(out / 'SOURCE_FOR_REPLAY.zip'),
               'manifest_sha256': sha(manifest_path),
               'input': 'Fresh canonical 128-pulse source; no reused layer or receipt',
               'epsilon': epsilon, 'last_accepted_layer': row['last_accepted_layer'],
               'status': row['status']}
    (out / (name + '_PACKAGE_RECEIPT.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'archive': str(archive), 'MiB': round(archive.stat().st_size / 2**20, 2),
                      'receipt': receipt}, indent=2))


if __name__ == '__main__':
    main()
