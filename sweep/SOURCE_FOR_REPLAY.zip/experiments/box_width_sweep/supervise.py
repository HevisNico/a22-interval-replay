"""Sequential fresh epsilon campaigns; read-only monitoring of engine artifacts.

Run from any directory. All supervisor outputs are outside campaign folders.
Stops a campaign process group on refusal; never resumes or edits receipts.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import signal
import statistics
import subprocess
import sys
import time

REPO = Path(__file__).resolve().parents[2]
ENGINE = REPO / 'engine'


def utc():
    return datetime.now(timezone.utc).isoformat()


def atomic(path, data):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, indent=2) + '\n')
    tmp.replace(path)


def terminate_group(proc):
    try:
        os.killpg(proc.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        pass
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    proc.wait()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--workers', type=int, default=8)
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1',
               MKL_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
    epsilons = ('3e-4', '1e-3', '3e-3', '1e-2')
    result = {'started_utc': utc(), 'status': 'running', 'epsilons': epsilons,
              'initial_delta': '1e-5', 'workers': args.workers,
              'memory_mib_per_worker': 1536, 'cpu_seconds_per_cell': 14400,
              'scientific_status': 'experimental_not_qualified', 'runs': []}
    events = out / 'events.jsonl'

    def emit(kind, **data):
        event = dict(time_utc=utc(), kind=kind, **data)
        with events.open('a') as stream:
            stream.write(json.dumps(event) + '\n')
        print(json.dumps(event), flush=True)

    def checkpoint():
        atomic(out / 'sweep_status.json', result)

    checkpoint()
    for epsilon in epsilons:
        label = 'eps_' + epsilon.replace('-', 'm')
        campaign = out / label
        if campaign.exists():
            raise RuntimeError('Fresh campaign directory already exists')
        command = [sys.executable, '-u', '-B', str(ENGINE / 'launch_fresh.py'),
                   '--out', str(campaign), '--workers', str(args.workers),
                   '--memory-mib', '1536', '--cpu-seconds', '14400',
                   '--epsilon', epsilon]
        row = {'epsilon': epsilon, 'campaign': str(campaign), 'command': command,
               'started_utc': utc(), 'status': 'running', 'layers': [],
               'observed_layer_starts_seconds': {}}
        result['runs'].append(row)
        checkpoint()
        emit('campaign_started', epsilon=epsilon, workers=args.workers)
        started = time.monotonic()
        seen = set()
        failure = None
        with (out / (label + '.log')).open('w') as log:
            proc = subprocess.Popen(command, cwd=ENGINE, env=env, stdout=log,
                                    stderr=subprocess.STDOUT, start_new_session=True)
            row['controller_pid'] = proc.pid
            checkpoint()
            while True:
                for layer in sorted(campaign.glob('layer_*')):
                    n = int(layer.name[6:])
                    if str(n) not in row['observed_layer_starts_seconds']:
                        seconds = time.monotonic() - started
                        row['observed_layer_starts_seconds'][str(n)] = seconds
                        emit('layer_started', epsilon=epsilon, layer=n,
                             seconds_since_campaign_start=round(seconds, 3))
                    complete = layer / 'complete.json'
                    if complete.exists() and n not in seen:
                        data = json.loads(complete.read_text())
                        receipts = [json.loads(p.read_text()) for p in sorted(layer.glob('cell_*/receipt.json'))]
                        widths = [float(r['metrics']['max_width']) for r in receipts]
                        active = [float(r['metrics']['max_width']) for r in receipts if r['metrics']['pulses']]
                        summary = {'layer': n, 'compute_and_plan_seconds': data['critical_path_seconds'],
                                   'fresh_verification_seconds': data['phase_seconds']['revalidation'],
                                   'max_date_width': max(widths),
                                   'median_active_cell_date_width': statistics.median(active) if active else None,
                                   'completed_cells': len(receipts)}
                        row['layers'].append(summary)
                        seen.add(n)
                        emit('layer_accepted', epsilon=epsilon, **summary)
                        checkpoint()
                refusals = sorted(campaign.glob('layer_*/cell_*/refusal.json'))
                stopped = sorted(campaign.glob('layer_*/stopped.json'))
                if (refusals or stopped) and failure is None:
                    path = min(refusals or stopped, key=lambda p: p.stat().st_mtime_ns)
                    data = json.loads(path.read_text())
                    n = int(path.relative_to(campaign).parts[0][6:])
                    failure = {'file': str(path.relative_to(campaign)), 'layer': n,
                               'first_observed_seconds': time.monotonic() - started,
                               'type': data.get('type', data.get('exception_type')),
                               'reason': data.get('traceback', data.get('reason', ''))}
                    row['failure'] = failure
                    emit('refusal_detected', epsilon=epsilon, layer=n,
                         type=failure['type'], reason=failure['reason'].strip().splitlines()[-1])
                    checkpoint()
                if failure is not None:
                    n = failure['layer']
                    # Allow the controller's already-running prior-layer verifier
                    # to finish and write its authentic completion marker.
                    prior_done = n == 1 or (campaign / f'layer_{n-1:02d}' / 'complete.json').exists()
                    wait = time.monotonic() - started - failure['first_observed_seconds']
                    if prior_done or wait >= 60:
                        terminate_group(proc)
                        break
                if proc.poll() is not None:
                    break
                time.sleep(0.5)
            row['returncode'] = proc.wait()
        row['elapsed_seconds'] = time.monotonic() - started
        row['ended_utc'] = utc()
        # Collect a last completion written between the final poll and shutdown.
        for path in sorted(campaign.glob('layer_*/complete.json')):
            n = int(path.parent.name[6:])
            if n not in seen:
                data = json.loads(path.read_text())
                receipts = [json.loads(p.read_text()) for p in path.parent.glob('cell_*/receipt.json')]
                widths = [float(r['metrics']['max_width']) for r in receipts]
                summary = {'layer': n, 'compute_and_plan_seconds': data['critical_path_seconds'],
                           'fresh_verification_seconds': data['phase_seconds']['revalidation'],
                           'max_date_width': max(widths), 'completed_cells': len(receipts)}
                row['layers'].append(summary)
                emit('layer_accepted', epsilon=epsilon, **summary)
        row['layers'].sort(key=lambda d: d['layer'])
        row['last_accepted_layer'] = max((d['layer'] for d in row['layers']), default=0)
        row['status'] = 'refused' if failure else ('completed' if row['returncode'] == 0 else 'controller_error')
        cfg = campaign / 'campaign.json'
        if cfg.exists():
            row['campaign_identity'] = json.loads(cfg.read_text())
        checkpoint()
        emit('campaign_finished', epsilon=epsilon, status=row['status'],
             last_accepted_layer=row['last_accepted_layer'],
             elapsed_seconds=round(row['elapsed_seconds'], 3))
        # The existing reader checks each payload hash; summary is outside the
        # campaign directory and does not alter any engine certificate or receipt.
        summary_env = dict(env, A22_PHYSICAL_EPSILON=epsilon)
        summary = out / (label + '_summary.json')
        with (out / (label + '_summary.log')).open('w') as log:
            check = subprocess.run([sys.executable, '-B', str(ENGINE / 'tools' / 'bilan_campagne.py'),
                                    '--campaign', str(campaign), '--out', str(summary)],
                                   cwd=ENGINE, env=summary_env, stdout=log, stderr=subprocess.STDOUT)
        row['summary_reader_returncode'] = check.returncode
        checkpoint()
        if row['status'] == 'controller_error' or check.returncode:
            result['status'] = 'stopped_on_internal_error'
            checkpoint()
            raise RuntimeError('Inspect controller/summary error before continuing')
    result['status'] = 'finished'
    result['ended_utc'] = utc()
    checkpoint()
    emit('sweep_finished', runs=len(result['runs']))


if __name__ == '__main__':
    main()
