"""Read-only CSV, figure and technical report for the epsilon sweep."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import statistics


def write_csv(path, rows):
    keys = list(dict.fromkeys(k for row in rows for k in row))
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sweep', type=Path, required=True)
    parser.add_argument('--baseline-summary', type=Path, required=True)
    parser.add_argument('--baseline-report', type=Path, required=True)
    args = parser.parse_args()
    out = args.sweep.resolve()
    status = json.loads((out / 'sweep_status.json').read_text())
    baseline = json.loads(args.baseline_summary.read_text())
    original = json.loads(args.baseline_report.read_text())
    layer_rows = []
    summary_rows = []
    for layer in baseline['layers']:
        cells = layer['cells']
        active = [c['max_date_width'] for c in cells if c.get('pulses')]
        layer_rows.append({'epsilon': 1e-4, 'source': 'archived_reference',
                           'layer': layer['layer'], 'status': 'accepted',
                           'compute_seconds': layer['critical_path_seconds'],
                           'verification_seconds': layer['revalidation_seconds'],
                           'max_date_width': max(c['max_date_width'] for c in cells),
                           'median_active_date_width': statistics.median(active) if active else None,
                           'max_gain_width': max(c.get('gain_width', 0) for c in cells),
                           'max_q_width': max(c.get('q_width', 0) for c in cells),
                           'max_b_width': max(c.get('b_width', 0) for c in cells)})
    summary_rows.append({'epsilon': 1e-4, 'source': 'archived_reference',
                         'status': 'completed_18_layer_horizon', 'last_accepted_layer': 18,
                         'first_refused_layer': None, 'refusal_type': None,
                         'elapsed_seconds': original['supervision']['elapsed_seconds'],
                         'last_accepted_max_date_width': layer_rows[-1]['max_date_width']})
    for run in status['runs']:
        epsilon = float(run['epsilon'])
        extra_path = out / (Path(run['campaign']).name + '_summary.json')
        details = json.loads(extra_path.read_text()) if extra_path.exists() else {}
        detail_layers = {r['layer']: r for r in details.get('layers', [])}
        for layer in run['layers']:
            cells = detail_layers.get(layer['layer'], {}).get('cells', [])
            layer_rows.append({'epsilon': epsilon, 'source': 'fresh_sweep',
                               'layer': layer['layer'], 'status': 'accepted',
                               'compute_seconds': layer['compute_and_plan_seconds'],
                               'verification_seconds': layer['fresh_verification_seconds'],
                               'max_date_width': layer['max_date_width'],
                               'median_active_date_width': layer.get('median_active_cell_date_width'),
                               'max_gain_width': max((c.get('gain_width', 0) for c in cells), default=None),
                               'max_q_width': max((c.get('q_width', 0) for c in cells), default=None),
                               'max_b_width': max((c.get('b_width', 0) for c in cells), default=None)})
        failure = run.get('failure', {})
        last = max(run['layers'], key=lambda r: r['layer']) if run['layers'] else None
        summary_rows.append({'epsilon': epsilon, 'source': 'fresh_sweep',
                             'status': run['status'],
                             'last_accepted_layer': run.get('last_accepted_layer', last['layer'] if last else 0),
                             'first_refused_layer': failure.get('layer'),
                             'refusal_type': failure.get('type'),
                             'elapsed_seconds': run.get('elapsed_seconds'),
                             'last_accepted_max_date_width': last['max_date_width'] if last else None})
    write_csv(out / 'sweep_summary.csv', summary_rows)
    write_csv(out / 'layer_timings_and_widths.csv', layer_rows)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10})
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5), layout='constrained')
    colors = plt.get_cmap('tab10').colors
    for i, row in enumerate(summary_rows):
        epsilon = row['epsilon']
        records = [r for r in layer_rows if r['epsilon'] == epsilon]
        label = f"ε = {epsilon:g}" + (' (archived)' if i == 0 else '')
        axes[0].plot([r['layer'] for r in records], [r['max_date_width'] for r in records],
                     marker='o', markersize=3, color=colors[i], label=label)
        axes[1].scatter([epsilon], [row['last_accepted_layer']], s=65, color=colors[i],
                        marker='s' if i == 0 else 'o')
        if row['first_refused_layer'] is not None:
            axes[1].annotate(f"refusal at {row['first_refused_layer']}",
                             (epsilon, row['last_accepted_layer']), xytext=(0, 10),
                             textcoords='offset points', ha='center', fontsize=9)
    axes[0].set(xlabel='Layer', ylabel='Maximum output-date enclosure width',
                yscale='log', title='Enclosure growth (accepted layers only)')
    axes[0].legend(fontsize=8)
    axes[0].set_xticks(range(1, 19, 2))
    axes[0].grid(alpha=.2)
    axes[1].set(xlabel='Relative parameter half-width ε', ylabel='Last accepted layer',
                xscale='log', ylim=(-.5, 20.5), title='Reach of the fixed research engine')
    axes[1].grid(alpha=.2)
    axes[1].set_yticks(range(0, 19, 3))
    axes[1].axhline(18, color='0.5', linestyle='--', linewidth=.8)
    axes[1].text(.98, .9, '18-layer test horizon', transform=axes[1].transAxes,
                 ha='right', va='top', fontsize=8, color='0.4')
    fig.suptitle('A22 physical-parameter box-width sweep — initial δ = 10⁻⁵', fontsize=13)
    fig.savefig(out / 'box_width_sweep.png', dpi=220)
    fig.savefig(out / 'box_width_sweep.svg')
    plt.close(fig)
    lines = ['A22 — PHYSICAL-PARAMETER BOX-WIDTH SWEEP', '',
             'Scientific status: experimental_not_qualified. Obligation B remains OPEN.',
             'A refusal is a limitation of this enclosure calculation, not a physical counterexample.',
             '', 'Protocol',
             'Fresh campaigns for epsilon = 3e-4, 1e-3, 3e-3, 1e-2; relative half-width',
             'of C, LM, LS, LE, M, with independent physical ports as in v3.3.',
             'Initial uncertainty delta stays 1e-5. Same 128-pulse source and horizon 1116.',
             'Eight workers; 1536 MiB virtual-address limit per worker; 14400 CPU seconds per cell.',
             'A new campaign identity binds epsilon, source bytes and arithmetic environment.',
             'No campaign.json or receipt is edited; no result is resumed under changed code.',
             'Replay from SOURCE_FOR_REPLAY.zip: install engine/requirements.txt with Python 3.12,',
             'then from engine/: python -B build_all_native.py',
             'and python -B launch_fresh.py --out NEW_DIRECTORY --workers 8 --epsilon 3e-4',
             '(replace epsilon with the desired value; always choose a fresh output directory).',
             '', 'Validation before launch',
             'Both native extensions built in Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0.',
             '78 tests pass, including box coverage and independent ports at all five epsilon values.',
             'The 1e-4 row is the supplied archived reference, not a fresh run of the modified runner.',
             'Each accepted fresh layer passed the engine separate-process artifact verifier.',
             'The supplied summary reader checks payload hashes before extracting state widths.',
             '', 'Timing interpretation',
             'compute_seconds includes planning and the parallel critical path for all 12 cells.',
             'verification_seconds is measured separately and overlaps the next layer computation.',
             'Do not sum compute+verification over layers to infer campaign elapsed time.',
             '', 'Results']
    for row in summary_rows:
        lines.append(json.dumps(row))
    lines += ['', 'Refusal diagnostics']
    for run in status['runs']:
        if 'failure' in run:
            lines += [f"epsilon {run['epsilon']}: {run['failure']['file']}",
                      run['failure']['reason'], '']
    (out / 'REPORT_EN.txt').write_text('\n'.join(lines) + '\n')
    print(json.dumps({'status': status['status'], 'rows': summary_rows}, indent=2))


if __name__ == '__main__':
    main()
