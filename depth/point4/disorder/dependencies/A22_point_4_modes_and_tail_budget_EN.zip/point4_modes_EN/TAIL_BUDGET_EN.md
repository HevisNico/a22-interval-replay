# Quantitative check before a mode-transfer proof

23 October 2026

**Baseline-method result:** the original six-layer heterogeneous-tail certificate accepts widths up to a supremum near 0.1104052895. Optimizing the block length within the same proof method gives five layers and a supremum near 0.1214296379. A working contract with D=0.1214 has strictly positive closure slack. This does not establish universal entrance, and it does not turn a frozen-head contraction into a pruning contraction.

**Subsequent improvement:** `TAIL_REFINEMENT_EN.md` replaces the coarse Jacobian minorization by sharper normalized entry bounds and certifies D=0.195 for the full heterogeneous frozen tail. The limits below apply only to the older minorization family.

## 1. What was optimized

Retain the full independent fresh-cell box of the existing heterogeneous-tail theorem, including effective log-gain offsets [-0.00001,0.00009], initial-charge memory, first arrival at time at least 20, and incoming same-lane gaps at least 15.5.

Write c0=Delta+2 epsilon, where Delta is the directed synchronized delay spread and epsilon=2e-9. The existing certificate gives

    c0 = 0.0001665067484259469514851840379... .

For a block of m layers, replace the earlier fixed block length six by

\[
 W_m=D+mc_0,\qquad
 \gamma_m(D)=e^{-0.0001}\frac{h'(u_++W_m)}{h'(u_+)},
\]

\[
 \rho_m=\min_{r,s}\sum_j\min((P^m)_{rj},(P^m)_{sj}),\quad
 \beta_m(D)=\rho_m\gamma_m(D)^m,
\]

where P has stencil (1/6,2/3,1/6). Exact rational ring convolution evaluates rho_m. The block diameter estimate is

\[
 d_{n+m}\le(1-\beta_m(D))d_n+mc_0.
\]

The closure condition is beta_m(D)D>mc0. All D-dependent physical guards, regeneration margins and the slope bound controlling first-head memory are rechecked. The remaining parameter/energy guards are inherited from the unchanged source certificate included in the package.

## 2. Certified width limits

The strict closure condition has an upper root. The endpoint brackets below have positive closure at the left endpoint and negative closure at the right endpoint. Physical inequalities hold throughout each bracket.

| Block length | Bracket for upper admissible-width supremum |
|---|---|
| 4 | [0.1191434500, 0.1191434502] |
| 5 | [0.1214296378, 0.1214296380] |
| 6 | [0.1104052894, 0.1104052897] |

The supremum itself is not included because the proof uses strict closure. These are limits of this **particular lower-Jacobian/overlap certificate**, not maximum physical widths of A22 and not limits of every possible tail proof.

The five-layer optimum is checked over all positive integer block lengths, not just the three displayed choices. For m=1,2 the overlap is zero. At D0=0.1214296378 all m=3,...,15 except five fail closure, and their log capacity derivatives are negative:

\[
 \frac{d}{dD}\log(D\beta_m(D))
 =\frac1D+m\frac{h''(u_++D+mc_0)}{h'(u_++D+mc_0)}<0.
\]

This derivative decreases with D, since log h' is strictly concave. Thus those methods cannot regain closure above D0. For every m>=16, the physical age bound implies D<0.334 and

\[
 D\beta_m(D)\le0.334\left(e^{-0.0001}
 \frac{h'(u_++D_0)}{h'(u_+)}\right)^m<mc_0.
\]

The last inequality is checked at m=16; its left side decreases and its right side increases thereafter. This proves optimality of m=5 within the stated certificate family.

## 3. Explicit multi-layer factors

Rounded values below are informative; full directed endpoints appear in `results/tail_budget_certificate.json`.

| Entrance D | Layers m | Intermediate W | Diameter factor 1-beta | Additive block allowance mc0 | Positive closure slack |
|---|---:|---:|---:|---:|---:|
| 0.11 | 6 | 0.110999041 | 0.990870486 | 0.000999041 | >0.0000052061 |
| 0.11 | 5 | 0.110832534 | 0.991535014 | 0.000832534 | >0.0000986148 |
| 0.1214 | 5 | 0.122232534 | 0.993140109 | 0.000832534 | >0.00000025711 |

At D=0.11, five-layer blocks improve the closure slack by roughly a factor of 19. A larger accepted tube comes with a weaker contraction bound. These factors concern the **heterogeneous frozen tail T**, conditional on its entrance contract. They cannot be used as factors for the pruning map S.

In the frozen tail, b affects protection and regeneration, but does not enter the regenerated READY head equation. Through pruning, b changes reopening and learned gains, so its much larger forcing effect must be counted separately.

## 4. The affine pruning budget does not close

The previous directed b-only witness gives a synchronous-input output diameter

\[
 f_b\simeq0.0009458292197921523.
\]

Consequently any uniform diameter estimate d'<=q d+f for a domain containing that witness must allow f>=f_b. This is a **necessary lower bound on the allowance**, not a proved full-box upper bound on the actual forcing.

For the proposed q=0.95, the associated affine comparison process has fixed point at least

\[
 \frac{f_b}{1-0.95}
 =0.0189165843958430\ldots .
\]

Taking the supplied pruning-diameter budget 0.0058 as the target, this is too large by a factor of about 3.26. For a one-layer affine estimate with that forcing allowance, fitting this budget would require q<=1-f_b/0.0058, approximately 0.83693. The synchronized nominal alternating derivative has magnitude approximately 0.93884, so a uniform one-layer contraction constant that small is already impossible near synchrony. This is an obstruction to that *uniform affine proof strategy*, not a counterexample to nonlinear extinction.

Grouping the same inequality does not improve the fixed point:

\[
 d_{n+m}\le0.95^m d_n
 +f\frac{1-0.95^m}{1-0.95},
\qquad
 \frac{f(1-0.95^m)/(1-0.95)}{1-0.95^m}=20f.
\]

For example, six layers give q6=0.735091890625, but the inherited additive allowance is already at least about 0.005011 for f=f_b. A 0.0058 absorbing budget would instead require a six-layer allowance no larger than approximately 0.0015365. The gain in the multiplicative factor alone is therefore insufficient.

The new tail width 0.1214 is not automatically a pruning-amplitude budget of 0.1214. The conversion must account for all output cohorts, learned head delays, gap margins and intermediate widths. The supplied value 0.0058 is not derived anew here; there is no justified formula in this note for converting its change from D=0.11 to D=0.1214.

## 5. Consequence for the next proof step

Before a full mode-transfer estimate, a useful target is a genuinely new block bound

\[
 d_{n+m}\le q_m d_n+F_m,
 \qquad F_m<(1-q_m)\,d_{\rm budget},
\]

with every intermediate event margin retained. F_m must be evaluated for the actual compositions, rather than inherited mechanically from a loose one-step bound. Another viable approach is a state-dependent nonlinear bound: clipping of the error integral may strengthen contraction away from infinitesimal synchrony. The nominal pure-alternating certificate in the companion report demonstrates a continuous family that can be controlled, but does not yet provide such a full-box forced estimate.

Thus the quantitative check supports postponing a large mode-transfer calculation until both the admissible pruning budget and a suitable nonlinear/block forcing estimate are established. The full-box, original-source entrance theorem remains unproved.

## 6. A directed nonlinear check with b-only disorder

The quantitative objection motivated a more targeted test, retaining the nonlinear clipping instead of replacing it by a constant contraction plus a constant forcing allowance.

Assume nominal physical constants, nominal gains and exact fresh charges. Keep a two-periodic incoming profile, but allow b_even and b_odd to be chosen independently anywhere in [0.07999,0.08001], with new choices at every layer. Values must be constant within each parity. This is a restricted subset of the original parameter box; arbitrary cell-by-cell choices would generate additional spatial modes.

A new directed certificate proves the uniform envelopes

\[
 0\le d\le0.0058\quad\Longrightarrow\quad |D_{b_e,b_o}(d)|<0.0038,
\]

\[
 0\le d\le0.0038\quad\Longrightarrow\quad |D_{b_e,b_o}(d)|<0.0030.
\]

Thus, after two pruning passages, the amplitude is below 0.0030; this smaller domain is invariant under further passages. These are nonlinear envelope bounds, not a uniform two-step Lipschitz contraction factor for every pair of profiles.

The calculation covers the entire intervals, with 15 and 25 closed subintervals respectively. At each subinterval it checks four directed cell enclosures: both row types, at both endpoints of the b range. The recovery actuator and its increase by 0.3 are included.

Endpoint b values suffice for a mathematical reason. For fixed arrivals, the unlearned head F is independent of b, and

\[
 \frac{\partial R}{\partial b}=\frac{F+1-R}{b+0.3}<0.
\]

The physical guards put R after all second raw endings and F before the first raw ending, so the numerator is strictly negative. The clipped learning increment is nonincreasing in R. Learned gains therefore increase with b, and the later head is nonincreasing in b. For the signed output difference, its minimum is enclosed by the odd head at maximal b minus the even head at minimal b, and its maximum by the reverse choices. This includes all interior b choices, including changes of error/reopening order. The relevant event guards are also extremized at these endpoints: recovery, the later head and gain caps have the stated monotonicities. Each endpoint cell calculation checks strict physical margins.

Two-periodicity is preserved because the parameter choices are constant on each parity. If the output changes sign, shifting the lane labels restores the chosen convention for d. Arbitrary new parity choices at the next layer are already covered by the next envelope. Since 0.0030<0.0038, the second envelope proves invariance of the final amplitude bound.

This is why the affine comparison floor 20f is not a lower bound on the actual physical amplitude: the nonlinear response can contract much more strongly over the relevant nonzero-amplitude range. The result **does not bound transfer to other modes, independent port variations, or arbitrary per-cell disorder**. It also does not establish original-source reachability. It nevertheless supplies a rigorously checked b-only nonlinear two-step estimate below the supplied 0.0058 budget.

## 7. Reproduction

    python3 verify_tail_budget.py
    python3 -O verify_tail_budget.py results/tail_budget_certificate_optimized.json

Both runs were executed and produced identical JSON. All checks use explicit exceptions rather than assertions. The included earlier certificates retain the full endpoints used here; their hashes are recorded. The environment report identifies Python and its binary, as well as the installed NumPy and SciPy versions and representative binary hashes. This verifier itself uses only the Python standard library.

For the b-only nonlinear envelopes:

    python3 verify_b_alternating.py
    python3 -O verify_b_alternating.py results/b_alternating_certificate_optimized.json

The full interval covers are in the corresponding JSON certificates.
