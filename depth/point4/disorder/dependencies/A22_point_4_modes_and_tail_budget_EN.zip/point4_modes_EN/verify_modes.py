"""Directed nominal spectral and pure alternating-mode bounds; no full-box claim."""
import json,sys
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal as D
from directed import I,A,K,log,exp,h,dh,rational,require
from verify_blocks import cell,enclosed_root,G,LM,LE
from verify_desync import exact_profile


def slope(x,vel):
    f=enclosed_root(G,x,'.6666')
    R=(log('2.5')+I('.08')*(f+1)+I('.1')*sum((8+t+I('.02') for t in x),I(0))-I('.024')+I('.3')/LM)/I('.38')
    gamma=[];s=[]
    for t in x:
        d=R-t-I('9.1')
        require(d.lo>0 and d.hi<I('.15').lo,'strict partial-error derivative domain')
        z=I('.8')*exp(-LE*d)
        gamma.append(z-I('.2'));s.append(LE*z)
    gs=[g*exp(a) for g,a in zip(G,gamma)]
    u=enclosed_root(gs,x,'.27')
    t0=[g*dh(f-v) for g,v in zip(G,x)];den0=sum(t0,I(0))
    fp=sum((v*t for v,t in zip(vel,t0)),I(0))/den0
    rp=(I('.08')*fp+I('.1')*sum(vel,I(0)))/I('.38')
    t1=[g*dh(u-v) for g,v in zip(gs,x)];den1=sum(t1,I(0))
    c=[g*h(u-v)*si for g,v,si in zip(gs,x,s)]
    return (sum((ti*vi for ti,vi in zip(t1,vel)),I(0))+sum((ci*(rp-vi) for ci,vi in zip(c,vel)),I(0)))/den1


def alternating():
    delta=F(1,500);z=I(0);one=I(1);accepted=[]
    # Cover [0,.002] by derivative bounds and integrate from D(0)=0.
    # Avoid cancellation in tiny-amplitude secant estimates.
    for k in range(20):
        d=I(rational(F(k,10000)).lo,rational(F(k+1,10000)).hi)
        derivative=slope([z,d,z],[z,one,z])-slope([d,z,d],[one,z,one])
        require(derivative.lo>D('-.95') and derivative.hi<D('.95'),'small alternating amplitude derivative bound')
        cell([z,d,z],I('.08'));cell([d,z,d],I('.08'))
        accepted.append({'d':d.pair(),'method':'derivative; integrate contiguous cover from D(0)=0','bound':derivative.pair()})
    stack=[(delta,F(2,25),0)];tries=0
    while stack:
        lo,hi,depth=stack.pop();di=I(rational(lo).lo,rational(hi).hi);tries+=1
        try:
            even=cell([di,z,di],I('.08'));odd=cell([z,di,z],I('.08'))
            ratio=(odd-even)/di
            ok=ratio.lo>D('-.95') and ratio.hi<D('.95')
        except ArithmeticError:
            ok=False
        if ok:
            accepted.append({'d':di.pair(),'method':'direct secant enclosure','bound':ratio.pair()})
        else:
            require(depth<28,'adaptive partition depth')
            mid=(lo+hi)/2
            stack.extend([(mid,hi,depth+1),(lo,mid,depth+1)])
        if tries%100==0:print(json.dumps({'boxes_attempted':tries,'boxes_accepted':len(accepted)}),flush=True)
    require(accepted[0]['d'][0]=='0','partition starts at zero')
    # Exact-rational recursion already covers the entire interval; rounded leaf
    # intervals overlap at every shared endpoint, which is independently checked.
    for a,b in zip(accepted,accepted[1:]):
        require(D(a['d'][1])>=D(b['d'][0]),'no gap between partition leaves')
    require(D(accepted[-1]['d'][1])>=D('.08'),'partition reaches width .08')
    return {'status':'PASS','input':'X_even=0, X_odd=d, nominal cells; common translations arbitrary',
            'domain_d':['0','.08'],'amplitude_contraction_factor':'.95',
            'scope':'Pure two-periodic profiles only; no other modes and no independent parameter disorder.',
            'boxes_attempted':tries,'cover':accepted}


def spectrum():
    p=exact_profile(['0','0','0']);c=I(*p['jacobian'][1]);a=I(*p['jacobian'][0])
    root3=I('1.73205080756887729352744634150587236694280525381038062805580',
            '1.73205080756887729352744634150587236694280525381038062805581')
    require((I(root3.lo)**2).hi<3 and (I(root3.hi)**2).lo>3,'sqrt3 endpoint certificate')
    cosines=[I(1),root3/2,I('.5'),I(0),I('-.5'),-root3/2,I(-1)]
    rows=[]
    for k,q in enumerate(cosines):
        t=(2+q)/3;s=c+(1-c)*q
        rows.append({'k':k,'frozen_T':t.pair(),'pruning_S':s.pair(),'one_S_one_T':(s*t).pair()})
    require(I(*rows[6]['pruning_S']).lo>D('-.94'),'nominal alternating linearization stable')
    return {'synchronized_pruning_row':[a.pair(),c.pair(),a.pair()],
            'scope':'Jacobian at synchronized nominal profile only','multipliers':rows}


def schedule(M=128):
    # Formal symbolic execution of the conditional prefix/suffix induction.
    live={k:'' for k in range(M)};history=[]
    for n in range(1,M//2+1):
        kill=2*n-1
        for k in list(live):
            if k==kill:del live[k]
            else:live[k]+='T' if k<2*n else 'S'
        for k,word in live.items():
            r=k//2
            expected='S'*min(n,r)+'T'*max(0,n-r)
            require(word==expected,'cohort itinerary identity')
        history.append({'layer':n,'suppressed_original_index':kill,'survivors':len(live)})
    return {'scope':'Conditional complete translated train X+8k; valid pruning and safe-prefix propagation at every step. Not original-source reachability.',
            'M':M,'history':history,'final_itineraries':{str(k):v for k,v in live.items()},
            'largest_consecutive_S_before_first_T':M//2-1}


def safe_prefix():
    u=enclosed_root(G,[I(0)]*3,'.6666');w=I('.08')
    checks={
        'first_marks_before_head':u-w-I('.04'),
        'head_before_first_raw_end':1-u-w,
        'head_before_every_error':I('1.1')-u-w,
        'errors_protected':u+1+log('2.5')/I('.08')-w-I('1.25'),
        'ready_before_next_safe_cohort':I('15.5')-w-u-1-log('2.5')/I('.08'),
        'auxiliary_regeneration':I('15.5')-w-I('1.25')}
    for name,value in checks.items():require(value.lo>0,name)
    return {'nominal_cohort_width':'.08','coordinatewise_gap_lower_bound':'15.5',
            'positive_margins':{k:v.pair() for k,v in checks.items()},
            'proof_obligations_in_text':['T is order-preserving and translation-equivariant on this physical head domain','safe gaps persist coordinatewise','T preserves two-periodicity and does not increase oscillation']}


def main():
    out={'status':'PASS_RESTRICTED_NOMINAL_RESULTS','universal_original_source_entry':'NOT_PROVED',
         'spectrum':spectrum(),'safe_prefix':safe_prefix(),'alternating_mode':alternating(),'cohort_schedule':schedule()}
    path=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent/'results/mode_certificate.json'
    path.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'status':out['status'],'alternating_cover_leaves':len(out['alternating_mode']['cover'])}),flush=True)
if __name__=='__main__':main()
