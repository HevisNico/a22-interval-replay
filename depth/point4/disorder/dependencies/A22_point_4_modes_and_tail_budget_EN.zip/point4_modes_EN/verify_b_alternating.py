"""Nonlinear b-only two-periodic envelope. NOT independent full-box disorder."""
import json,sys
from pathlib import Path
from fractions import Fraction as F
from directed import I,rational,require
from verify_blocks import cell


def cover(cap,target):
    stack=[(F(0),F(cap),0)];accepted=[];attempts=0
    while stack:
        lo,hi,dep=stack.pop();d=I(rational(lo).lo,rational(hi).hi);z=I(0);attempts+=1
        try:
            el=cell([d,z,d],I('.07999'));eh=cell([d,z,d],I('.08001'))
            ol=cell([z,d,z],I('.07999'));oh=cell([z,d,z],I('.08001'))
            bounds=I((oh-el).lo,(ol-eh).hi)
            ok=bounds.lo> -I(target).hi and bounds.hi<I(target).lo
        except ArithmeticError:ok=False
        if ok:accepted.append({'input_d':d.pair(),'output_signed_difference':bounds.pair()})
        else:
            require(dep<20,'b-only envelope refinement depth');mid=(lo+hi)/2
            stack.extend([(mid,hi,dep+1),(lo,mid,dep+1)])
        if attempts%50==0:print(json.dumps({'input_cap':cap,'attempts':attempts,'accepted':len(accepted)}),flush=True)
    require(I(*accepted[0]['input_d']).lo==0,'cover starts at zero')
    for a,b in zip(accepted,accepted[1:]):require(I(*a['input_d']).hi>=I(*b['input_d']).lo,'cover gap')
    require(I(*accepted[-1]['input_d']).hi>=I(cap).hi,'cover endpoint')
    return {'input_cap':cap,'output_cap':target,'attempts':attempts,'cover':accepted}


def main():
    rows=[cover('.0058','.0038'),cover('.0038','.0030')]
    r={'status':'PASS_B_ONLY_TWO_PERIODIC_NONLINEAR_ENVELOPE',
       'scope':'Nominal gains and physical constants, exact fresh charges; b independently chosen for each parity in [.07999,.08001] at every layer, constant within each parity. Complete translated input cohorts. Not arbitrary per-cell b or the full A22 box.',
       'monotonicity_argument':'For fixed arrivals F is independent of b, dR/db=(F+1-R)/(b+.3)<0 on the checked physical event domain. Clipped gamma is nonincreasing in R, so every learned gain is nondecreasing in b and the output head is nonincreasing in b. Endpoint b values therefore enclose every interior b.',
       'envelopes':rows,'two_step_conclusion':'d<=.0058 implies d_after_1<.0038 and d_after_2<.0030; [.0,.0030] is invariant because it is a subset of the second input domain.',
       'universal_original_source_entry':'NOT_PROVED'}
    out=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent/'results/b_alternating_certificate.json'
    out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'leaves':[len(v['cover']) for v in rows]}))
if __name__=='__main__':main()
