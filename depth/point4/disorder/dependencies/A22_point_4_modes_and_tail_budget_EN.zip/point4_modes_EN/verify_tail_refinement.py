"""Entrywise normalized Jacobian bounds extend the full-box frozen tail."""
import json,sys
from pathlib import Path
from directed import I,A,K,exp,log,h,dh,require
from verify_tail_budget import ROOT,BASE,P,U,UMIN,C,EPS,validate_baselines


def coefficients(d,m):
    v=U+I(d)+m*C;g=exp('-.0001')*dh(v)/dh(U)
    require(0<g.lo<=g.hi<1,'positive gamma below one')
    return g/(5+g),2*g/(1+2*g),g


def beta(d,m):
    a,b,g=coefficients(d,m);row=[I(int(j==0)) for j in range(12)]
    for _ in range(m):row=[a*(row[(j-1)%12]+row[(j+1)%12])+b*row[j] for j in range(12)]
    vals=[]
    for shift in range(12):
        vals.append(sum((I(min(row[j].lo,row[(j-shift)%12].lo),min(row[j].hi,row[(j-shift)%12].hi)) for j in range(12)),I(0)))
    return I(min(v.lo for v in vals),min(v.hi for v in vals))


def closure(d,m):return I(d)*beta(d,m)-m*C


def decreasing_capacity_bound(d,m):
    v=U+I(d)+m*C;_,_,g=coefficients(d,m)
    hp=A/(A-K)*(K*K*exp(-K*v)-A*A*exp(-A*v))
    return I(1)/I(d)+m*(hp/dh(v))/(1+2*g)


def physical(d,m):
    d=I(d);W=d+m*C;young=UMIN-I(W.hi)-EPS;old=U+I(W.hi)+EPS
    marks=I(*BASE['mark_end']);es=I(*BASE['error_start']);ee=I(*BASE['error_end']);pr=I(*BASE['principal_protection'])
    slope=I('1.8')*exp('-.00001')*dh(I(old.hi))-K*I('.00001')
    require(slope.lo>0,'positive slope for memory bound')
    err=I('.00001')*exp(-10)/slope
    margins={'head_after_last_arrival':young,'marks_before_head':young-I(marks.hi),
       'head_before_raw_end':1-old,'head_before_error':I(es.lo)-old,
       'error_protected':young+I(pr.lo)-I(ee.hi),'raw_protected':young+I(pr.lo)-1,
       'main_regenerated':I('15.49999999')-I(W.hi)-U-EPS-I(pr.hi),
       'auxiliary_regenerated':I('15.49999999')-I(W.hi)-I(ee.hi),
       'no_early_head':1-I('.10001')-I('1.8')*exp('.00009')*h(I(W.hi)),
       'first_head_memory_allowance':EPS-err,'first_head_advance_above_0_66':UMIN-EPS-I('.66')}
    for name,value in margins.items():require(value.lo>0,name)
    return {'D':d.pair(),'m':m,'W':W.pair(),'slope':slope.pair(),'first_head_memory_bound':err.pair(),
       'positive_margins':{k:v.pair() for k,v in margins.items()},'beta':beta(d,m).pair(),
       'block_contraction_factor':(1-beta(d,m)).pair(),'block_forcing':(m*C).pair(),'closure_slack':closure(d,m).pair()}


def main():
    validate_baselines()
    brackets={4:('.1852227796','.1852227799'),5:('.1950798211','.1950798214'),6:('.1891293631','.1891293635')}
    rows=[]
    for m,(lo,hi) in brackets.items():
        l=closure(lo,m);r=closure(hi,m);dec=decreasing_capacity_bound(lo,m)
        require(l.lo>0 and r.hi<0,'refined upper closure root bracket')
        require(dec.hi<0,'capacity decreases beyond lower endpoint')
        rows.append({'m':m,'upper_admissible_D_supremum_bracket':[lo,hi],
            'left_closure':l.pair(),'right_closure':r.pair(),'capacity_log_derivative_upper_bound':dec.pair(),
            'physical_bracket_checks':physical(I(lo,hi),m)})
    d0=brackets[5][0];excluded=[]
    for m in range(1,16):
        if m==5:continue
        val=closure(d0,m)
        require(val.hi<0,'other length fails closure at d0')
        if m>=3:
            der=decreasing_capacity_bound(d0,m);require(der.hi<0,'other length capacity decreasing')
            excluded.append({'m':m,'closure_at_d0':val.pair(),'capacity_log_derivative_upper_bound':der.pair()})
        else:
            require(beta(d0,m).hi==0,'zero overlap for m<3');excluded.append({'m':m,'zero_overlap':True})
    g0=exp('-.0001')*dh(U+I(d0))/dh(U)
    mass=2*g0/(5+g0)+2*g0/(1+2*g0)
    require((1-U).hi<I('.334').lo and 0<mass.lo<=mass.hi<1,'large-block domain')
    upper=I('.334')*I(mass.hi)**16-16*C
    require(upper.hi<0,'all lengths m>=16 excluded')
    working=[physical('.11',5),physical('.1214',5),physical('.195',5)]
    for p in working:require(I(*p['closure_slack']).lo>0,'working refined contract closes')
    report={'status':'PASS_REFINED_FULL_BOX_FROZEN_TAIL','universal_original_source_entry':'NOT_PROVED',
      'scope':'Full independent fresh-cell box; same conditional entire-history tail contract. Entrywise bounds Q=(gamma/(5+gamma),2gamma/(1+2gamma),gamma/(5+gamma)).',
      'upper_root_brackets':rows,'optimal_block_length_within_this_certificate_family':5,
      'other_block_exclusions':excluded,'large_block_exclusion':{'m_min':16,'row_mass_upper':str(mass.hi),'margin_at_16':upper.pair()},
      'working_contracts':working,'note':'Largest certified width for this specified entrywise minorization family, not a physical maximum. Slope >0.3 is replaced by the directly verified first-head error <2e-9; regeneration remains strictly positive.'}
    out=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'results/tail_refinement_certificate.json'
    out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'D_supremum':brackets[5],'D_working':'.195','working_block':working[-1]}))
if __name__=='__main__':main()
