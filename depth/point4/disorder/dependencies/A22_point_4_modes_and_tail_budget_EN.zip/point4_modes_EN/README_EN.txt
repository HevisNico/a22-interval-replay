A22 — alternating mode and actual cohort itineraries

Read TAIL_REFINEMENT_EN.md first (new full-box working tail width D=0.195),
then TAIL_BUDGET_EN.md and PROOF_EN.md.
Universal original-source entrance is NOT PROVED.

New directed result: for nominal, pure two-periodic profiles with width d <= 0.08,
|D(d)| <= 0.95 d through the nonlinear pruning map, with b tracked explicitly.
This yields a conditional 128-cohort extinction result for that boundary family.

Reproduce the directed certificate (Python standard library only):
  python3 verify_modes.py results/mode_certificate.json
  python3 -O verify_modes.py results/mode_certificate_optimized.json
The two JSON files should be identical. Reproduction may take several minutes.

The verifier checks a continuous interval cover, strict physical root signs,
clipped adaptation, event margins and a symbolic cohort itinerary. The manual
induction and the scope limitations are in the report. The included preceding
package supplies model context and earlier limitations. No production data is
modified or new original-source campaign run.

Tail width optimization and block factors:
  python3 verify_tail_budget.py
  python3 -O verify_tail_budget.py results/tail_budget_certificate_optimized.json

The maximum D reported is for the existing gamma^m P^m certificate family,
not the maximum physically possible width. Five-layer blocks permit D=0.1214.

Additional b-only two-periodic nonlinear envelope:
  python3 verify_b_alternating.py
  python3 -O verify_b_alternating.py results/b_alternating_certificate_optimized.json
It proves .0058 -> .0038 -> .0030, then invariance, for parity-constant b
disorder only. It does not cover arbitrary per-cell disorder or other parameters.

Sharper full-box frozen-tail certificate:
  python3 verify_tail_refinement.py
  python3 -O verify_tail_refinement.py results/tail_refinement_certificate_optimized.json
Five-layer blocks now permit D=0.195; the supremum within this sharper
minorization family lies in [.1950798211,.1950798214].
