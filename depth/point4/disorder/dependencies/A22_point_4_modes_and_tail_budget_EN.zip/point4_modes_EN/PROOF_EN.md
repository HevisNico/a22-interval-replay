# A22: separating the alternating mode and counting actual cohort itineraries

23 October 2026

**Status: restricted nominal results, not a universal entrance proof.** This note follows the suggestion to separate the alternating Fourier mode from the other modes and to count pruning versus frozen passages. It establishes a nonlinear contraction bound on the entire pure alternating family of width at most 0.08, and gives the exact conditional cohort itinerary. Independent port/cell disorder and entrance from the original single-lane source remain unproved.

The accompanying checker uses directed finite-series interval arithmetic, not sampled plots, to establish the stated numerical bounds. This is a mathematical argument with a numerical certificate; it is not a proof-assistant verification or independent review. Original campaign files and receipts are untouched.

## 1. Maps and the nominal linear spectrum

Use the same physical maps as the preceding packages. T(X) is the unlearned head map. S(X) is the profile of the third input cohort after a fresh cell passes the first cohort, suppresses the second, and adapts during its residual error. The common advance of 16 is removed from S. The recovery actuator b is included: the three protected marks increase b from 0.08 to 0.38 before reopening. All recovery and gain formulas, including clipped partial/full error increments, are retained.

At a synchronized nominal profile, the Jacobian of T has stencil (1/6,2/3,1/6), hence

\[
 t_k=\frac23+\frac13\cos(2\pi k/12).
\]

The synchronized Jacobian of S has stencil (a,c,a), 2a+c=1, with c approximately 0.03058. Consequently

\[
 s_k=c+(1-c)\cos(2\pi k/12).
\]

The checker encloses c and every multiplier using directed arithmetic; cosines are exact rational combinations of a certified square-root-of-three bracket. For k=6, the alternating mode,

\[
 t_6=1/3,\qquad s_6\simeq-0.938839434.
\]

Thus one S followed by one T has alternating multiplier approximately -0.312946478. At this synchronized linearization both maps individually damp every nonconstant mode. An arbitrary product of P pruning and F frozen Jacobians has kth multiplier s_k^P t_k^F, because these particular circulant matrices commute.

These formulas are not global Fourier multipliers of a nonlinear heterogeneous head. In particular, the earlier wide-profile row with center approximately -0.29384 gives an alternating *local row response* approximately -1.58768. It is not by itself a Fourier eigenvalue of the full 12-by-12 Jacobian. Other rows see other triples; on a two-periodic background there are generally two row types. A single-row response can also include a change in the common timing offset.

## 2. A nonlinear result: the pure alternating family contracts

Define a nominal two-periodic profile by

\[
 X_{2j}=0,\qquad X_{2j+1}=d,\qquad 0\le d\le0.08.
\]

Add an arbitrary common starting time at least 20 when interpreting this as a physical boundary input. The model is homogeneous and commutes with cyclic lane shifts. Therefore S(X) also has two values. Let

\[
 D(d)=S(X)_1-S(X)_0
      =S_{\rm cell}(0,d,0)-S_{\rm cell}(d,0,d).
\]

**Certified bound:**

\[
 |D(d)|\le0.95d\quad\text{for every }0\le d\le0.08.
\]

For d>0 the certificate actually gives a strict bound. No small-amplitude linearization is substituted for S here.

### Numerical proof and branch handling

On the initial interval [0,0.002], subdivided into 20 intervals of width 0.0001, both row types remain on their strict partial-error branches. Differentiating the full reopening, gain and head equations gives a directed enclosure of D'(d) inside [-0.95,0.95]. Since D(0)=0 by symmetry, the fundamental theorem of calculus proves the desired bound there.

On the rest of [0.002,0.08], adaptive exact-rational subdivision encloses both physical head roots on each closed subinterval. The checker tests directly that the entire interval enclosure of D(d)/d lies inside (-0.95,0.95). The gain formula is clipped between 0 and 0.6, so a box crossing an error/reopening ordering boundary includes both cases. No strict ordering is imposed on those boxes. Closed rounded intervals overlap at subdivision boundaries, and the checker verifies that the cover reaches 0.08 without gaps.

For both row types on every accepted box, the checker also verifies the physical event inequalities: first marks before firing, first errors protected, all second raw pulses blocked, reopening before second errors finish, later marks before firing, later errors protected, regeneration before the next dense cohort, inactive caps, and a new first output gap strictly above 15.5. The check includes the b increase to 0.38. Root candidates are accepted only after strict directed endpoint-sign checks in the physical monotone root domain.

The full list of accepted intervals and their enclosures is in `results/mode_certificate.json`. This is a cover of a one-dimensional continuous family, not a random sample of it.

If D(d)<0, the parity of the later profile is reversed. A lane shift and a common time translation return it to the same parametrized family, with amplitude |D(d)|. Therefore the family is invariant and repeated nominal pruning satisfies

\[
 \operatorname{osc}(S^m(X))\le0.95^m\operatorname{osc}(X).
\]

This explains why a negative center entry alone is not evidence that pure alternation grows. The earlier six-step *pairwise* expansion witness is consistent with this result: it compares two general mixed-mode backgrounds and does not lie in this one-dimensional family.

## 3. Safe prefixes and a conditional extinction corollary

The nominal unlearned head T is order-preserving and commutes with common time translations on the physical head domain. This follows directly from the positive derivative h' of the pulse response: increasing any arrival time cannot make the threshold head earlier. The directed checks bound all relevant head ages between zero and one.

It follows that T does not increase a profile's oscillation. It also preserves any coordinatewise gap: if Y-X >= H componentwise, then T(Y)-T(X) >= H. T preserves two-periodicity by symmetry.

For profiles of width at most 0.08 and coordinatewise safe gaps at least 15.5, `safe_prefix()` verifies that every unlearned response has its marks before firing, its errors under protection, and its principal and auxiliary states regenerated before the next safe cohort. Thus these safe-prefix responses do not adapt b or the gains. In particular, the principal regeneration margin is bounded below by

\[
 15.5-0.08-u_0-1-\frac{\log 2.5}{0.08}>0,
\]

where u_0 is the synchronized nominal unlearned head delay.

Combine this with the preceding certified alternating-family pruning bound. For a **complete translated boundary train** X+8k, k=0,...,M-1, with nominal fresh states and parameters and two-periodic X of width at most 0.08, induction is valid:

* each layer passes the existing safe prefix without adaptation;
* it passes the first dense cohort and suppresses the second;
* the third and subsequent dense cohorts acquire the same translated profile S(X), and remain 8-spaced;
* the newly created safe gap exceeds 15.5;
* both the safe and dense profiles retain width at most 0.08.

For M=128, the train has 64 surviving safe cohorts at layer 64. From layer 65 onward this finite train causes no learning. This is an extension of the earlier nominal small-width result **along the pure alternating subspace only**. It does not certify arbitrary width-0.08 profiles, independent disorder, the original single-lane source, or additional future inputs that fail the safe-gap assumptions.

## 4. The actual itinerary: consecutive pruning cannot be skipped

Number original cohorts from k=0. Under the valid prefix/suffix induction, after n layers the survivors are

\[
 0,2,\ldots,2n-2,\quad 2n,2n+1,\ldots,M-1,
\]

up to truncation at the end of the train. Layer n suppresses original cohort 2n-1. For an even cohort k=2r, its profile at layer n>=r is

\[
 F_{n,2r}=16r+T^{\,n-r}\big(S^r(X)\big).
\]

For a surviving cohort still in the dense suffix, k>=2n, its profile is 8k+S^n(X). These formulas follow by induction from the two map definitions. A safe cohort undergoes T, while a remaining dense cohort undergoes S. `schedule()` checks the formal itineraries for all 128 cohorts; it is a combinatorial check of this conditional argument, not a simulation certifying its physical hypotheses.

In particular, cohort 126 undergoes **63 consecutive S maps**, then one T at layer 64. Its first frozen passage does not occur between its first and second pruning passages. The T-like first-head calculation used internally to define S cannot be counted again as an independent damping passage for the late cohort.

The pure alternating theorem controls these 63 passages directly:

\[
 \operatorname{osc}(S^{63}(X))\le0.95^{63}\operatorname{osc}(X)
 <0.0395\operatorname{osc}(X).
\]

For general profiles, however, a hypothetical bound of 1.58 per S and 1/3 per T would require at least 27 frozen passages to offset 63 pruning passages. Cohort 126 has only one at layer 64, and later damping cannot retroactively establish the validity of earlier local pruning steps. In addition, 1.58 and 1/3 are not established uniform bounds on the full heterogeneous problem.

For layer-dependent maps, even where the physical itinerary persists, replace powers by ordered compositions. Fourier components can mix, so counting alone does not generally determine the norm of a product.

## 5. A precise version of the proposed weighted-norm route

Work modulo a common time shift. Let e=(1,-1,...,1,-1)/sqrt(12), P_0 the constant-mode projector, P_pi=ee^T, and Q=I-P_0-P_pi. For a centered profile z define

\[
 A=|e^Tz|,\qquad B=\|Qz\|_2,\qquad N_\lambda(z)=A+\lambda B,\quad\lambda>0.
\]

For each actual passage H in {S,T}, a usable proof would establish, on a specified invariant domain and for the full independent parameter box,

\[
 \begin{pmatrix}A'\\B'\end{pmatrix}
 \le M_H\begin{pmatrix}A\\B\end{pmatrix}+f_H,
\]

componentwise, with nonnegative M_H and f_H. Off-diagonal entries bound mode mixing; f_H bounds asynchronous output created even from a synchronous input by parameter disorder. Neither term may be omitted. One can seek these estimates directly relative to synchrony; a uniform contraction estimate for every pair of wider profiles is unnecessary and would encounter the previous counterexample.

For example, if

\[
 M_H=\begin{pmatrix}a_H&b_H\\c_H&d_H\end{pmatrix},
\]

then

\[
 N_\lambda(z')\le g_H N_\lambda(z)+q_H,
\quad
 g_H=\max(a_H+\lambda c_H,\ d_H+b_H/\lambda),
\quad q_H=(f_H)_1+\lambda(f_H)_2.
\]

For an actual chronological itinerary H_1,...,H_n, induction gives

\[
 N_n\le\left(\prod_{i=1}^n g_{H_i}\right)N_0
 +\sum_{j=1}^n q_{H_j}\prod_{i=j+1}^n g_{H_i}.
\]

If g_S and g_T are uniform, the homogeneous product is g_S^P g_T^F. The forcing term still depends on the order of passages. Keeping the two-dimensional matrix product instead can give a sharper bound, but those matrices generally do not commute.

Every prefix of each itinerary must satisfy the domain constraint. A simple sufficient conversion is

\[
 \operatorname{osc}(z)\le\sqrt2\,\|z\|_2
 \le\sqrt2\max(1,1/\lambda)N_\lambda(z).
\]

A successful bound must also control the gaps between successive surviving cohorts and the hybrid event margins, not just a final-layer spatial norm. The conditional itinerary above shows exactly where a finite pruning budget may help and where no frozen damping is yet available.

## 6. What is and is not now established

Established here: the nominal synchronized spectral multipliers; a directed nonlinear contraction for all pure alternating profiles of width <=0.08; the associated conditional finite-train extinction result; the exact conditional cohort itinerary; and a sufficient weighted-norm propagation criterion.

Not established: full-box bounds for mode mixing and disorder forcing; closure for general mixed-mode profiles through all required pruning prefixes; or entrance of every original-source preparation into the required complete-cohort boundary structure. Thus **the universal point-4 theorem remains open**. The new result narrows the difficulty: the pure alternating nominal family can be controlled without borrowing future frozen layers, while its coupling to other modes and to independent disorder remains to be bounded.
