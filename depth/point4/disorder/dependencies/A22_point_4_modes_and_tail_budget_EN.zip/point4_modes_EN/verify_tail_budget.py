"""Optimize block length in the existing heterogeneous-tail certificate.
Not a maximum physical width, and not a pruning-map contraction theorem.
"""
import json,sys,hashlib
from pathlib import Path
from fractions import Fraction as F
from zipfile import ZipFile
from decimal import Decimal as D
from directed import I,A,K,exp,log,h,dh,rational,require
ROOT=Path(__file__).parent
BASE=json.loads((ROOT/'dependencies/heterogeneous_tail_bounds.json').read_text())
P=BASE['profiles'][1]
U=I(P['maximum_synchronized_delay'][1]);UMIN=I(P['minimum_synchronized_delay'][0])
DELTA=I(*P['synchronized_delay_spread_upper']);EPS=I('.000000002');C=DELTA+2*EPS

def overlap(m):
 row=[F(int(j==0)) for j in range(12)]
 for _ in range(m):row=[(row[(j-1)%12]+4*row[j]+row[(j+1)%12])/6 for j in range(12)]
 return min(sum((min(row[j],row[(j-i)%12]) for j in range(12)),F(0)) for i in range(12))

def beta(d,m):
 W=I(d)+m*C
 gamma=exp('-.0001')*dh(U+W)/dh(U)
 return rational(overlap(m))*gamma**m

def closure(d,m):return I(d)*beta(d,m)-m*C

def logderiv(d,m):
 v=U+I(d)+m*C
 hh=A/(A-K)*(K*K*exp(-K*v)-A*A*exp(-A*v))
 return I(1)/I(d)+m*hh/dh(v)

def physical(d,m):
 d=I(d);W=d+m*C;ages=I(UMIN.lo)-I(W.hi)-EPS,I(U.hi)+I(W.hi)+EPS
 marks=I(*BASE['mark_end']);es=I(*BASE['error_start']);ee=I(*BASE['error_end']);pr=I(*BASE['principal_protection'])
 margins={'head_after_last_arrival':ages[0], 'marks_before_head':ages[0]-I(marks.hi),
  'head_before_raw_end':1-ages[1],'head_before_error':I(es.lo)-ages[1],
  'error_protected':ages[0]+I(pr.lo)-I(ee.hi),
  'raw_protected':ages[0]+I(pr.lo)-1,
  'main_regenerated':I('15.49999999')-I(W.hi)-U-EPS-I(pr.hi),
  'auxiliary_regenerated':I('15.49999999')-I(W.hi)-I(ee.hi),
  'no_early_head':1-I('.10001')-I('1.8')*exp('.00009')*h(I(W.hi))}
 slope=I('1.8')*exp('-.00001')*dh(I(ages[1].hi))-K*I('.00001')
 margins['first_head_slope_above_0_3']=slope-I('.3')
 for name,val in margins.items():require(val.lo>0,name)
 return {'D':d.pair(),'block_length':m,'W':W.pair(),'positive_margins':{k:v.pair() for k,v in margins.items()},
         'beta':beta(d,m).pair(),'contraction_factor':(1-beta(d,m)).pair(),'block_forcing':(m*C).pair(),'closure_slack':closure(d,m).pair()}

def validate_baselines():
 for name,digest,member,local in [
  ('A22_points_1_2_heterogeneous_tail_ergodic_speed_EN.zip','a1bc53f0824e1f53e342dc0392d755265f63dc469be584f47afc6fe2cde2438b','A22_points_1_2_EN/comparison_and_bounds.json','heterogeneous_tail_bounds.json'),
  ('A22_point_4_multilayer_EN.zip','dbd9bd737fbc5fce621781de9b7a86b49945d49339d7bf6f7a278f58e72a5641','point4_multilayer_EN/results/block_certificate.json','multilayer_bounds.json')]:
  path=ROOT/'dependencies'/name
  require(hashlib.sha256(path.read_bytes()).hexdigest()==digest,'previous deliverable hash')
  with ZipFile(path) as archive:require(archive.read(member)==(ROOT/'dependencies'/local).read_bytes(),'baseline report matches archived deliverable')

def main():
 validate_baselines()
 brackets={4:('0.1191434500','0.1191434502'),5:('0.1214296378','0.1214296380'),6:('0.1104052894','0.1104052897')}
 cert=[]
 for m,(lo,hi) in brackets.items():
  l=closure(lo,m);r=closure(hi,m);der=logderiv(lo,m)
  require(l.lo>0 and r.hi<0,'upper closure root bracket')
  require(der.hi<0,'closure capacity decreasing beyond lower bracket')
  phys=physical(I(lo,hi),m)
  cert.append({'block_length':m,'upper_admissible_D_supremum_bracket':[lo,hi],
    'left_closure':l.pair(),'right_closure':r.pair(),'left_log_capacity_derivative':der.pair(),'physical_bracket_checks':phys})
 # All other block lengths are excluded above the lower five-step bracket.
 d0=brackets[5][0];exclusions=[]
 for m in range(1,16):
  if m==5:continue
  if m<3:
   require(overlap(m)==0,'no overlap at block length 1 or 2')
   exclusions.append({'m':m,'reason':'zero overlap'});continue
  val=closure(d0,m);der=logderiv(d0,m)
  require(val.hi<0 and der.hi<0,'other block excluded above d0')
  exclusions.append({'m':m,'closure_at_d0':val.pair(),'log_capacity_derivative_at_d0':der.pair()})
 # Any physically allowed D has D < 1-u_plus < .334.
 require((1-U).hi<D('.334'),'universal physical upper D for this age bound')
 g=exp('-.0001')*dh(U+I(d0))/dh(U)
 require(0<g.lo<=g.hi<1,'large block decay')
 big=I('.334')*I(g.hi)**16-16*C
 require(big.hi<0,'all m >=16 excluded: LHS decreases, forcing increases')
 chosen=[physical('.11',5),physical('.11',6),physical('.1214',5)]
 for x in chosen:require(I(*x['closure_slack']).lo>0,'chosen block closes')
 f=I(*json.loads((ROOT/'dependencies/multilayer_bounds.json').read_text())['independent_b_forcing']['output_diameter'])
 report={'status':'PASS_CERTIFICATE_FAMILY_OPTIMIZATION','scope':'Complete fresh initial box; existing gamma^m P^m overlap method only. Not the maximal physically possible tail width.',
  'root_brackets':cert,'chosen_working_contracts':chosen,'other_block_exclusions':exclusions,
  'large_block_exclusion':{'m_min':16,'D_max_used':'.334','gamma_upper':str(g.hi),'margin_at_16':big.pair()},
  'b_only_forcing_witness':f.pair(),'affine_proxy_absorbing_diameter_at_rho_0_95':(f/I('.05')).pair(),
  'warning':'The b witness is a lower bound on a necessary uniform forcing allowance, not a proved full-box forcing upper bound. Grouping the same one-step affine estimate does not lower its fixed point.',
  'baseline_sha256':hashlib.sha256((ROOT/'dependencies/heterogeneous_tail_bounds.json').read_bytes()).hexdigest()}
 out=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'results/tail_budget_certificate.json'
 out.write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'status':report['status'],'D_supremum_five_steps':brackets[5],'D_supremum_six_steps':brackets[6],'b_only_affine_floor':(f/I('.05')).pair()}))
if __name__=='__main__':main()
